# H3RTZ.stdio
## Features
This project, coded in C, aims to bring a portable audio player to life. Currently, it supports almost every formats but lacks features.
## How to use?
You need to compile this project to run it. A simple "make all" command will compile everything you need. However, some dependancies are needed: they are listed below.
After compilation, you can open the executable using your shell with "./main" or click on the file in the file explorer to run it without a shell (standalone GUI).
## Dependencies
- Gstreamer 1.0 (with basic sets of plugin to run the program)
- GTK 3.0
- PulseAudio (as software and the developer pack)
- Default programs and librairies for C: gcc with default headers
## Cleaning the project:
A simple "make clean" will remove everything related to the compilation of the program.
