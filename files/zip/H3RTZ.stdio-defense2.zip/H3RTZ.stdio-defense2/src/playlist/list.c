#include <stdlib.h>
#include "list.h"
#include <stdio.h>
#include <stddef.h>
#include <string.h>

void list_init(linked_list *list)
{
    	list->next = NULL;
        list->data = 0;
}

int list_is_empty(linked_list *list)
{
    if (list == NULL)
        return 1;
    return !list->next;
}

size_t list_len(linked_list *list)
{
    if (list_is_empty(list))
        return 0;
    linked_list *next = list->next;
    size_t size = 0;
    for(; next != NULL; next = next->next)
    {
        size++;
    }
    return size;
}

void list_push_front(linked_list *list, linked_list *elm)
{
    if (list->next == NULL)
    {
        list->next = elm;
        elm->next = NULL;
        return;
    }
    linked_list *nextNode = list->next;
    elm->next = nextNode;
    list->next = elm;
}

linked_list *list_pop_front(linked_list *list)
{
    if (list_is_empty(list))
        return NULL;
    if (list_len(list) == 1)
    {
        linked_list *oldEl = list->next;
        list->next = NULL;
        return oldEl;
    }
    else
    {
        linked_list *newFront = list->next->next;
        linked_list *oldEl = list->next;
        list->next = newFront;
        return oldEl;
    }
    
}

linked_list *list_find(linked_list *list, char *value)
{
    linked_list *next = list->next;
    for(; next != NULL; next = next->next)
    {
        if (strcmp(value, next->data) == 0)
        {
            return next;
        }
    }
    return NULL;
}
#if OPTIONAL
linked_list *list_lower_bound(linked_list *list, int value)
{
    //linked_list *previous = NULL;
    linked_list *next = list->next;
    for(; next != NULL; next = next->next)
    {
        if (next->data > value)
        {
            /*
            linked_list *res = malloc(sizeof(linked_list));
            res->data = 0;
            res->next = next;
            */
            return next; //res
        }
        //previous = next;
    }
    return NULL;
}

int list_is_sorted(linked_list *list)
{
    if (list_len(list) == 0 || list_len(list) == 1)
        return 1;
    linked_list *previous = list->next;
    linked_list *next = list->next->next;
    for(; next != NULL; next = next->next)
    {
        //printf("%d %d\n", previous->data, next->data);
        if (previous->data > next->data)
        {
            return 0;
        }
        previous = next;
    }
    return 1;
}
#endif
void list_insert(linked_list *list, linked_list *elm)
{
    if (list->next == NULL)
    {
        list->next = elm;
        elm->next = NULL;
        return;
    }
    linked_list *next = list->next;
    linked_list *previous = list;
    for (; next != NULL; next = next->next)
    {
        if (next->data > elm->data)
        {
            previous->next = elm;
            elm->next = next;
            return;
        }
        previous = next;
    }
    previous->next = elm;
    elm->next = NULL;
    
}
#if OPTIONAL
void list_rev(linked_list *list)
{p
    size_t length = list_len(list);
    int *data = malloc(sizeof(int)*length);
    linked_list *next = list->next;
    for (size_t i = 0; i < length; i++)
    {
        data[i] = next->data;
        next = next->next;
    }
    next = list->next;
    for (size_t i = 0; i < length; i++)
    {
        next->data = data[length-i-1];
        next = next->next;
    }
    
    
}

void list_half_split(linked_list *list, linked_list *second)
{
    size_t len = list_len(list);
    linked_list *next = list->next;
    for (size_t i = 0; i < len/2-1; i++)
    {
        next = next->next;
    }
    second->next = next->next;
    next->next = NULL;
    
}
#endif

linked_list *initNode(void *data)
{
    linked_list *newNode = malloc(sizeof(linked_list));
    newNode->data = data;
    newNode->next = 0;
    return newNode;
}

void freeNode(linked_list *elm)
{
    free(elm);
}