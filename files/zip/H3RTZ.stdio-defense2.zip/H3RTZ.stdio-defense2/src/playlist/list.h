#ifndef _LIST_H_
#define _LIST_H_
#include <stddef.h>
#define OPTIONAL 0
typedef struct linked_list
{
  struct linked_list *next;
  void *data;
} linked_list;

// Initialize the sentinel of an empty list.
void list_init(linked_list *list);

// Return true if the list is empty.
// Otherwise, return false.
// Do not forget that there is always a sentinel.
// So the list is empty if the sentinel does not point to a next element.
int list_is_empty(linked_list *list);

// Return the length of the list (sentinel excluded).
size_t list_len(linked_list *list);

// Insert 'elm' in front of the list, that is just after the sentinel.
// Note that 'elm' is already an existing element.
// You just have to insert it.
void list_push_front(linked_list *list, linked_list *elm);

// Extract the first element (not the sentinel) of the list.
// This operation removes the element from the list and returns it
// (the caller is responsible for freeing it).
// If the list is empty, the function returns NULL.
linked_list *list_pop_front(linked_list *list);

// Search for the first element that contains 'value' and return it
// (without removing it from the list).
// The function returns NULL if the value is not in the list.
linked_list *list_find(linked_list *list, char *value);
#if OPTIONAL
// Search for the first element that is not smaller than 'value'
// and return the element that comes just before.
linked_list *list_lower_bound(linked_list *list, int value);

// Return true if the list is sorted in increasing order.
// Otherwise, return false.
int list_is_sorted(linked_list *list);
#endif
// Insert 'elm' in the sorted list (keeping the list sorted).
// Note that 'elm' is already an existing element.
// You just have to insert it.
void list_insert(linked_list *list, linked_list *elm);
#if OPTIONAL
// Reverse the elements of the list (except for the sentinel).
void list_rev(linked_list *list);

// Split the list in half and put the second half in 'second'.
// 'second' is an empty list (just a sentinel).
void list_half_split(linked_list *list, linked_list *second);
#endif
// Creates a new node to be inserted in the list
linked_list *initNode(void *data);

// frees the element but not the data
void freeNode(linked_list *elm);
#endif
