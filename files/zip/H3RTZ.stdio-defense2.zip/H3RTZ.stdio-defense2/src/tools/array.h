#ifndef ARRAY_H
#define ARRAY_H

#include <stdio.h>
void addToArrayl(long double *array, size_t size, long double term);
#endif