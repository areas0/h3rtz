#ifndef CONVERSION_H
#define CONVERSION_H

// This file contains various bitwise/integers tools
#include <stdio.h>
typedef struct int128
{
    unsigned int a;
    unsigned int b;
    unsigned int c;
    unsigned int d;
} int128;
__uint32_t intConversionBE(unsigned char *data);
__int16_t shortConversionBE(unsigned char *data);
__uint32_t uintConversionBE(unsigned char *data);
__int32_t intConversionLE(unsigned char *data);
__int16_t shortConversionLE(unsigned char *data);
__uint128_t int128ConversionBE(unsigned char *data);
__uint128_t int128ConversionLE(unsigned char *data);
#endif