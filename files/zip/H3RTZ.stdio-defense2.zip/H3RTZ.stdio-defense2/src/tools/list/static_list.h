#ifndef STATIC_LIST_H
#define STATIC_LIST_H

#include <stdio.h>
#include <stdlib.h>

#define DEFAULT_SIZE 128

typedef struct static_list
{
    size_t *data;
    size_t size;
    size_t nb_el;
} static_list;

typedef struct static_list_f
{
    long double *data;
    size_t size;
    size_t nb_el;
} static_list_f;

static_list *initStaticList(void);
void doubleCapacity(static_list *l);
void appendStaticList(static_list *l, size_t elm);
void removeLast(static_list *l);
void printStaticList(static_list *l);
void freeStaticList(static_list *l);
void popStaticList(static_list *l, size_t i);
static_list_f *initStaticListF(void);
void doubleCapacityF(static_list_f *l);
void appendStaticListF(static_list_f *l, long double elm);
void removeLastF(static_list_f *l);
void popStaticListF(static_list_f *l, size_t i);
void freeStaticListF(static_list_f *l);
void printStaticListF(static_list_f *l);
int ListContains(static_list *l, size_t elm);
int ListContainsF(static_list_f *l, long double elm);
#endif