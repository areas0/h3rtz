#include "conversion.h"

// Fast 4 bytes to int conversion (merging) BIG ENDIAN
// @param data: must be an at least 4 bytes long array
__uint32_t intConversionBE(unsigned char *data)
{
    return (data[0] << 24) | (data[1] << 16) | (data[2] << 8) | (data[3]);
}
// Fast 4 bytes to int conversion (merging) LITTLE ENDIAN
// @param data: must be an at least 4 bytes long array
__int32_t intConversionLE(unsigned char *data)
{
    return (data[3] << 24) | (data[2] << 16) | (data[1] << 8) | (data[0]);
}

// Fast 4 bytes to uint conversion (merging) BIG ENDIAN
// @param data: must be an at least 4 bytes long array
__uint32_t uintConversionBE(unsigned char *data)
{
    return (data[0] << 24) | (data[1] << 16) | (data[2] << 8) | (data[3]);
}

// Fast 2 bytes to short conversion (merging) BIG ENDIAN
// @param data: must be at least 2 bytes long
__int16_t shortConversionBE(unsigned char *data)
{
    return (data[0] << 8) | (data[1]);
}
// Fast 2 bytes to short conversion (merging) LITTLE ENDIAN
// @param data: must be at least 2 bytes long
__int16_t shortConversionLE(unsigned char *data)
{
    return (data[1] << 8) | (data[0]);
}

// Fast 16 bytes to unsigned long long conversion (merging) BIG ENDIAN
// @param data: must be at least 16 bytes long
__uint128_t int128ConversionBE(unsigned char *data)
{
    return ((__uint128_t) uintConversionBE(data) << 96) |
    ((__uint128_t) uintConversionBE(data+4) <<  64) |
    ((__uint128_t) uintConversionBE(data+8) << 32) |
    uintConversionBE(data+12);
}
// Fast 16 bytes to unsigned long long conversion (merging) LITTLE ENDIAN
// @param data: must be at least 16 bytes long
__uint128_t int128ConversionLE(unsigned char *data)
{
    return ((__uint128_t) intConversionBE(data+12) << 96) |
    ((__uint128_t) intConversionBE(data+8) <<  64) |
    ((__uint128_t) intConversionBE(data+4) << 32) |
    intConversionBE(data);
}