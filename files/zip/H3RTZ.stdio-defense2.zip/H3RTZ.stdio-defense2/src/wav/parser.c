#include "parser.h"

// Move that to another file later
file *getData(char *path)
{
    file *fileData = calloc(1, sizeof(file));
    fileData->stats = malloc(sizeof(struct stat));
    // file opening
    int fd_in = open(path, O_RDONLY);
    if (fd_in == -1)
    {
        free(fileData);
        free(fileData->stats);
        return NULL;
    }
    fileData->fd = fd_in;
    int error = stat(path, fileData->stats);
    if (error == -1)
        errx(errno, "Failed");
    // mapping data to memory
    unsigned char *data = mmap(NULL, fileData->stats->st_size,
                                PROT_READ, MAP_SHARED, fd_in, 0);
    if (data == MAP_FAILED)
        err(errno, "Could not map the file");
    fileData->map = data;
    return fileData;
}

void freeFile(file *file)
{
    if (!file)
        return;
    if (file->fd < 0)
    {
        free(file->map);
        free(file->stats);
        free(file);
        return;
    }
    close(file->fd);
    munmap(file->map, file->stats->st_size);
    free(file->stats);
    free(file);
}

// Note: could be reworked with multithreading to get even faster parsing
// Estimate the position of the next chunk and launch parallel threads to parse it
/* Opens a file, supposed of a valid format (wav)
 * parses all the chunks to provide a header
 * This header can be used to retrieve pulseaudio specs to play the file
 * @param path: path to the file to parse
*/
wav *headerParser(file *file)
{
    if (!file)
        return NULL;
    unsigned char *data = file->map;
    wav *header = calloc(1, sizeof(wav));
    assert(header);
    // parsing zone
    uint32_t formatCheck = intConversionBE(data);
    if (formatCheck != RIFF)
    {
        warnx("HeaderParser: File provided is not a wav file, returning null...");
        free(header);
        return NULL;
    }
    size_t size = file->stats->st_size -4;
    for (size_t i = 0; i < size;)
    {
        uint32_t chunkid = intConversionBE(data+i);
        if (chunkid == RIFF)
        {
            header->riff = riffParser(data, &i);
            if (uintConversionBE((unsigned char *) header->riff->fileFormatId) != WAV)
                errx(1, "Invalid format: WAVE expected");
        }
        else if (chunkid == FMT)
        {
            fmtParser(data, &i, header);
        }
        else if (chunkid == DATA)
        {
            header->data = dataParser(data, &i);
        }
        else if (chunkid == FACT)
        {
            header->fact = factParser(data, &i);
        }
        else if (chunkid == LIST)
        {
            header->list = listParser(data, &i);
        }
        else
        {
            // padding for files needing it
            // chunk skipping for unsupported
            //printf("padding\n");
            i++;
            //break;
        }
    }
    // mandatory chunks
    if (!header->data || !header->riff || !header->fmt)
    {
        warnx("headerParser: invalid header: returning empty object...");
        freeWav(header);
        return NULL;
    }
    //read_header_wav(path);
    printHeader(header);
    return header;
}
// Riff chunk parser
// @param data: the mapped data in memory
// @param i: index in the file
riff *riffParser(unsigned char *data, size_t *i)
{
    riff *riff = malloc(sizeof(struct riff));
    strcpyn(data + *i, riff->riff, 4);
    *i += 4;
    riff->fileSize = intConversionLE(data + *i);
    *i += 4;
    strcpyn(data + *i, riff->fileFormatId, 4);
    *i += 4;
    return riff;
}
// data chunk parser
// @param data: the mapped data in memory
// @param i: index in the file
data *dataParser(unsigned char *d, size_t *i)
{
    data *data = malloc(sizeof(struct data));
    strcpyn(d + *i,data->data, 4);
    data->data_bytes = intConversionLE(d+ *i + 4);
    data->chunk = d + *i + 8;
    *i += data->data_bytes + 8 + (data->data_bytes % 8 == 0 ? 0 : 1); //padding
    return data;
}
// fact chunk parser
// @param data: the mapped data in memory
// @param i: index in the file
fact *factParser(unsigned char *data, size_t *i)
{
    fact *fact = malloc(sizeof(struct fact));
    strcpyn(data + *i,fact->fact, 4);
    fact->chunk_size = intConversionLE(data + *i + 4);
    fact->nb_samples = intConversionLE(data + *i + 8);
    *i += sizeof(struct fact);
    return fact;
}
// fmt chunk parser
// @param data: the mapped data in memory
// @param i: index in the file
// @param header: the current header
void fmtParser(unsigned char *data, size_t *i, wav *header)
{
    // default header is PCM
    header->format = CLASSIC_PCM;
    header->fmt = malloc(sizeof(fmt));

    fmt *fmt = header->fmt;
    strcpyn(data + *i,fmt->fmt, 4);
    // temp represents a temporary index
    size_t temp = *i + 4;
    fmt->blocSize = intConversionLE(data + temp);
    temp += 4;
    fmt->AudioFormat = shortConversionLE(data + temp);
    temp += 2;
    fmt->channel = shortConversionLE(data + temp);
    temp += 2;
    fmt->sampling_freq = intConversionLE(data + temp);
    temp += 4;
    fmt->bitrate = intConversionLE(data + temp);
    temp += 4;
    fmt->blocrate = shortConversionLE(data + temp);
    temp += 2;
    fmt->samplerate = shortConversionLE(data + temp);
    temp += 2;
    // PCM_FLOAT custom bloc data
    if (fmt->blocSize == 18)
    {
        header->fmt = realloc(header->fmt, sizeof(fmt_float));
        header->fmt_float->wExtSize = shortConversionLE(data + temp);
        temp += 2;
        header->format = FLOAT_PCM;
    }
    // this is wave_extensible header
    else if (fmt->blocSize == 40)
    {
        header->format = EXTENSIBLE;
        header->fmt = realloc(header->fmt, sizeof(fmt_extensible));
        header->fmt_extensible->extension_size = shortConversionLE(data + temp);
        temp += 2;
        header->fmt_extensible->valid_bytes_ps = shortConversionLE(data + temp);
        temp += 2;
        header->fmt_extensible->channel_mask = intConversionLE(data + temp);
        temp += 4;
        strcpyn(data + temp, header->fmt_extensible->sub_format, 16);
        temp += 16;
    }
    *i = temp;
}
// Custom strncpy: copies from src to dest n bytes exactly
// It doesn't require a null terminating src/dst to work
// done to bypass gcc warnings
void strcpyn(unsigned char *src, char *dest, size_t n)
{
    for (size_t i = 0; i < n; i++)
    {
        dest[i] = (char) src[i];
    }
}

// General procedure to free a wav object
// Warning: the real data must be freed in another place with munmap
// This function will clean up the attached objects to the data
void freeWav(wav *wav)
{
    if (!wav)
        return;
    if (wav->data)
        free(wav->data);
    if (wav->riff)
        free(wav->riff);
    if (wav->fmt)
        free(wav->fmt);
    if (wav->fact)
        free(wav->fact);
    if (wav->list)
        freeList(wav->list);
    free(wav);
}