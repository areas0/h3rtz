#ifndef WAV_H
#define WAV_H
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <err.h>
#include <sys/types.h>
#include <pulse/pulseaudio.h>
#include <pulse/simple.h>
#include <string.h>
#include "../tools/conversion.h"
#include "legacy.h"
#include "parser.h"
#include "headerwav.h"

void printHeader(wav *h);
pa_sample_spec headerToSpecs(wav *h);
void printHeaderNormal(wav *h);
void printHeaderExt(wav *h);
#endif