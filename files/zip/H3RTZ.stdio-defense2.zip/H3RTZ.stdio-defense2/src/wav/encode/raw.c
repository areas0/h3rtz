#include "raw.h"

// "efficient" write
void rewrite(int fd, const void *buf, size_t count, char *err_msg)
{
    int r;
    size_t offset = 0;
    while (offset < count)
    {
        r = write(fd, buf + offset, count - offset);
        if (r == -1)
        {
            errx(EXIT_FAILURE, "failed to write %s into fd", err_msg);
        }
        if (r == 0)
        {
            break;
        }
        offset += r;
    }
}

//write a new wave file with given header and file
void write_wav(char *path, char **new_wav, struct wav *header)
{
    int ret = open(path, O_RDONLY);

    //creating repetition file
    char *new_file = malloc(BUFFER_SIZE);

    strcpy(new_file, path);
    new_file[strlen(new_file) - 4] = 0;
    strcat(new_file, "_2.wav");

    strcpy(*new_wav, new_file);
    free(new_file);

    int res = open(*new_wav, O_CREAT | O_WRONLY, 0666);

    if (ret < 0)
    {
        errx(EXIT_FAILURE, "open raw file failed\n");
    }

    struct stat st;
    int stat = fstat(ret, &st);
    int raw_size = st.st_size;

    if (stat == -1)
    {
        errx(EXIT_FAILURE, "stat on raw file failed\n");
    }

    //write header
    write_header(res, header);

    char *buf = malloc(raw_size * sizeof(char));

    if (read(ret, buf, raw_size) < 0)
    {
        err(3, "read from raw data failed");
    };

    //write .raw into .wav
    rewrite(res, buf, raw_size, "new wav");

    free(buf);
}

//writes the raw signal + data structure
void write_raw(char *path, char **raw_file, struct wav *header)
{
    char *buf = malloc(header->data->data_bytes);
    char *new_file = malloc(BUFFER_SIZE);

    strcpyn((unsigned char *)path, new_file, BUFFER_SIZE);
    new_file[strlen(new_file) - 4] = 0;
    strcat(new_file, ".raw");
    strcpy(*raw_file, new_file);

    int fd_write = open(*raw_file, O_CREAT | O_WRONLY | O_TRUNC, 0666);

    rewrite(fd_write, header->data->chunk, header->data->data_bytes, "raw data");

    free(buf);
    free(new_file);
}

//writes a new header into fd
void write_header(int fd, struct wav *header)
{
    //Writing riff chunk header
    rewrite(fd, header->riff, sizeof(riff), "riff chunk");

    //write fmt chunk
    switch (header->format)
    {
    case CLASSIC_PCM:
        rewrite(fd, header->fmt, sizeof(fmt), "classic PCM");
        break;

    case FLOAT_PCM:
        rewrite(fd, header->fmt_float, sizeof(fmt_float), "float PCM");
        rewrite(fd, header->fact, sizeof(fact), "fact PCM");
        break;

    case EXTENSIBLE:
        rewrite(fd, header->fmt_extensible, sizeof(struct fmt_extensible), "extensible PCM");
        break;
    default:
        errx(EXIT_FAILURE, "unknown format\n");
        break;
    }

    //writing nested data chunk
    if (header->list != NULL)
    {
        rewrite(fd, header->list->list, 4, "LIST");
        char chunk_size[8];

        int size = sprintf(chunk_size, "%c", header->list->chunk_size);

        rewrite(fd, chunk_size, size, "list chunk size");

        //weird spacing found in file
        write_space(fd, 3);

        //infos struct writing
        for (info *i = header->list->infos; i != NULL; i = i->next)
        {
            rewrite(fd, i->infoId, 4, "infoID");

            //writing size
            if (i->size)
            {
                char size_buf[4];
                size = sprintf(size_buf, "%c", i->size);
                char *error_buf = malloc(BUFFER_SIZE);
                sprintf(error_buf, "info size on %s", i->infoId);

                rewrite(fd, size_buf, size, error_buf);
                free(error_buf);
            }

            if (i->data != NULL)
            {
                write_space(fd, 3);
                int chunk_size = i->size;

                char *error_buf = malloc(BUFFER_SIZE);
                sprintf(error_buf, "info data on %s", i->infoId);

                rewrite(fd, i->data, chunk_size, error_buf);
                free(error_buf);

                if (chunk_size % 2 != 0)
                {
                    write_space(fd, 1);
                }
            }
        }
    }

    rewrite(fd, header->data->data, 4, "data string");
    unsigned char chunk_size[4]; // holding an int
    int data_bytes = header->data->data_bytes;

    chunk_size[0] = data_bytes & 0xFF;
    chunk_size[1] = (data_bytes >> 8) & 0xFF;
    chunk_size[2] = (data_bytes >> 16) & 0xFF;
    chunk_size[3] = (data_bytes >> 24) & 0xFF;

    for (size_t i = 0; i < 4; i++)
    {
        rewrite(fd, &chunk_size[i], 1, "data size");
    }
}

//writes n null bytes for spacing
void write_space(int fd, size_t n)
{
    for (size_t i = 0; i < n; i++)
    {
        unsigned char hex = 0x0;
        rewrite(fd, &hex, 1, "spacing");
    }
}

char *add_wav(char *src, char *raw_file, char *argv[])
{
    /* Convention for argv:
    0: Artist
    1: Copyrights
    2: Genre
    3: Name
    4: Album

    Upgrade for later
    for (size_t i = 0; i < 5; i++)
    {
        if (strcmp(argv[i], unknown) == 0)
        {
            switch (i)
            {
            case 0:
                argv[0] = find_arg(header, "IART");
                break;
            case 1:
                argv[1] = find_arg(header, "ICOP");
            case 2:
                argv[2] = find_arg(header, "IGNR");
            case 3:
                argv[3] = find_arg(header, "INAM");
            case 4:
                argv[4] = find_arg(header, "ISBJ");
            default:
                break;
            }
        }
        
    }
    */

    file *first_file = getData(src);
    wav *header = headerParser(first_file);
    char *new_wav = malloc(BUFFER_SIZE);

    //int check[5] = {0};
    info *current = header->list->infos;

    for (; current != NULL; current = current->next)
    {
        int art = strncmp(current->infoId, "IART", 4);

        if (art == 0 && strcmp(argv[0], "No changes\n") != 0)
        {
            unsigned int diff = strlen(argv[0]) - strlen(current->data);
            current->size += diff;
            header->list->chunk_size += diff;
            header->riff->fileSize += diff;
            current->data = argv[0];
            /* What should be done or smth:
                check[0] = 1;
                current->data = realloc(current->data, strlen(argv[0]));
                strcpyn((unsigned char *)argv[0], current->data, strlen(argv[0]));
            */
            continue;
        }

        int cpy = strncmp(current->infoId, "ICOP", 4);

        if (cpy == 0 && strcmp(argv[1], "No changes\n") != 0)
        {
            unsigned int diff = strlen(argv[1]) - strlen(current->data);
            current->size += diff;
            header->list->chunk_size += diff;
            header->riff->fileSize += diff;
            current->data = argv[1];
            /* What should be done or smth:
                check[1] = 1;
                current->data = realloc(current->data, strlen(argv[1]));
                strcpyn((unsigned char *)argv[1], current->data, strlen(argv[1]));
            */
            continue;
        }

        int gnr = strncmp(current->infoId, "IGNR", 4);
        if (gnr == 0 && strcmp(argv[2], "No changes\n") != 0)
        {
            unsigned int diff = strlen(argv[2]) - strlen(current->data);
            current->size += diff;
            header->list->chunk_size += diff;
            header->riff->fileSize += diff;
            current->data = argv[2];
            
            /* What should be done or smth:
                check[2] = 1;
                current->data = realloc(current->data, strlen(argv[2]));
                strcpyn((unsigned char *)argv[2], current->data, strlen(argv[2]));
            */
            continue;
        }

        int nme = strncmp(current->infoId, "INAM", 4);
        if (nme == 0 && strcmp(argv[3], "No changes\n") != 0)
        {
            unsigned int diff = strlen(argv[3]) - strlen(current->data);
            current->size += diff;
            header->list->chunk_size += diff;
            header->riff->fileSize += diff;
            current->data = argv[3];
            /* What should be done or smth:
                check[3] = 1;
                current->data = realloc(current->data, strlen(argv[3]));
                strcpyn((unsigned char *)argv[3], current->data, strlen(argv[3]));
            */
            continue;
        }

        int alm = strncmp(current->infoId, "ISBJ", 4);
        if (alm == 0 && strcmp(argv[4], "No changes\n") != 0)
        {
            unsigned int diff = strlen(argv[4]) - strlen(current->data);
            current->size += diff;
            header->list->chunk_size += diff;
            header->riff->fileSize += diff;
            current->data = argv[4];
            
            /* What should be done or smth:
                check[4] = 1;
                current->data = realloc(current->data, strlen(argv[4]));
                strcpyn((unsigned char *)argv[4], current->data, strlen(argv[4]));
            */
            continue;
        }
    }

    /* 
    info *artist = malloc(sizeof(info));
    info *copy = malloc(sizeof(info));
    info *genre = malloc(sizeof(info));
    info *name = malloc(sizeof(info));
    info *album = malloc(sizeof(info));

    for (size_t j = 0; j < 5; j++)
    {
        if (!check[j])
        {
            switch (j)
            {
            case 0:
                strcpyn((unsigned char *)"IART", (char *)artist->infoId, 4);
                artist->size = strlen(argv[0]);
                artist->data = argv[0];
                artist->next = NULL;
                header->riff->fileSize += artist->size;
                header->list->chunk_size += artist->size;
                memcpy(current, name, sizeof(info));
                current = current->next;
                break;
            case 1:
                strcpyn((unsigned char *)"ICOP", (char *)copy->infoId, 4);
                copy->size = strlen(argv[1]);
                copy->data = argv[1];
                copy->next = NULL;
                header->riff->fileSize += copy->size;
                header->list->chunk_size += copy->size;
                memcpy(current, name, sizeof(info));
                current = current->next;
                break;
            case 2:
                strcpyn((unsigned char *)"IGNR", (char *)genre->infoId, 4);
                genre->size = strlen(argv[2]);
                genre->data = argv[2];
                genre->next = NULL;
                header->riff->fileSize += genre->size;
                header->list->chunk_size += genre->size;
                memcpy(current, name, sizeof(info));
                current = current->next;
                break;
            case 3:
                strcpyn((unsigned char *)"INAM", (char *)name->infoId, 4);
                name->size = strlen(argv[3]);
                name->data = argv[3];
                name->next = NULL;
                header->riff->fileSize += name->size;
                header->list->chunk_size += name->size;
                memcpy(current, name, sizeof(info));
                current = current->next;
                break;
            case 4:
                strcpyn((unsigned char *)"ISBJ", (char *)album->infoId, 4);
                album->size = strlen(argv[4]);
                album->data = argv[4];
                album->next = NULL;
                header->riff->fileSize += album->size;
                header->list->chunk_size += album->size;
                memcpy(current, name, sizeof(info));
                current = current->next;
                break;
            default:
                break;
            }
        }
    }

    free(artist);
    free(copy);
    free(genre);
    free(name);
    free(album);
    */

    write_wav(raw_file, &new_wav, header);

    freeWav(header);
    freeFile(first_file);

    return new_wav;
}