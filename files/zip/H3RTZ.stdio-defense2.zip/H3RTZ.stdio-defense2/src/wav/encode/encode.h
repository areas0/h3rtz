#ifndef ENCODE_H
#define ENCODE_H

//simple i/o function to get new info
int infoInput(char *message, char **res);

// add elements to the linked list
void add_list(char *src, char *raw_file);

//takes a file and reencodes the file somewhere else into src_2.wav
void encode(char *src);

//add new info to header->list
// Disclaimer: I will only add new informations from the linked list
void add_encode(char *src);

//main function
void wav_encode(char *src);
#endif