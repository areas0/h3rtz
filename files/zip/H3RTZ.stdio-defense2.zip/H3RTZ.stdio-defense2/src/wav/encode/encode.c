#include "raw.h"
#include "encode.h"

/* Upgrade for later
char *find_arg(struct wav *header, char *type)
{
    for (info* i = header->list->infos; i != NULL; i = i->next)
    {
        if (strcmp(i->infoId, type) == 0)
        {
            return i->data;
        }
    }

    return NULL;
}
*/

void header_init(struct wav *h)
{
    h->riff = malloc(sizeof(riff));
    h->fact = malloc(sizeof(fact));
    h->data = malloc(sizeof(data));
    h->format = (enum fmt_type)malloc(sizeof(fmt_type));
    h->list = malloc(sizeof(list));
    h->list->infos = malloc(sizeof(info));
}

/*
// copying each element from src to dest using memcpy
void header_cpy(struct wav *dst, struct wav *src)
{
    header_init(dst);
    memcpy(dst->riff, src->riff, sizeof(riff));

    (src->fact == NULL) ? dst->fact = NULL : memcpy(dst->fact, src->fact, sizeof(fact));
    memcpy(dst->data, src->data, sizeof(data));
    fmt_type fmt = src->format;
    dst->format = fmt;
    char list[4] = "LIST";
    //starting the list which will be tricky
    strcpyn((unsigned char *)list, dst->list->list, 4);

    int chunk_size = src->list->chunk_size;
    dst->list->chunk_size = chunk_size;
    //memcpy(dst->list->data, src->list->data, src->list->chunk_size);

    for (info *i = src->list->infos, *j = dst->list->infos; i != NULL; i = i->next, j = j->next)
    {
        //infoID and data are strings so strcpy is more adapted
        strcpy(j->infoId, i->infoId);
        unsigned int size = i->size;
        j->size = size;
        strcpy(j->data, i->data);
        struct info *next = i->next;
        j->next = next;
    }
}
*/

int infoInput(char *message, char **res)
{
    int ret = write(STDOUT_FILENO, message, strlen(message));

    if (ret == -1)
    {
        errx(1, "failed to write %s message", message);
    }

    ret = read(STDIN_FILENO, *res, BUFFER_SIZE);

    if (ret == -1)
    {
        errx(1, "failed to read %s from stdin", message);
    }

    char *no_changes = "No changes\n";

    if (*res[0] == '\n')
    {
        strcpy(*res, no_changes);
        return strlen(no_changes);
    }

    return ret;
}

void encode(char *src)
{
    file *first_file = getData(src); //real file
    wav *header = headerParser(first_file);

    char *raw_file = malloc(BUFFER_SIZE);
    write_raw(src, &raw_file, header);

    char *new_wav = malloc(BUFFER_SIZE);
    write_wav(raw_file, &new_wav, header);

    /*
    Priting results
    file *wav_file = getData(new_wav);
    wav *res = headerParser(wav_file);
    
    freeWav(res);
    freeFile(wav_file);
    */

    free(new_wav);
    free(raw_file);
    freeWav(header);
    freeFile(first_file);
}

void add_list(char *src, char *raw_file)
{
    char *artist_buf = malloc(BUFFER_SIZE);
    int art = infoInput("Artist(s): ", &artist_buf);
    artist_buf[art] = '\0';

    char *copyright_buf = malloc(BUFFER_SIZE);
    int cpy = infoInput("Copyright: ", &copyright_buf);
    copyright_buf[cpy] = '\0';

    char *genre_buf = malloc(BUFFER_SIZE);
    int gnr = infoInput("Genre: ", &genre_buf);
    genre_buf[gnr] = '\0';

    char *name_buf = malloc(BUFFER_SIZE);
    int nme = infoInput("Name: ", &name_buf);
    name_buf[nme] = '\0';

    char *album_buf = malloc(BUFFER_SIZE);
    int alm = infoInput("Album: ", &album_buf);
    album_buf[alm] = '\0';

    printf("\n=== Writing this information into the header file... ===\n");

    char **args = malloc(5 * sizeof(char *));

    for (size_t i = 0; i < 5; i++)
    {
        args[i] = (char *)malloc(BUFFER_SIZE);
    }

    snprintf(args[0], art, "%s", artist_buf);
    snprintf(args[1], cpy, "%s", copyright_buf);
    snprintf(args[2], gnr, "%s", genre_buf);
    snprintf(args[3], nme, "%s", name_buf);
    snprintf(args[4], alm, "%s", album_buf);

    char *new_wav = add_wav(src, raw_file, args);

    //Final testing
    file *wav_file = getData(new_wav);
    wav *res = headerParser(wav_file);

    free(artist_buf);
    free(copyright_buf);
    free(genre_buf);
    free(name_buf);
    free(album_buf);
    free(new_wav);

    for (size_t i = 0; i < 5; i++)
    {
        free(args[i]);
    }
    free(args);

    freeWav(res);
    freeFile(wav_file);
}

void add_encode(char *src)
{
    file *first_file = getData(src); //real file
    wav *header = headerParser(first_file);

    char *raw_file = malloc(BUFFER_SIZE);
    write_raw(src, &raw_file, header);

    add_list(src, raw_file);

    free(raw_file);
    freeWav(header);
    freeFile(first_file);
}

void wav_encode(char *src)
{
    //Main for wav_encoding
    //Encode for no changes
    //Add_encode for new infomation
    if (src == NULL)
    {
        errx(1, "Usage: [wav_file]");
    }

    printf("Want to write a new header ? (y / n) : ");

    char keep_header = 0;
    int scan = scanf("%c", &keep_header);

    if (scan == 0)
    {
        errx(1, "Failed to scan");
    }

    switch (keep_header)
    {
    case 'y':
        add_encode(src);
        break;
    case 'n':
        encode(src);
        break;
    default:
        warnx("Encode: error, misinput from user");
        break;
    }
}