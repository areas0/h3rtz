#ifndef RAW_H
#define RAW_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <err.h>
#include <sys/types.h>
#include <pulse/pulseaudio.h>
#include <pulse/simple.h>
#include "../wav.h"
#include "../parser.h"
#include "../headerwav.h"
#define BUFFER_SIZE 128

// "efficient" write
void rewrite(int fd, const void *buf, size_t count, char *err_msg);

//write a new wave file with given header and file
void write_wav(char *path, char **new_wav, struct wav *header);

//writes the raw signal + data structure
void write_raw(char *path, char **raw_file, struct wav *header);

//writes a new header into fd
void write_header(int fd, struct wav *header);

//writes 3 null bytes for spacing
void write_space(int fd, size_t n);

//creates a new struct wav and add the new list into it
char *add_wav(char *src, char *raw_file, char *argv[]);

#endif
