this directory will be about decoding data from wav files to play them as .raw files.

Use rewrite instead of write(2)