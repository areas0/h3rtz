#include "wav.h"

//PIECES of strings to determine data conformity to standard
//cannot be seen outside of file (static context)
const uint32_t RIFF = 0x52494646;
const uint32_t WAV = 0x57415645;
const uint32_t FMT = 0x666d7420;
const uint32_t DATA = 0x64617461;
const uint32_t FACT = 0x66616374;
const uint32_t LIST = 0x4C495354;
const uint32_t INFO = 0x494E464F;
// compiler constants cannot be larger than 64 bits so bit shifting must be used
const __uint128_t PCM_CODE = ((__uint128_t) 0x0100000000001000 << 64)
                                                        | 0x800000aa00389b71;
const __uint128_t PCM_FLOAT_CODE = ((__uint128_t) 0x0300000000001000 << 64)
                                        | 0x800000aa00389b71;
//static const __uint128_t PCM_CODE2= 0x000000010000001080000aa00389B71;

void printHeaderNormal(wav *h)
{
    if (h == NULL)
    {
        warnx("print_header : No header found");
        return;
    }
    printf("========File Info==========\n");
    //printf("FileSize: %d\n", h->fileSize);
    printf("Sampling frequency: %dHz\n", h->fmt->sampling_freq);
    printf("Sampling size: %d bits\n", h->fmt->samplerate);
    printf("Audio type: %s\n", audio_format(
                                (enum compression_codes) h->fmt->AudioFormat));
    printf("Channels: %s\n", channel_type((enum channels) h->fmt->channel));
    printf("Average bitrate: %d bits per sec\n", h->fmt_float->bitrate);
    printf("Estimated duration: %ds\n", h->data->data_bytes/h->fmt->bitrate);
    printf("=====Bloc info=====\n");
    printf("Bloc size: %d bits\n", h->fmt->blocSize);
    printf("Bloc rate: %dB\n", h->fmt->blocrate);
    printf("=======Various data=======\n");
    printf("FileSize: %d B (data: %d B)\n", h->riff->fileSize,
                                            h->data->data_bytes);
    printf("File format id: %s\n",
    intConversionBE((unsigned char *) h->riff->fileFormatId) == WAV ? "WAV" :
    "Unknown");
    if (h->format == FLOAT_PCM)
    {
        printf("PCM FLOAT fmt chunk: %d\n", h->fmt_float->wExtSize);
    }
    printf("=======End========\n");
}
void printHeaderExt(wav *h)
{
    if (h == NULL)
    {
        warnx("print_header : No header found");
        return;
    }
    printf("========File Info==========\n");
    //printf("FileSize: %d\n", h->fileSize);
    printf("Sampling frequency: %dHz\n", h->fmt->sampling_freq);
    printf("Sampling size: %d bits\n", h->fmt->samplerate);
    printf("Audio type: %s %s\n", audio_format(
        (enum compression_codes) h->fmt->AudioFormat),
    int128ConversionBE((unsigned char *)h->fmt_extensible->sub_format)
    == PCM_CODE ? "PCM" : "PCM FLOAT");
    printf("Channels: %s\n", channel_type((enum channels) h->fmt->channel));
    printf("Average bitrate: %d bits per sec\n", h->fmt_float->bitrate);
    printf("Estimated duration: %ds\n", h->data->data_bytes/h->fmt->bitrate);
    printf("=====Bloc info=====\n");
    printf("Bloc size: %d bits\n", h->fmt->blocSize);
    printf("Bloc rate: %dB\n", h->fmt->blocrate);
    printf("=======Various data=======\n");
    printf("FileSize: %d B (data: %d B)\n",
            h->riff->fileSize, h->data->data_bytes);
    printf("File format id: %s\n",
    intConversionBE((unsigned char *)h->riff->fileFormatId) == WAV ? "WAV" :
    "Unknown");
    printf("=======End========\n");
}

// Provides a header for pulseaudio according to the header's data
pa_sample_spec headerToSpecs(wav *h)
{
    pa_sample_spec s;
    switch ((enum data_type) h->fmt->samplerate)
    {
        case unsigned_data8:
            s.format = PA_SAMPLE_U8;
            break;
        case signed_data12: //handle 12 bit as 16 bit
            s.format = PA_SAMPLE_S16LE;
            break;
        case signed_data16:
            s.format = PA_SAMPLE_S16LE;
            break;
        case signed_data24:
            s.format = PA_SAMPLE_S24LE;
            break;
        case signed_data32:
            if (h->fmt->AudioFormat == PCM_float)
            {
                s.format = PA_SAMPLE_FLOAT32LE;
                break;
            }
            s.format = PA_SAMPLE_S32LE;
            break;
        case signed_data64:
            if (h->fmt->AudioFormat == PCM_float)
            {
                s.format = PA_SAMPLE_MAX;
                warnx("Unsuported PCM FLOAT 64 bit");
                break;
            }
            s.format = PA_SAMPLE_MAX;
            warnx("headerToSpecs: pulseaudio formats specs reached: %d", 64);
            break;
        default:
            s.format = PA_SAMPLE_INVALID;
            warnx("headerToSpecs: couldn't assign a valid format, \
                    program will most likely fail");
            break;
    }
    s.rate = h->fmt->sampling_freq;
    s.channels = h->fmt->channel;
    return s;
}

pa_sample_spec headerExtToSpecs(wav *h)
{
    if (h->format != EXTENSIBLE)
    {
        warnx("headerExtToSpecs: no extensible header found");
        return headerToSpecs(h);
    }
    __uint128_t guid = int128ConversionBE(
        (unsigned char *)h->fmt_extensible->sub_format);
    if (guid == PCM_CODE)
    {
        return headerToSpecs(h);
    }
    else if (guid == PCM_FLOAT_CODE)
    {
        pa_sample_spec s = headerToSpecs(h);
        if (h->fmt->samplerate == 64)
        {
            warnx("Unsupported format");
            s.format = PA_SAMPLE_INVALID;
        }
        s.format = PA_SAMPLE_FLOAT32LE;
        return s;
    }
    else
    {
        pa_sample_spec s = headerToSpecs(h);
        s.format = PA_SAMPLE_INVALID;
        warnx("Unsupported format");
        return s;
    }
}

void printHeader(wav *h)
{
    switch (h->format)
    {
        case CLASSIC_PCM:
        case FLOAT_PCM:
            printHeaderNormal(h);
            break;
        case EXTENSIBLE:
            printHeaderExt(h);
            break;
        default:
            warnx("printHeader: unknown wav header");
            break;
    }
}
