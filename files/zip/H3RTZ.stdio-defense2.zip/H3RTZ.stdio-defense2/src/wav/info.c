#include "info.h"

/* Parses a standard listChunk with the information inside
** @param data: the file being read
** @param i: the pointer to the current index being read
** @return the parsed list object
*/
list *listParser(unsigned char *data, size_t *i)
{
    list *list = malloc(sizeof(struct list));
    list->chunk_size = intConversionLE(data+*i+4);
    list->infos = calloc(1, sizeof(info));
    list->data = data+*i+8;
    info *current = list->infos;
    strcpyn(data+*i+8, list->infos->infoId, 4);
    strcpyn(data+*i, list->list, 4);
    size_t j = 4;
    for (; j < (size_t) list->chunk_size;)
    {
        
        if (!list->data[j]) // word alignement
        {
            //printf("padding\n");
            j++;
            continue;
        }
        
        current->next = infoParser(list->data, &j);
        current = current->next;
    }
    *i += 8 + j;
    fileInfo *info = getFileInfo(list);
    printFileInfo(info);
    //freeList(list);
    free(info);
    return list;
}
// Creates a new node for the linked list with some data
info *infoParser(unsigned char *data, size_t *j)
{
    info *info = malloc(sizeof(struct info));
    info->next = 0;
    strcpyn(data+*j, info->infoId, 4);
    info->size = intConversionLE(data+*j+4);
    info->data = (char *) data+ *j+ 8;
    //printf("%d %d\n", info->size, strlen(info->data));
    *j += 8 + info->size;
    return info;
}
// Transforms a list of info into an object with clear attributes
fileInfo *getFileInfo(list *list)
{
    fileInfo *f = calloc(1, sizeof(fileInfo));
    if (list == NULL || list->infos->next == NULL)
        return f;
    info *current = list->infos->next;
    for (;current; current = current->next)
    {
        switch (uintConversionBE((unsigned char *)current->infoId))
        {
        case IARL:
            f->archival = current->data;
            break;
        case IART:
            f->artists = current->data;
            break;
        case ICMS:
            f->commissioned = current->data;
            break;
        case ICMT:
            f->comments = current->data;
            break;
        case ICOP:
            f->copyrights = current->data;
            break;
        case ICRD:
            f->creationDate = current->data;
            break;
        case IGNR:
            f->genre = current->data;
            break;
        case IKEY:
            f->keywords = current->data;
            break;
        case INAM:
            f->name = current->data;
            break;
        case ISFT:
            f->software = current->data;
            break;
        case ISRC:
            f->source = current->data;
            break;
        case IPRD:
            f->product = current->data;
            break;
        case IPRT:
            sscanf(current->data, "%d", &f->tracknb);
            break;
        case ISBJ:
            f->album = current->data;
            break;
        default:
            warnx("unknown attribute %s %s", current->infoId, current->data);
            break;
        }
    }
    
    return f;
}

void freeList(list *l)
{
    freeInfo(l->infos);
    free(l);
}

void freeInfo(info *i)
{
    info *current = i;
    while(current)
    {
        info *next = current->next;
        free(current);
        current = next;
    }
}
// Standard printing for fileInfo
void printFileInfo(fileInfo *f)
{
    printf("====== FileInfo =======\n");
    printf("Archival location: %s\n", !f->archival ? "Unkwown" : f->archival);
    printf("Artist(s): %s\n", f->artists ? f->artists : "Unkwown");
    printf("Copyrights: %s\n", f->copyrights ? f->copyrights : "Unkwown");
    printf("Keywords: %s\n", f->keywords ? f->keywords : "Unkwown");
    printf("Name: %s\n", f->name ? f->name : "Unkwown");
    printf("Genre: %s\n", f->genre ? f->genre : "Unknown");
    printf("Software: %s\n", f->software ? f->software : "Unkwown");
    printf("Source: %s\n", f->source ? f->source: "Unkwown");
    printf("Product: %s\n", f->product ? f->product : "Unkwown");
    printf("Album: %s\n", f->album ? f->album : "Unknown");
    printf("======    End   =======\n");
}