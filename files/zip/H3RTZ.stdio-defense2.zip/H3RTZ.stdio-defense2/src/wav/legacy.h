#ifndef LEGACY_H
#define LEGACY_H

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <err.h>
#include <sys/types.h>
#include <pulse/pulseaudio.h>
#include <pulse/simple.h>
#include <string.h>
#include <errno.h>
#include "../tools/conversion.h"
#include "wav.h"
// stardard 44 bytes wav header
struct wav_header
{
    // Part 1 : declaration as wave file
    char riff[4];//contains 4 bytes
    int fileSize; //contains 4 bytes
    char fileFormatId[4]; // contains 4 bytes

    // Part 2 :
    char fmt[4]; //format block id 4B
    int blocSize;

    short AudioFormat; //2B see enum compression_codes
    short channel; //2B

    int sampling_freq; // 4B
    int bitrate; //important 4B //number of bytes to read per sec
    short blocrate; //2B NbrCanaux * BitsPerSample/8
    short samplerate; //2B //8-16-24 bits

    char data[4]; // entry point for real data boi
    int data_bytes; //number of bytes in the data chunk
};


//most common compression modes for wav
enum compression_codes
{
    any = 0, //if the format doesn't need this info
    PCM = 1, //used
    ADPCM = 2,
    PCM_float = 3, //might be used for 32-64bits formats
    alaw = 6,
    Amu_law = 7,
    IMA_ADPCM = 17,
    Yamaha = 20,
    GSM = 49,
    G721 = 64,
    MPEG = 80, // used
    WaveFormatExtensible = 65534, //used
    Experimental = 65536,
};
// channels for audio
enum channels
{
    unknwon,
    mono,
    stereo,
    triple,
    four,
    five,
    six,
};
// data_type: how to handle the data: only 8 bit is unsigned
enum data_type
{
    unsigned_data8 = 8,
    signed_data12 = 12,
    signed_data16 = 16,
    signed_data24 = 24,
    signed_data32 = 32,
    signed_data64 = 64,
};

struct wav_header *read_header_wav(char *path);
void print_header(struct wav_header *h);
char *audio_format(enum compression_codes code);
char *channel_type(enum channels c);
pa_sample_spec headerToSpecsLegacy(struct wav_header *h);

#endif