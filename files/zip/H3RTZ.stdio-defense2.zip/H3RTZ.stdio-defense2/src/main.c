#include <stdio.h>
#include "./GUI/init.h"
#include "./wav/wav.h"
#include "./async/multiplayer.h"
#include "./wav/encode/encode.h"
#include "./mp3/psychoacoustics/psychoacoustic.h"
#include "./mp3/psychoacoustics/tests/test.h"
#define MP3 0

int main(int argc, char **argv)
{
    #if MP3
    //file *f = getData("./examples/8bitmono441.wav");
    //file *f = getData("./examples/02_tone.wav");
    file *f = getData("./examples/8b441.wav");
    wav *w = headerParser(f);
    int samples[1024];
    size_t m = 400;
    for (size_t i = 1024*(m-1); i < 1024*m; i++)
    {
      samples[i-1024*(m-1)] = w->data->chunk[i];
    }
    //psychoAcoustic1(samples, 8);
    freeWav(w);
    freeFile(f);
    
    testFFT();
    checkTonal();
    testNoise();
    testDecimation();
    testMaskingTonal();
    testMaskingNoise();
    testGlobalMasking();
    testMinMasking();
    
    #else
    if (argc == 1 || !argv)
    {
      init_interface();
      return 0;
    }
    long mode = atol(argv[1]);
    switch (mode)
    {
      case 1:
        init_interface();
        break;
      case 2:
        player(argc-1, &argv[1]);
        break;
      case 3:
        wav_encode(argv[2]);
        break;
      case 4:
        testFFT();
        checkTonal();
        testNoise();
        testDecimation();
        testMaskingTonal();
        testMaskingNoise();
        testGlobalMasking();
        testMinMasking();
        break;
      default:
        printf("Invalid argument, exiting...");
        break;
    }
    #endif
    return 0;
}
