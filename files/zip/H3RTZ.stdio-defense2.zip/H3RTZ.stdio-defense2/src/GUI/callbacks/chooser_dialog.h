#ifndef CHOOSER_DIALOG_H
#define CHOOSER_DIALOG_H

#include "../init.h"

void chooser_dialog(GtkWidget *widget, gpointer userdata);

#endif
