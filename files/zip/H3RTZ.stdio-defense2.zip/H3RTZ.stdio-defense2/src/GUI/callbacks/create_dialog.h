#ifndef CREATE_DIALOG_H
#define CREATE_DIALOG_H

#include "../init.h"
void dialog_init(GtkWidget *widget, gpointer userdata);
void dialog_close(GtkWidget *widget, gpointer userdata);

#endif
