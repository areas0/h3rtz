#include "playlist.h"

void append(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    GtkTreeIter iter;
    gchar *str = player->ui.name_chooser;
    player->ui.dialog_list_store = GTK_LIST_STORE(
        gtk_tree_view_get_model(player->ui.dialog_tree));
    tuple data = ParseTrack(str);
    if (!data.a || !data.b)
        return;
    wav *w = data.b;
    fileInfo *f = getFileInfo(w->list);
    char *entry = f->name ? f->name : str;
    free(f);
    pthread_mutex_lock(&playlist_l);
    ssize_t find_index = findIndex(player, entry);
    if (find_index != -1 && (size_t) find_index <= player->playlist->nb_el-1)
    {
        freeWav(data.b);
        freeFile(data.a);
        pthread_mutex_unlock(&playlist_l);
        return;
    }
    player->playlist->f[player->playlist->nb_el] = data.a;
    player->playlist->w[player->playlist->nb_el] = data.b;
    player->playlist->nb_el++;
    pthread_mutex_unlock(&playlist_l);
    gtk_list_store_append(player->ui.dialog_list_store, &iter);
    gtk_list_store_set(player->ui.dialog_list_store, &iter, LIST_ITEM, entry, -1);
}

void remove_item(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    GtkTreeIter iter;
    GtkTreeModel *model;

    model = gtk_tree_view_get_model(player->ui.dialog_tree);
    player->ui.select = gtk_tree_view_get_selection(player->ui.dialog_tree);

    if (gtk_tree_model_get_iter_first(model, &iter) == FALSE)
        return;

    gboolean found = gtk_tree_selection_get_selected(player->ui.select,
                                                     &model, &iter);
    if (!found)
        return;
    GtkTreeIter iter_bis;
    if (gtk_tree_model_get_iter_first(model, &iter_bis) == FALSE)
        return;
    gchar *key;
    gtk_tree_model_get(model, &iter, LIST_ITEM, &key, -1);
    ssize_t l = findIndex(player, key);
    if (l == -1)
        return;
    size_t i = (size_t)l;
    if (i >= player->playlist->nb_el)
        return;
    if (i == player->playlist->index)
    {
        Pause(player->player);
        terminateStream(player->player);
    }
    removeTrackAtIndex(player->playlist, i);
    gtk_list_store_remove(player->ui.dialog_list_store, &iter);
}

ssize_t findIndex(gtk_player *player, gchar *key)
{
    GtkTreeIter iter;
    GtkTreeModel *model;

    model = gtk_tree_view_get_model(player->ui.dialog_tree);
    if (gtk_tree_model_get_iter_first(model, &iter) == FALSE)
        return -1;
    ssize_t i = -1;
    do
    {
        i++;
        gchar *buffer;
        gtk_tree_model_get(model, &iter, LIST_ITEM, &buffer, -1);
        if (!strcmp(key, buffer))
        {
            return i;
        }
    } while (gtk_tree_model_iter_next(model, &iter) &&
             (size_t)i < player->playlist->nb_el);
    return i+1;
}

void remove_all(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    GtkTreeModel *model;
    GtkTreeIter iter;

    model = gtk_tree_view_get_model(player->ui.dialog_tree);

    if (gtk_tree_model_get_iter_first(model, &iter) == FALSE)
    {
        return;
    }

    gtk_list_store_clear(player->ui.dialog_list_store);
    if (player->player->pa_state == ACTIVE)
    {
        Pause(player->player);
        terminateStream(player->player);
    }
    cleanPlaylist(player->playlist);
}

void init_list(gpointer userdata)
{
    gtk_player *player = userdata;
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Playlist",
                                                      renderer, "text",
                                                      LIST_ITEM, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(player->ui.dialog_tree), column);

    player->ui.dialog_list_store = gtk_list_store_new(N_COLUMNS, G_TYPE_STRING);

    gtk_tree_view_set_model(GTK_TREE_VIEW(player->ui.dialog_tree),
                            GTK_TREE_MODEL(player->ui.dialog_list_store));

    g_object_unref(player->ui.dialog_list_store);
}

void itemSelection(GtkTreeView *tree_view,
                   GtkTreePath *path,
                   GtkTreeViewColumn *column,
                   gpointer userdata)
{
    gtk_player *player = userdata;
    assert(path);
    assert(column);
    GtkTreeIter iter;
    GtkTreeModel *model;

    model = gtk_tree_view_get_model(tree_view);
    player->ui.select = gtk_tree_view_get_selection(tree_view);

    if (gtk_tree_model_get_iter_first(model, &iter) == FALSE)
        return;

    gboolean found = gtk_tree_selection_get_selected(player->ui.select, &model, &iter);
    if (!found)
        return;
    GtkTreeIter iter_bis;
    if (gtk_tree_model_get_iter_first(model, &iter_bis) == FALSE)
        return;
    gchar *key;
    gtk_tree_model_get(model, &iter, LIST_ITEM, &key, -1);
    ssize_t l = findIndex(player, key);
    if (l == -1)
        return;
    size_t i = (size_t)l;
    if (i >= player->playlist->nb_el || i == player->playlist->index)
        return;
    Pause(player->player);
    terminateStream(player->player);
    player->playlist->index = i;
    playTrack(player);
}