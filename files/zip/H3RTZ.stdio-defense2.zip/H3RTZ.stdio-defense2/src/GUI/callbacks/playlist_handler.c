#include "playlist_handler.h"

pthread_mutex_t playlist_l = PTHREAD_MUTEX_INITIALIZER;
void initStaticPlaylist(playlist_t *playlist)
{
    if (!playlist)
        errx(EXIT_FAILURE, "dafuq");
    pthread_mutex_lock(&playlist_l);
    // PLAYLIST ALLOCATION
    playlist->threads = calloc(DEFAULT_PLAYLIST_SIZE, sizeof(pthread_t));
    playlist->w = calloc(DEFAULT_PLAYLIST_SIZE, sizeof(wav));
    playlist->f = calloc(DEFAULT_PLAYLIST_SIZE, sizeof(file));
    playlist->size = DEFAULT_PLAYLIST_SIZE;
    pthread_mutex_unlock(&playlist_l);
}

void *parseTrackT(void *userdata)
{
    tuple *t = userdata;
    playlist_t *p = t->a;
    char *path = t->b;
    warnx("parseTrackT: parsing track... size: %zu nb_el: %zu", p->size, p->nb_el);
    tuple data = ParseTrack(path);
    pthread_mutex_lock(&playlist_l);
    if (p->nb_el == p->size)
        doubleCapacityPlaylist(p);
    p->f[p->nb_el] = data.a;
    p->w[p->nb_el] = data.b;
    p->nb_el++;
    pthread_mutex_unlock(&playlist_l);
    warnx("parseTrackT: parsed track... size: %zu nb_el: %zu", p->size, p->nb_el);
    free(t->b);
    free(t);
    return NULL;
}

void doubleCapacityPlaylist(playlist_t *p)
{
    warnx("doublePlaylist: reallocating playlist");
    p->size *= 2;
    p->f = realloc(p->f, sizeof(file) * p->size);
    p->w = realloc(p->w, sizeof(wav) * p->size);
    p->threads = realloc(p->threads, sizeof(pthread_t) * p->size);
}

void removeTrackAtIndex(playlist_t *p, size_t index)
{
    pthread_mutex_lock(&playlist_l);
    if (index == 0 && p->nb_el == 1)
    {
        freeWav(p->w[index]);
        freeFile(p->f[index]);
        memset(p->threads, 0, sizeof(pthread_t) * p->size);
        memset(p->w, 0, sizeof(wav) * p->size);
        memset(p->f, 0, sizeof(file) * p->size);
        p->nb_el--;
        pthread_mutex_unlock(&playlist_l);
        return;
    }
    if (p->index && p->index >= index)
        p->index--;
    if (p->index && p->index == index)
        p->index = p->index % (p->nb_el-1);
    if (index >= p->nb_el)
    {
        pthread_mutex_unlock(&playlist_l);
        return;
    }
    p->threads[index] = 0;
    freeWav(p->w[index]);
    freeFile(p->f[index]);
    for (size_t i = index; i < p->nb_el; i++)
    {
        p->threads[i] = p->threads[i + 1];
        p->w[i] = p->w[i + 1];
        p->f[i] = p->f[i + 1];
    }
    p->w[p->nb_el] = 0;
    p->f[p->nb_el] = 0;
    p->nb_el--;
    pthread_mutex_unlock(&playlist_l);
}

void cleanPlaylist(playlist_t *p)
{
    pthread_mutex_lock(&playlist_l);
    for (size_t i = 0; i < p->nb_el; i++)
    {
        freeFile(p->f[i]);
        freeWav(p->w[i]);
    }
    p->nb_el = 0;
    p->index = 0;
    pthread_mutex_unlock(&playlist_l);
}

void freePlaylist(playlist_t *p)
{
    pthread_mutex_lock(&playlist_l);
    for (size_t i = 0; i < p->nb_el; i++)
    {
        freeFile(p->f[i]);
        freeWav(p->w[i]);
    }
    free(p->w);
    free(p->f);
    free(p->threads);
    free(p);
    pthread_mutex_unlock(&playlist_l);
}

void playTrack(gtk_player *player)
{
    pthread_mutex_lock(&playlist_l);
    warnx("%zu %zu", player->playlist->nb_el, player->playlist->index);
    if (player->playlist->nb_el == 0)
    {
        GtkWidget *image = gtk_image_new_from_file("./GUI/callbacks/icons/play.png");
        gtk_button_set_image(GTK_BUTTON(player->ui.play_pause), image);
        pthread_mutex_unlock(&playlist_l);
        return;
    }
    static int init = 0;
    on_pause(player);
    int code = terminateStream(player->player);
    if (code >= 0 && player->ui.ID)
        g_source_remove(player->ui.ID);
    //pthread_join(player->playlist->threads[player->playlist->index], NULL);
    //warnx("%zu %zu", player->playlist->index, player->playlist->nb_el);
    wav *w = player->playlist->w[player->playlist->index];
    file *f = player->playlist->f[player->playlist->index];
    changeTrackNoFree(player->player, w, f);

    changeTitle(player);
    genre(player);
    album(player);
    image(player);
    if (prepareStream(player->player) == -1)
        on_quit(NULL, player);

    if (!init)
    {
        init = 1;
        setDefaultVolume(player);
    }

    player->player->player->timing->current = 0;
    on_play(player);
    pthread_mutex_unlock(&playlist_l);
}

void incrementPosition(playlist_t *p)
{
    pthread_mutex_lock(&playlist_l);
    if (p->nb_el == 0)
    {
        pthread_mutex_unlock(&playlist_l);
        return;
    }
    if (p->index == 0 && p->nb_el == 0)
    {
        pthread_mutex_unlock(&playlist_l);
        return;
    }
    if (p->index == p->nb_el - 1)
        p->index = 0;
    else
        p->index++;
    pthread_mutex_unlock(&playlist_l);
}

void decrementPosition(playlist_t *p)
{
    pthread_mutex_lock(&playlist_l);
    if (p->nb_el == 0)
    {
        pthread_mutex_unlock(&playlist_l);
        return;
    }
    if (p->index == 0)
        p->index = p->nb_el - 1;
    else
        p->index--;
    pthread_mutex_unlock(&playlist_l);
}

void playPrevious(gtk_player *player)
{
    pthread_mutex_lock(&playlist_l);
    if (player->playlist->index == 0)
        player->playlist->index = player->playlist->nb_el - 1;
    pthread_mutex_unlock(&playlist_l);
}

void forward_cb(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    incrementPosition(player->playlist);
    playTrack(player);
}

void backward_cb(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    decrementPosition(player->playlist);
    playTrack(player);
}