#include "create_dialog.h"

void dialog_init(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    gtk_widget_show(player->dialog_create);
}

void dialog_close(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    gtk_widget_hide(player->dialog_create);
}

