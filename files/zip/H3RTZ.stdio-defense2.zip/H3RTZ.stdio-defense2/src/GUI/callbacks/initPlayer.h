#ifndef INITPLAYER_H
#define INITPLAYER_H

#include "../init.h"
// Plays the selected file with PulseAudio
// If a file is currently being played, switches track
// @param userdata : gtk_player expected
void on_choose_wav(GtkWidget *widget, gpointer userdata);

#endif