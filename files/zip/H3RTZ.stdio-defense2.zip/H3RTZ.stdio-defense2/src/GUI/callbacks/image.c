#include "image.h"

void image(gpointer userdata)
{
    gtk_player *player = userdata;
    fileType info;
    info = player->player->type;
    //For now, we'll see how to get mp3 pic song,
    //but lets just take care of WAv since there is no pic
    if(info == WAV_ORIGINAL)
    {
        player->ui.song_image = GTK_IMAGE(gtk_image_new_from_file("./icons/wav.jpg"));
        //printf("Pas MP3");
    }
    else
    {
        player->ui.song_image = GTK_IMAGE(gtk_image_new_from_file("./icons/mp3_default.png"));
        //printf("Pas Wav");
    }
}
