#ifndef ALBUM_H
#define ALBUM_H

#include "../init.h"

void album(gpointer userdata);

#endif
