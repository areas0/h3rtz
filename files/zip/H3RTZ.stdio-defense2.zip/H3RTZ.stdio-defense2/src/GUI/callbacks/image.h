#ifndef IMAGE_H
#define IMAGE_H
#include "../init.h"

void image(gpointer userdata);

#endif
