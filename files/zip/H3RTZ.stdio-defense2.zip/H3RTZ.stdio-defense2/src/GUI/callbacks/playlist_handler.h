#ifndef PLAYLIST_HANDLER_H
#define PLAYLIST_HANDLER_H

#include "../init.h"
void initStaticPlaylist(playlist_t *playlist);
void doubleCapacityPlaylist(playlist_t *p);
void *parseTrackT(void *userdata);
void freePlaylist(playlist_t *p);
void playTrack(gtk_player *player);
void decrementPosition(playlist_t *p);
void incrementPosition(playlist_t *p);
void playPrevious(gtk_player *player);
void forward_cb(GtkWidget *widget __attribute__((unused)), gpointer userdata);
void backward_cb(GtkWidget *widget __attribute__((unused)), gpointer userdata);
void removeTrackAtIndex(playlist_t *p, size_t index);
void cleanPlaylist(playlist_t *p);
#endif