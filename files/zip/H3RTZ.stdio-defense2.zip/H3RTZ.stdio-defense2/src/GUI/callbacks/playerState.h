#ifndef PLAYERSTATE_H
#define PLAYERSTATE_H

#include "../init.h"

extern pthread_mutex_t playlist_l;
// Sub callback function to play a track
void on_play(gtk_player *g);
// sub callback function to pause a track
void on_pause(gtk_player *g);
// Entry callback to toggle UI elements & pause/play audio
// @param userdata: a gtk_player
void toggle(GtkWidget *widget, gpointer userdata);
#endif
