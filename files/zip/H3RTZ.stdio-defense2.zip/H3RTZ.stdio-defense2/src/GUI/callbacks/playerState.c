#include "playerState.h"
#include "progress.h"
#include "slider.h"

// Callback to toggle play and pause button
// it will call the pulseaudio callbacks to do the rest
void toggle(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    switch (player->player->player->status)
    {
    case PLAYING:
        on_pause(player);
        break;
    case PAUSED:
        on_play(player);
        break;
    case NOT_READY:
        // start playing the playlist
        playTrack(player);
        break;
    default:
        break;
    }
}

void on_play(gtk_player *g)
{
    if (g->player->player->status != PAUSED)
        return;
    if (!g->player->player->stream)
        return;
    GtkWidget *image = gtk_image_new_from_file("./GUI/callbacks/icons/pause.png");
    gtk_button_set_image(GTK_BUTTON(g->ui.play_pause), image);
    play(g->player);
    g->ui.ID = g_timeout_add(100, slider, g);
    return;
}

void on_pause(gtk_player *g)
{
    if (g->player->player->status != PLAYING)
        return;
    GtkWidget *image = gtk_image_new_from_file("./GUI/callbacks/icons/play.png");
    gtk_button_set_image(GTK_BUTTON(g->ui.play_pause), image);
    Pause(g->player);
    if (g->ui.ID)
        g_source_remove(g->ui.ID);
    g->ui.ID = 0;
    return;
}
