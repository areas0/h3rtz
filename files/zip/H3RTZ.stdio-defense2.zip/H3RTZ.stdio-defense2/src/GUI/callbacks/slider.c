#include "slider.h"

// this function will update every few seconds the progress bar
const double power = (double) 0xf4240;
int slider(void *userdata)
{
  gtk_player *player = userdata;
  pa_player *pulseAudio = player->player;
  // Total duration computation: nb bytes in file / bitrate
  if (player->player->pa_state == TERMINATED)
  {
    gdouble max = gtk_adjustment_get_upper(player->ui.adjustment);
    // 100% completion for interruption 
    gtk_adjustment_set_value(player->ui.adjustment, max);
    // disables callback
    g_source_remove(player->ui.ID);
    player->ui.ID = 0;
    terminateStream(player->player);
    GtkWidget *image = gtk_image_new_from_file("./GUI/callbacks/icons/play.png");
    gtk_button_set_image (GTK_BUTTON(player->ui.play_pause), image);
    incrementPosition(player->playlist);
    playTrack(player);
    return FALSE;
  }
  double duration = (double)pulseAudio->player->info->data->data_bytes /
                    (double)pulseAudio->player->info->fmt->bitrate;
  gtk_adjustment_set_upper (player->ui.adjustment,duration);
  // updates latency from pulseAudio
  updateLatency(pulseAudio);
  // computation zone
  double timing = pulseAudio->player->timing->time;
  // converts to microseconds
  timing *= power;
  // removes latency
  double wLatency = timing - (double)*(pulseAudio->player->timing->latency);
  //ratio = ((wLatency / power)* 100) / duration;
  double current = wLatency/power;
  player->player->player->timing->current = current;
  // update the progress bar
  gtk_adjustment_set_value (player->ui.adjustment, current);
  gtk_scale_set_draw_value(player->ui.slider, TRUE);
  return TRUE;
}
// Currently locks the position in the UI of the slider
void changePosition(GtkWidget *widget, gpointer userdata)
{
  gtk_player *player = userdata;
  assert(widget);
  if (player->player->pa_state == ACTIVE)
  {
    gdouble value = gtk_adjustment_get_value(player->ui.adjustment);
    if (value != player->player->player->timing->current)
    {
      double new = value * player->player->player->info->fmt->bitrate;
      size_t offset = (size_t) new;
      on_pause(player);
      relative(player->player, offset, 0);
      on_play(player);
    }
    return;
  }
  if (player->player->pa_state == TERMINATED)
  {
    // getting the current value
    gdouble value = gtk_adjustment_get_value(player->ui.adjustment);
    // if there's nothing to play, we lock the slider and do nothing
    if(player->playlist->nb_el == 0)
    {
      gdouble max = gtk_adjustment_get_upper(player->ui.adjustment);
      gtk_adjustment_set_value(player->ui.adjustment, max);
      return;
    }
    // checking if it differs with the latest one in memory
    if (value != player->player->player->timing->current && !player->ui.ID)
    {
      // compute the new offset value:
      // value is in seconds (double) multiplied by the bitrate
      // bits per second of audio
      double new = value * player->player->player->info->fmt->bitrate;
      size_t offset = (size_t) new;
      // There is no current stream to play the audio, we need to re-create one
      if (prepareStream(player->player) == -1)
        errx(EXIT_FAILURE, "Failed to init stream");
      on_pause(player);
      relative(player->player, offset, 0);
      on_play(player);
    }
    return;
  }
  // The mainloop is ready but no audio has been played yet, we can keep the
  // slider at 0 position
  if (player->player->pa_state == READY)
  {
    gtk_adjustment_set_value(player->ui.adjustment, 0.0);
    return;
  }
  // default case, we freeze the slider
  gdouble value = gtk_adjustment_get_value(player->ui.adjustment);
  if (value != player->player->player->timing->current)
  {
    gtk_adjustment_set_value(player->ui.adjustment, 
    player->player->player->timing->current);
  }
  printPulseState(player->player);
}

void *seeker(void *userdata)
{
  gtk_player *player = userdata;
  assert(player);
  return NULL;
}