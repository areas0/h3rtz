#ifndef INIT_H
#define INIT_H

#include <stdlib.h>
#include <stdio.h>
#include <gtk/gtk.h>
#include "../async/multiplayer.h"
#include <sys/types.h>

#define DEFAULT_PLAYLIST_SIZE 20
typedef struct playlist_t
{
    pthread_t *threads; // check if the task is finished
    wav **w; // headers
    file **f; // files IO
    size_t nb_el; // nb of elements currently
    size_t size; // total size of the list in memory
    size_t index;
} playlist_t;

typedef struct UserInterface
{
    GtkWindow* window;              // Main window
    GtkButton* play_pause;        // Start button
    guint ID;
    GtkVolumeButton *volume;
    GtkScale *slider;
    GtkAdjustment *adjustment;
    char *name_chooser; //for the dialog box
    GtkListStore *dialog_list_store;
    GtkTreeView *dialog_tree;
    GtkTreeSelection *select;
    GtkLabel *name;
    GtkLabel *genre;
    GtkLabel *album;
    GtkImage *song_image;
    GtkFileChooser *audio_chooser;
} UserInterface;


typedef struct gtk_player
{
    char *filename;
    pa_player *player;
    file *data;
    UserInterface ui;
    playlist_t *playlist;
} gtk_player;


#include "./callbacks/exit.h"
#include "./callbacks/initPlayer.h"
#include "./callbacks/playerState.h"
#include "./callbacks/title.h"
#include "./callbacks/progress.h"
#include "./callbacks/slider.h"
#include "./callbacks/cvolume.h"
#include "./callbacks/genre.h"
#include "./callbacks/album.h"
#include "./callbacks/image.h"
#include "./callbacks/create_dialog.h"
#include "./callbacks/chooser_dialog.h"
#include "./callbacks/playlist.h"
#include "./callbacks/playlist_handler.h"

void init_interface(void);
#endif
