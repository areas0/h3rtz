#include "init.h"

//Macro to check
#define CHECK(button)                                     \
    if (button == NULL)                                   \
    {                                                     \
        fprintf(stderr, "Error: can't get the button\n"); \
        exit(EXIT_FAILURE);                               \
    }
GtkWindow *window;
gchar *path; //the path to the audio file look at fct audio_chooser

void init_interface(void)
{
    GtkBuilder *builder;

    //Initialize GTK
    gtk_init(NULL, NULL);

    // Establish contact with glade xml code used to adjust widget setting
    builder = gtk_builder_new();
    if (gtk_builder_add_from_file(builder, "stdio.glade", NULL) == 0)
    {
        fprintf(stderr, "Error: can't open the XML file\n");
        exit(EXIT_FAILURE);
    }

    // Sets the background color of the window
    //GdkColor window_color;
    //window_color.red = 0x6969;
    //window_color.green = 0x6969;
    //window_color.blue = 0x6969;

    // Changing the background color of the window
    //gtk_widget_modify_bg(window, GTK_STATE_NORMAL, &window_color);

    //create window using the builder
    window = GTK_WINDOW(gtk_builder_get_object(builder, "window"));

    GtkFileChooserButton *audio_chooser_button = GTK_FILE_CHOOSER_BUTTON(
        gtk_builder_get_object(builder, "audio_chooser"));
    CHECK(audio_chooser_button);

    GtkFileChooser *audio_chooser = GTK_FILE_CHOOSER(
        gtk_builder_get_object(builder, "audio_chooser"));
    CHECK(audio_chooser);

    GtkButton *play_pause = GTK_BUTTON(
        gtk_builder_get_object(builder, "play_pause"));
    CHECK(play_pause);

    GtkButton *forward = GTK_BUTTON(
        gtk_builder_get_object(builder, "next"));
    CHECK(forward);

    GtkButton *backward = GTK_BUTTON(
        gtk_builder_get_object(builder, "previous"));
    CHECK(backward);

    GtkVolumeButton *volume = GTK_VOLUME_BUTTON(
        gtk_builder_get_object(builder, "volume"));
    CHECK(volume);

    GtkScale *slider = GTK_SCALE(
        gtk_builder_get_object(builder, "slider"));
    CHECK(slider);

    GtkAdjustment *adjustment1 = GTK_ADJUSTMENT(
        gtk_builder_get_object(builder, "adjustment1"));
    CHECK(adjustment1);

    GtkLabel *name = GTK_LABEL(
        gtk_builder_get_object(builder, "name"));
    CHECK(name);

    GtkLabel *genre = GTK_LABEL(
        gtk_builder_get_object(builder, "genre"));
    CHECK(genre);

    GtkLabel *album = GTK_LABEL(
        gtk_builder_get_object(builder, "album"));
    CHECK(album);

    GtkListStore *dialog_list_store = GTK_LIST_STORE(
        gtk_builder_get_object(builder, "dialog_list_store"));
    CHECK(dialog_list_store);

    GtkTreeView *dialog_tree = GTK_TREE_VIEW(
        gtk_builder_get_object(builder, "dialog_tree"));
    CHECK(dialog_tree);

    GtkTreeSelection *select = GTK_TREE_SELECTION(
        gtk_builder_get_object(builder, "select"));
    CHECK(select);

    GtkButton *dialog_remove = GTK_BUTTON(
        gtk_builder_get_object(builder, "dialog_remove"));
    if (dialog_remove == NULL)
    {
        fprintf(stderr, "Error: can't get the button dialog_remove\n");
        exit(EXIT_FAILURE);
    }

    GtkButton *dialog_remove_all = GTK_BUTTON(
        gtk_builder_get_object(builder, "dialog_remove_all"));
    if (dialog_remove_all == NULL)
    {
        fprintf(stderr, "Error: can't get the button dialog_remove_all\n");
        exit(EXIT_FAILURE);
    }

    GtkButton *dialog_add = GTK_BUTTON(
        gtk_builder_get_object(builder, "dialog_add"));
    if (dialog_add == NULL)
    {
        fprintf(stderr, "Error: can't get the button dialog_add\n");
        exit(EXIT_FAILURE);
    }

    GtkWidget *window1 = GTK_WIDGET(
        gtk_builder_get_object(builder, "window1"));
    if (window1 == NULL)
    {
        fprintf(stderr, "Error: can't get the button window1\n");
        exit(EXIT_FAILURE);
    }


    gtk_player player = {
        .data = NULL,
        .filename = NULL,
        .player = NULL,
        .ui =
            {
                .window = window,
                .play_pause = play_pause,
                .volume = volume,
                .ID = 0,
                .slider = slider,
                .adjustment = adjustment1,
                .name_chooser = NULL,
                .dialog_list_store = dialog_list_store,
                .dialog_tree = dialog_tree,
                .select = select,
                .name = name,
                .genre = genre,
                .album = album,
                .audio_chooser = audio_chooser,
            },
        .playlist = calloc(1, sizeof(playlist_t)),
    };

    if (initPulsePlayer(&(player.player)) == -1)
        errx(EXIT_FAILURE, "Failed to initialize the player, \
check that PulseAudio is started and running...");
    if (init_player(player.player) == -1)
        errx(EXIT_FAILURE, "Failed to initialize the player, \
check that PulseAudio is started and running...");
    // inits a playlist
    initStaticPlaylist(player.playlist);
    init_list(&player);
    //Connect event handlers
    //Connect event handlers
    gtk_builder_connect_signals(builder, NULL);
    g_signal_connect(audio_chooser_button, "file_set", G_CALLBACK(on_choose_wav), &player);
    g_signal_connect(play_pause, "clicked", G_CALLBACK(toggle), &player);
    g_signal_connect(window, "delete_event", G_CALLBACK(gtk_main_quit), &player);
    g_signal_connect(volume, "value-changed", G_CALLBACK(cvolume), &player);
    g_signal_connect(adjustment1, "value-changed", G_CALLBACK(changePosition),
                     &player);
    g_signal_connect(dialog_add, "clicked", G_CALLBACK(append), &player);
    g_signal_connect(dialog_remove, "clicked", G_CALLBACK(remove_item), &player);
    g_signal_connect(dialog_remove_all, "clicked", G_CALLBACK(remove_all), &player);
    g_signal_connect(forward, "clicked", G_CALLBACK(forward_cb), &player);
    g_signal_connect(backward, "clicked", G_CALLBACK(backward_cb), &player);
    // connects the signal for double click event
    g_signal_connect(player.ui.dialog_tree, "row-activated", G_CALLBACK(itemSelection), &player);
    //g_signal_connect(slider, "format_value", G_CALLBACK(slider1), &player);
    gtk_widget_set_size_request(GTK_WIDGET(window), 820, 920);
    gtk_widget_set_size_request(GTK_WIDGET(window1), 100 , 200);
    gtk_window_set_resizable(window, TRUE);
    GtkWidget *image = gtk_image_new_from_file("./GUI/callbacks/icons/play.png");
    gtk_button_set_image(GTK_BUTTON(player.ui.play_pause), image);
    gtk_widget_show(GTK_WIDGET(window));
    //Execute loop GTK
    gtk_main();
    // cleans up PulseAudio stuff with playlist
    Pause(player.player);
    terminateStream(player.player);
    freePlaylist(player.playlist);
    player.player->player->info = 0;
    player.player->player->track = 0;
    pa_context_unref(player.player->pulseAudio->context);
    pa_threaded_mainloop_stop(player.player->pulseAudio->loop);
    pa_threaded_mainloop_free(player.player->pulseAudio->loop);
    freePulsePlayer(player.player);

    g_object_unref(G_OBJECT(builder));
    gtk_window_close(window);
    gtk_widget_destroy(GTK_WIDGET(window));
    gtk_widget_destroy(GTK_WIDGET(audio_chooser_button));
}
