#define _GNU_SOURCE
#include <stdio.h>
#include "test.h"

static const char *path = "./examples/8b441.wav";
static const char *path_FFT = "./mp3/psychoacoustics/tests/fft.txt";
void testFFT(void)
{
    printf("==== Testing FFT ====\n");
    file *f = getData((char *)path);
    wav *w = headerParser(f);
    int samples[NB_SAMPLES];
    size_t m = 125;
    for (size_t i = NB_SAMPLES*(m-1); i < NB_SAMPLES*m; i++)
    {
      samples[i-NB_SAMPLES*(m-1)] = w->data->chunk[i];
    }
    long double *norm = normalizeInput(samples, NB_SAMPLES, 8);
    long double *SPL = getSPL(norm);
    long double *check = loadFFT();
    for (size_t i = 0; i < 512; i++)
    {
        assert(SPL[i] - check[i] < 1e-5);
    }
    freeWav(w);
    freeFile(f);
    free(SPL);
    free(norm);
    free(check);
    printf("==== Passed FFT ====\n");
}

long double *loadFFT(void)
{
    FILE *f = fopen(path_FFT, "r");
    long double *data = calloc(HALF, sizeof(long double));
    int r;
    size_t len = 0;
    char *buffer = NULL;
    size_t i = 0;
    while ( (r = getline(&buffer, &len, f)) != -1)
    {
        sscanf(buffer, "%Lf", &(data[i]));
        i++;
    }
    free(buffer);
    fclose(f);
    return data;
}

void checkTonal(void)
{
    printf("==== Testing TONAL COMPONENTS ====\n");
    long double *SPL = loadFFT();
    tonalComponents *tonals = findTonalComponents(SPL);
    tonalComponents *verif = loadTonalComponents("./mp3/psychoacoustics/\
tests/tonal.txt");
    size_t tonal_nb = 0;
    for (size_t i = 0; i < HALF; i++)
    {
        assert(tonals->flags[i] == verif->flags[i]);
        assert(tonals->SPL[i] - verif->SPL[i] < 1e-9);
        if (tonals->flags[i] == TONAL)
        {
            assert(tonals->tonals->data[tonal_nb] == verif->tonals->data[tonal_nb]);
            tonal_nb++;
        }
    }
    assert(tonal_nb == verif->tonals->nb_el);
    freeTonalComponents(tonals);
    freeTonalComponents(verif);
    free(SPL);
    printf("==== Passed TONAL COMPONENTS ====\n");
}

const char *path_tonal = "./mp3/psychoacoustics/tests/tonal.txt";
const char *path_noise = "./mp3/psychoacoustics/tests/noise.txt";
void testNoise(void)
{
    printf("==== Testing NON-TONAL COMPONENTS ====\n");
    tonalComponents *tonals = loadTonalComponents("./mp3/psychoacoustics/\
tests/tonal.txt");
    crit_table *t = generateTable(44100);
    band_table tables = associateBandToTable(t);
    findNonTonalComponents(tonals,t, tables.t, tables.associated);
    tonalComponents *expected = loadTonalComponents("./mp3/psychoacoustics/\
tests/noise.txt");
    size_t noise_nb = 0;
    //printStaticList(tonals->noises);
    //printStaticList(expected->noises);
    //printf("%zu %zu\n",tonals->noises->nb_el, expected->noises->nb_el);
    assert(tonals->noises->nb_el == expected->noises->nb_el);
    for (size_t i = 0; i < HALF; i++)
    {
        assert(tonals->flags[i] == expected->flags[i]);
        assert(tonals->SPL[i] - expected->SPL[i] < 1e-9);
        if (tonals->flags[i] == NOISE)
        {
            assert(ListContains(expected->noises, tonals->noises->data[noise_nb]));
            noise_nb++;
        }
    }
    assert(noise_nb == expected->noises->nb_el);
    freeTonalComponents(tonals);
    free(tables.associated);
    freeTonalComponents(expected);
    freeTable(t);
    freeTable(tables.t);
    printf("==== Passed NON-TONAL COMPONENTS ====\n");
}

void testDecimation(void)
{
    printf("==== Test DECIMATION ====\n");
    tonalComponents *tonals = loadTonalComponents("./mp3/psychoacoustics/\
tests/noise.txt");
    crit_table *t = generateTable(44100);
    band_table tables = associateBandToTable(t);
    decimateTonal(tonals, tables.t, tables.associated);
    decimateNoise(tonals, tables.t, tables.associated);
    tonalComponents *expected = loadTonalComponents("./mp3/psychoacoustics/\
tests/decimation.txt");
    size_t noise_nb = 0;
    size_t tonal_nb = 0;
    for (size_t i = 0; i < HALF; i++)
    {
        assert(tonals->flags[i] == expected->flags[i]);
        assert(tonals->SPL[i] - expected->SPL[i] < 1e-9);
        if (tonals->flags[i] == NOISE)
        {
            assert(ListContains(expected->noises, tonals->noises->data[noise_nb]));
            noise_nb++;
        }
        else if (tonals->flags[i] == TONAL)
        {
            assert(ListContains(expected->tonals, tonals->tonals->data[tonal_nb]));
            tonal_nb++;
        }
    }
    assert(noise_nb == expected->noises->nb_el);
    assert(tonal_nb == expected->tonals->nb_el);
    freeTonalComponents(tonals);
    free(tables.associated);
    freeTonalComponents(expected);
    freeTable(t);
    freeTable(tables.t);
    printf("==== PASSED DECIMATION ====\n");
}

tonalComponents *loadTonalComponents(char *path)
{
    tonalComponents *t = calloc(1, sizeof(tonalComponents));
    t->flags = calloc(HALF, sizeof(size_t));
    t->SPL = calloc(HALF, sizeof(long double));
    t->tonals = initStaticList();
    t->noises = initStaticList();
    FILE *f = fopen(path, "r");
    int r;
    size_t len = 0;
    char *buffer = NULL;
    size_t i = 0;
    while ( (r = getline(&buffer, &len, f)) != -1)
    {
        sscanf(buffer, "%Lf %u", &(t->SPL[i]), &(t->flags[i]));
        if (t->flags[i] == TONAL)
            appendStaticList(t->tonals, i);
        else if (t->flags[i] == NOISE)
            appendStaticList(t->noises, i);
        i++;
    }
    free(buffer);
    fclose(f);
    return t;
}

void testMaskingTonal(void)
{
    printf("==== Test Masking TONAL====\n");
    tonalComponents *tonals = loadTonalComponents("./mp3/psychoacoustics/\
tests/decimation.txt");
    long double *original_SPL = loadFFT();
    static_list_f **expected = loadDoubleList("./mp3/psychoacoustics/\
tests/masks_tonal.txt");
    crit_table *t = generateTable(44100);
    band_table tables = associateBandToTable(t);
    static_list_f **result = getMaskTonal(tonals, original_SPL, tables);
    for (size_t i = 0; i < tables.t->size; i++)
    {
        assert(result[i]->nb_el == expected[i]->nb_el);
        for (size_t j = 0; j < result[i]->nb_el; j++)
        {
            assert(result[i]->data[j] - expected[i]->data[j] < 1e-4);
        }
    }
    freeTonalComponents(tonals);
    freeTable(t);
    free(tables.associated);
    free(original_SPL);
    for (size_t i = 0; i < tables.t->size; i++)
    {
        freeStaticListF(result[i]);
        freeStaticListF(expected[i]);
    }
    freeTable(tables.t);
    free(result);
    free(expected);
    printf("==== Passed Masking TONAL====\n");
}

void testMaskingNoise(void)
{
    printf("==== Test Masking NON-TONAL====\n");
    tonalComponents *tonals = loadTonalComponents("./mp3/psychoacoustics/\
tests/decimation.txt");
    long double *original_SPL = loadFFT();
    static_list_f **expected = loadDoubleList("./mp3/psychoacoustics/\
tests/masks_noise.txt");
    crit_table *t = generateTable(44100);
    band_table tables = associateBandToTable(t);
    static_list_f **result = getMaskNoise(tonals, original_SPL, tables);
    for (size_t i = 0; i < tables.t->size; i++)
    {
        assert(result[i]->nb_el == expected[i]->nb_el);
        for (size_t j = 0; j < result[i]->nb_el; j++)
        {
            assert(result[i]->data[j] - expected[i]->data[j] < 1e-4);
        }
    }  
    freeTonalComponents(tonals);
    freeTable(t);
    free(tables.associated);
    free(original_SPL);
    for (size_t i = 0; i < tables.t->size; i++)
    {
        freeStaticListF(result[i]);
        freeStaticListF(expected[i]);
    }
    freeTable(tables.t);
    free(result);
    free(expected);
    printf("==== Passed Masking NON-TONAL====\n");
}

static_list_f **loadDoubleList(char *path)
{
    FILE *f = fopen(path, "r");
    int r;
    size_t len = 0;
    char *buffer = NULL;
    r = getline(&buffer, &len, f);
    if (r == -1)
        return NULL;
    size_t size;
    sscanf(buffer, "%zu", &size);
    static_list_f **result = malloc(size*sizeof(static_list_f));
    result[0] = initStaticListF();
    size_t index = 0;
    while ( (r = getline(&buffer, &len, f)) != -1)
    {
        if (buffer[0] == '*')
        {
            index++;
            if (index < size)
                result[index] = initStaticListF();
            else
                break;
            continue;
        }
        long double value;
        sscanf(buffer, "%Lf", &value);
        appendStaticListF(result[index], value);
    }
    free(buffer);
    return result;
}

void testGlobalMasking(void)
{
    printf("==== Test GLOBAL MASK====\n");
    static_list_f **masks_tonal = loadDoubleList("./mp3/psychoacoustics/\
tests/masks_tonal.txt");
    static_list_f **masks_noise = loadDoubleList("./mp3/psychoacoustics/\
tests/masks_noise.txt");
    crit_table *t = generateTable(44100);
    band_table tables = associateBandToTable(t);
    static_list_f *result = getGlobalMasks(masks_tonal, masks_noise,tables.t, tables.t->size);
    static_list_f *expected = loadListFloat("./mp3/psychoacoustics/\
tests/global_masks.txt");
    assert(result->nb_el == expected->nb_el);
    for (size_t i = 0; i < result->nb_el; i++)
    {
        assert(result->data[i] - expected->data[i] < 1e-6);
    }

    freeTable(t);
    free(tables.associated);
    freeStaticListF(result);
    freeStaticListF(expected);
    for (size_t i = 0; i < tables.t->size; i++)
    {
        freeStaticListF(masks_tonal[i]);
        freeStaticListF(masks_noise[i]);
    }
    free(masks_noise);
    free(masks_tonal);
    freeTable(tables.t);
    printf("==== Passed GLOBAL MASK====\n");
}

static_list_f *loadListFloat(char *path)
{
    static_list_f *res = initStaticListF();
    FILE *f = fopen(path, "r");
    int r;
    size_t len = 0;
    char *buffer = NULL;
    while ( (r = getline(&buffer, &len, f)) != -1)
    {
        long double value;
        sscanf(buffer, "%Lf", &value);
        appendStaticListF(res, value);
    }
    free(buffer);
    return res;
}

void testMinMasking(void)
{
    printf("==== Test MIN MASK====\n");
    static_list_f *global = loadListFloat("./mp3/psychoacoustics/\
tests/global_masks.txt");
    crit_table *t = generateTable(44100);
    band_table tables = associateBandToTable(t);
    long double *result = getMinimumMaskThr(global, tables.associated);
    static_list_f *expected_list = loadListFloat("./mp3/psychoacoustics/\
tests/min_mask.txt");
    long double *expected = expected_list->data;
    for (size_t i = 0; i < NB_SUBBANDS; i++)
    {
        assert(result[i] - expected[i] < 1e-4);
    }
    freeTable(t);
    freeStaticListF(global);
    free(tables.associated);
    free(result);
    freeStaticListF(expected_list);
    freeTable(tables.t);
    printf("==== Passed MIN MASK====\n");
}