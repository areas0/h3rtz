#include "psychoacoustic.h"

// For the moment
// @param samples is assumed to be an array of size at least NB_SAMPLES
void psychoAcoustic1(int *samples, short bits)
{
    // normalizes the input according to spec 3.2.1
    long double *norm = normalizeInput(samples, NB_SAMPLES, bits);

    // compute the FFT and then the sound pressure level with the Hann Window
    long double *SPL = getSPL(norm);
    free(norm);
    // TO BE MODIFIED AT A LATER POINT
    long double *sfc = loadScaleFactors("./mp3/psychoacoustics/constants/sfc.txt");

    // SPL_Subband only partial implementation, more work required
    long double *SPL_subband = getSPLBand(SPL, sfc);

    // Gets the tonal components from the SPL
    tonalComponents *tonals = findTonalComponents(SPL);

    // Generates the table associated to the critical band table
    crit_table *t = generateTable(44100);
    // Generates the critical band table associated to frequencies
    band_table tables = associateBandToTable(t);
    // Find noise step
    findNonTonalComponents(tonals,t, tables.t, tables.associated);

    // Remove the useless frequencies in tonal and non tonal components
    decimateTonal(tonals, tables.t, tables.associated);
    decimateNoise(tonals, tables.t, tables.associated);

    // Compute the mask for tonal components
    static_list_f **masks = getMaskTonal(tonals, SPL, tables);
    
    // Compute the mask for noise, similar to tonal
    static_list_f **masks_n = getMaskNoise(tonals, SPL, tables);

    // Computes the global masks from the noise&tonal masks
    static_list_f *gl_masks = getGlobalMasks(masks, masks_n, tables.t, tables.t->size);
    
    // Finally, sum the power of global masks to get the minimum mask
    long double *min_mask = getMinimumMaskThr(gl_masks, tables.associated);

    // Computes signal to mask ratio for bit allocation
    // it is simply the subband SPL - min_mask for each subband i
    long double *signal_to_mask_ratio = calloc(NB_SUBBANDS, sizeof(long double));
    for (size_t i = 0; i < NB_SUBBANDS; i++)
    {
        signal_to_mask_ratio[i] = SPL_subband[i] - min_mask[i];
    }
    free(sfc);
    free(gl_masks);
    free(min_mask);
    free(SPL_subband);
    free(tables.associated);
    freeTable(t);
    freeTable(tables.t);
    free(SPL);
    freeTonalComponents(tonals);
    for (size_t i = 0; i < 130; i++)
    {
        freeStaticListF(masks[i]);
        freeStaticListF(masks_n[i]);
    }
    free(masks);
    free(masks_n);
    
}