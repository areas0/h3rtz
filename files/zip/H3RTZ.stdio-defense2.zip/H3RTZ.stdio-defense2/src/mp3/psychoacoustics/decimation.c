#include "decimation.h"

void decimateTonal(tonalComponents *t, crit_table *table, size_t *map)
{
    // First part of decimation
    // removes tonals if they cannot be heard by the human ear
    // meaning that their sound pressure level is lesser than the threshold of
    // hearing
    for (size_t i = 0; i < t->tonals->nb_el; i++)
    {
        if (i >= t->tonals->nb_el)
        {
            break;
        }
        size_t k = t->tonals->data[i];
        //printf("%zu %Lf\n", k, table->thresholds[map[k]]);
        if (t->SPL[k] < table->thresholds[map[k]])
        {
            //printf("decimated %zu %zu\n", i, t->tonals->data[i]);
            popStaticList(t->tonals, i);
            t->flags[k] = IGNORE;
            i--;
        }
    }
    // Second part of decimation
    // If two tonal components are too close in regard to their distance in Bark
    // One of them will be removed and the other kept
    // We keep only the stronger
    // Reminder: this is the result of audio masking on critical bands
    for (size_t i = 0; i < t->tonals->nb_el-1; i++)
    {
        if (i >= t->tonals->nb_el-1)
            break;
        size_t current = t->tonals->data[i];
        size_t next = t->tonals->data[i+1];
        if (table->barks[map[current]] - table->barks[map[next]] < 0.5)
        {
            if (t->SPL[current] > t->SPL[next])
            {
                //printf("decimated %zu\n", next);
                popStaticList(t->tonals, i+1);
                t->flags[next] = IGNORE;
            }
            else
            {
                //printf("decimated %zu\n", current);
                popStaticList(t->tonals, i);
                t->flags[current] = IGNORE;
            }
        }
    }
    
}

void decimateNoise(tonalComponents *t, crit_table *table, size_t *map)
{
    // Only part 1 of decimation applies for noises
    for (size_t i = 0; i < t->noises->nb_el; i++)
    {
        if (i >= t->noises->nb_el)
        {
            break;
        }
        size_t k = t->noises->data[i];
        if (t->SPL[k] < table->thresholds[map[k]])
        {
            popStaticList(t->noises, i);
            t->flags[k] = IGNORE;
            i--;
        }
    }
}