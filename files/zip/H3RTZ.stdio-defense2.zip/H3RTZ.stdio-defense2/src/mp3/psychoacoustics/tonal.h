#ifndef TONAL_H
#define TONAL_H

#include "../consts_mp3.h"
#include <stdio.h>
#include <stdlib.h>
#include "../../tools/list/static_list.h"
#include "../math/decibel.h"
#include <sys/types.h>
#include "critical_bands.h"
typedef enum tonal_t
{
    UNSET,
    TONAL,
    NOISE,
    IGNORE,

} tonal_t;

typedef struct tonalComponents
{
    long double *SPL;
    static_list *tonals;
    static_list *noises;
    tonal_t *flags;
} tonalComponents;


static_list *findPeaks(long double *SPL);
tonalComponents *findTonalComponents(long double *SPL);
void findNonTonalComponents(tonalComponents *t, crit_table *table, crit_table *bands,
                            size_t *associated);
void freeTonalComponents(tonalComponents *t);

#endif