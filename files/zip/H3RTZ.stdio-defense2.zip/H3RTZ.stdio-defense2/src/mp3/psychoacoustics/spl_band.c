#define _GNU_SOURCE
#include <stdio.h>
#include "spl_band.h"
/* This file contains pre-implementation for SPL subband
** However the related code in other parts is not yet ready
*/
long double *getSPLBand(long double *SPL, long double *scale_factors)
{
    long double *result = malloc(sizeof(long double)*NB_SUBBANDS);
    for (size_t i = 0; i < NB_SUBBANDS; i++)
    {
        long double max = -INFINITY;
        for (size_t j = 1 + i * SUB_SIZE; j < 1 + i * SUB_SIZE + SUB_SIZE && j < HALF; j++)
        {
            if (SPL[j] > max)
            {
                max = SPL[j];
            }
        }
        max = max == -INFINITY ? 0 : max;
        long double second = 20 * log10l(scale_factors[i] * 32768) - 10;
        result[i] = second > max ? max : second;
    }
    return result;
}

long double *loadScaleFactors(char *path)
{
    long double *sf = calloc(NB_SUBBANDS, sizeof(long double));
    int r;
    size_t len = 0;
    char *buffer = NULL;
    FILE *f = fopen(path, "r");
    size_t i = 0;
    while ((r = getline(&buffer, &len, f)) != -1 && i < NB_SUBBANDS)
    {
        long double value;
        sscanf(buffer, "%Lf", &value);
        sf[i] = value;
        i++;
    }
    free(buffer);
    return sf;
}