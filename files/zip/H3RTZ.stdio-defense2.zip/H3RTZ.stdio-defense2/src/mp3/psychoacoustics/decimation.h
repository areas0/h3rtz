#ifndef DECIMATION_H
#define DECIMATION_H

#include "psychoacoustic.h"

void decimateTonal(tonalComponents *t, crit_table *table, size_t *map);
void decimateNoise(tonalComponents *t, crit_table *table, size_t *map);
#endif