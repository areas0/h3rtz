#include "critical_bands.h"
size_t critbands[27] = {1,2,3,5,7,10,13,16,19,22,26,30,35,40,46,51,56,62,69,74,79,85,92,99,105,117,130};

// computes the band associated to frequency f in Hz
long double z(long double f)
{
    return 13*atanl(0.00076*f)+3.5*atanl(powl(f/7500, 2));
}

// computes the bark scale value of each frequencies in an array f
long double *generateTableZ(long double *f, size_t len)
{
    long double *table = malloc(len*sizeof(long double));
    for (size_t i = 0; i < len; i++)
    {
        table[i] = z(f[i]);
    }
    return table;
}
// Generates the critical band table for frequencies
// Currently for use only with fs = 44100hz
crit_table *generateTable(size_t sampling_rate)
{
    crit_table *t = calloc(1, sizeof(crit_table));
    if (sampling_rate == 44100)
    {
        t->size = CRIT_BAND_44100;
    }
    else if (sampling_rate == 48000)
    {
        errx(EXIT_FAILURE, "Unsupported sampling rate");
        t->size = CRIT_BAND_48000;
    }
    else if (sampling_rate == 32000)
    {
        errx(EXIT_FAILURE, "Unsupported sampling rate");
        t->size = CRIT_BAND_32000;
    }
    else
        errx(EXIT_FAILURE, "Failed to find a critical band table");
    
    t->sampling_rate = sampling_rate;
    t->indices = calloc(t->size, sizeof(size_t));
    t->frequencies = malloc(sizeof(long double)*t->size);
    
    long double f = sampling_rate/ (long double) NB_SAMPLES;
    for (size_t i = 0; i < t->size; i++)
    {
        t->indices[i] = critbands[i];
        t->frequencies[i] = f * (long double) t->indices[i];
    }
    
    t->thresholds = getTableThreshold(t->frequencies, t->size);
    t->barks = generateTableZ(t->frequencies, t->size);
    return t;
}

void freeTable(crit_table *t)
{
    free(t->indices);
    free(t->barks);
    free(t->frequencies);
    free(t->thresholds);
    free(t);
}
// Loads the critical band model and associates frequencies to indices in the
// 512 SPL to their critical band
// @return a tuple with the associated table of index & the classic crit_table
band_table associateBandToTable(crit_table *t)
{
    FILE *f = fopen("./mp3/model.txt", "r");
    // memory allocation zone
    crit_table *bounds = malloc(sizeof(crit_table));
    size_t *associated = calloc(HALF, sizeof(size_t));
    bounds->barks = calloc(130, sizeof(long double));
    long double *frequencies = calloc(131, sizeof(long double));
    bounds->frequencies = frequencies;
    bounds->size = 130;
    bounds->sampling_rate = t->sampling_rate;
    bounds->indices = calloc(130, sizeof(size_t));
    bounds->thresholds = calloc(130, sizeof(long double));

    // constants for file reading
    int r;
    size_t len = 0;
    char *buffer = NULL;
    // this loop gets the data from the file
    while ( (r = getline(&buffer, &len, f)) != -1)
    {
        size_t index;
        long double freq, crit, threshold;
        sscanf(buffer, "%zu %Lf %Lf %Lf\n", &index, &freq, &crit, &threshold);
        index--; // offset is -1 because format starts at 1
        frequencies[index] = freq;
        bounds->thresholds[index] = threshold;
        bounds->indices[index] = (size_t) freq/(44100/NB_SAMPLES);
        bounds->barks[index] = crit;
    }
    free(buffer);
    // compute the associated index table
    for (size_t i = 0; i < bounds->size-1; i++)
    {
        for (size_t j = bounds->indices[i]; j < bounds->indices[i+1]; j++)
        {
            associated[j] = i;
        }
    }
    for (size_t i = bounds->indices[bounds->size-1]; i < HALF; i++)
    {
        associated[i] = bounds->size -1;
    }
    // return value tuple
    band_table table = 
    {
        .associated = associated,
        .t = bounds,
    };
    return table;
}