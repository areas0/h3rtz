#ifndef DECIBEL_H
#define DECIBEL_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

long double add_db(long double *array, size_t len);
long double thresholdHearing(long double f);
long double *getTableThreshold(long double *f, size_t len);
#endif