#include "weights.h"

long double *normalizeInput(int *samples, size_t len, size_t factor)
{
    long double *result = calloc(len, sizeof(long double));
    long double numerator = len*powl(2, factor-1);
    for (size_t i = 0; i < len; i++)
    {
        result[i] = (samples[i])/(numerator);
    }
    return result;
}