#include "decibel.h"

long double add_db(long double *array, size_t len)
{
    long double sum = 0;
    for (size_t i = 0; i < len; i++)
    {
        sum += powl(10.0, array[i] / 10.0);
    }
    return 10.0 * log10l(sum+1e-6);
}

// Threshold of hearing as defined in part 3.1.1
long double thresholdHearing(long double f)
{
    long double part1 = 3.64 * powl(f/1000, -0.8);
    long double part2 = -6.5 * expl(-0.6*powl((f/1000)-3.3, 2));
    long double part3 = powl(10,-3)*powl(f/1000, 4);
    return part1+part2+part3;
}

long double *getTableThreshold(long double *f, size_t len)
{
    long double *t = malloc(len*sizeof(long double));
    for (size_t i = 0; i < len; i++)
    {
        t[i] = thresholdHearing(f[i]);
    }
    return t;    
}