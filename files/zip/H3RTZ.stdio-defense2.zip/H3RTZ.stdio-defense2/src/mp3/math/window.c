#include "window.h"

long double hannWindow(long double n, size_t total)
{
    return 0.5*(1-cosl( (2*M_PI*n)/(total-1)));
}

long double *getHannWindow(size_t total)
{
    long double *values = calloc(total, sizeof(long double));
    for (size_t n = 0; n < total; n++)
    {
        values[n] = hannWindow(n, total);
    }
    return values;
}