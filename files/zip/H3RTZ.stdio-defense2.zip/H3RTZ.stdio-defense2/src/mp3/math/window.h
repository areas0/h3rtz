#ifndef WINDOW_H
#define WINDOW_H

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "../consts_mp3.h"
long double hannWindow(long double n, size_t total);
long double *getHannWindow(size_t total);
#endif