#ifndef PROP_INFO_H
#define PROP_INFO_H

#include "../multiplayer.h"
void updatePropInfo(pa_format_info *info, wav *file);

#endif