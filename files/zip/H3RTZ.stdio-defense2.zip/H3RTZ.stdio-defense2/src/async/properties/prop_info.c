#include "prop_info.h"


void updatePropInfo(pa_format_info *info, wav *file)
{
    fileInfo *f = getFileInfo(file->list);
    if (!f)
        return;
    if (f->artists)
        pa_format_info_set_prop_string(info, PA_PROP_MEDIA_ARTIST, f->artists);
    if (f->name)
        pa_format_info_set_prop_string(info, PA_PROP_MEDIA_TITLE, f->name);
    free(f);
}