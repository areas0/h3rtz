#include "placeholders.h"

// simple callback to signal that the init was successfull
void callback_init_wait(pa_context *context, void *userdata)
{
    pa_player *player = userdata;
    pa_objects *pa = player->pulseAudio;
    assert(context);
    pa_threaded_mainloop_signal(pa->loop, 0);
}


void callback_success_stream(pa_stream *stream, int success, void *userdata)
{
    assert(stream);
    assert(success);
    assert(userdata);
    return;
}