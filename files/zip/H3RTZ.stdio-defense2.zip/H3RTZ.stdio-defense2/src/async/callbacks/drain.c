#include "drain.h"

// Makes sure that we played all the samples before disconnecting the stream
void drainStream(pa_player *player)
{
    pa_objects *pa = player->pulseAudio;
    pa_threaded_mainloop *loop = pa->loop;
    pa_stream *stream = player->player->stream;
    if (!stream || !loop)
    {
        warnx("drainStream: no stream or loop to drain");
        return;
    }
    if (player->pa_state != ACTIVE || player->player->status != PLAYING)
    {
        warnx("drainStream: tried a drain on an invalid status");
        return;
    }
    if (player->player->drainer->state != DRAIN_INACTIVE)
    {
        warnx("drainStream: tried to drain a stream already %s", 
        player->player->drainer->state == DRAIN_ACTIVE ? "in draining" : "drained");
        return;
    }
    warnx("drainStream: started draining...");
    // locks the mainloop to avoid errors
    pa_threaded_mainloop_lock(loop);
    // starts a draining operation, it is asynchronous
    pa_operation *op = pa_stream_drain(stream, &callbackDrain, loop);
    player->player->drainer->drain = op;
    player->player->drainer->state = DRAIN_ACTIVE;
    // we wait for it to be done
    pa_operation_state_t state;
    while ((state = pa_operation_get_state(op)) != PA_OPERATION_DONE)
    {
        if (state == PA_OPERATION_CANCELLED)
        {
            warnx("drainStream: cancelled operation...");
            pa_stream_set_write_callback(player->player->stream, &callback_write, player);
            pa_operation_unref(op);
            player->player->drainer->drain = 0;
            player->player->drainer->state = DRAIN_INACTIVE;
            pa_threaded_mainloop_unlock(pa->loop);
            return;
        }
        pa_threaded_mainloop_wait(loop);
    }
    warnx("drainStream: finished draining...");
    pa_operation_unref(op);
    player->player->drainer->state = DRAIN_FINISHED;
    player->player->drainer->drain = 0;
    pa_stream_disconnect(stream);
    pa_stream_unref(stream);
    // we can unlock and continue business as usual
    pa_threaded_mainloop_unlock(loop);

}
// pthread wrapper for drainStream
void *drainStreamT(void *userdata)
{
    drainStream((pa_player *) userdata);
    return NULL;
}

/* Callback that writes data to the buffer
 * @param userdata: must be pa_player
 * @param stream/requested_bytes all determined and given by default
 */
void callbackDrain(pa_stream *stream, int success, void *userdata)
{
    assert(stream);
    assert(success);
    pa_threaded_mainloop *loop = userdata;
    pa_threaded_mainloop_signal(loop, 0);
}

void cancelDrain(pa_player *player)
{
    wav_player *pa = player->player;
    if (pa->status == NOT_READY)
    {
        warnx("cancelDrain: tried to cancel a drain on an inactive stream");
        return;
    }
    if (!pa->drainer->drain || pa->drainer->state != DRAIN_ACTIVE)
    {
        warnx("cancelDrain: tried to cancel a drain but no draining was found");
        return;
    }
    pa_operation_cancel(pa->drainer->drain);
    pa_threaded_mainloop_signal(player->pulseAudio->loop, 0);
}