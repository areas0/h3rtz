#ifndef WRITE_H
#define WRITE_H

#include "../multiplayer.h"
extern pthread_mutex_t mutex_acc;
void callback_write(pa_stream *stream, size_t requested_bytes, void *userdata);
#endif