#ifndef STREAM_H
#define STREAM_H
#include <gst/gst.h>
#include <glib.h>
#include <gio/gio.h>
#include "../multiplayer.h"

int convert(pa_player *player, char *path);
#endif