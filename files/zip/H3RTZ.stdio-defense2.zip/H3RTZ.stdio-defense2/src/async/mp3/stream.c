#include "stream.h"
#define DEBUG 0

void on_pad_added_cb(GstElement *decodebin, GstPad *pad, gpointer data)
{
    assert(decodebin);
    GstElement *convert = (GstElement *) data;

    GstCaps *caps;
    GstStructure *str;

    GstPad *audiopad = gst_element_get_static_pad(convert, "sink");
    if (GST_PAD_IS_LINKED(audiopad))
    {
        g_object_unref(audiopad);
        return;
    }
    caps = gst_pad_query_caps(pad, NULL);
    str = gst_caps_get_structure(caps, 0);
    if (!g_strrstr(gst_structure_get_name(str), "audio"))
    {
        gst_caps_unref(caps);
        gst_object_unref(audiopad);
        return;
    }
    gst_caps_unref(caps);
    gst_pad_link(pad, audiopad);
    g_object_unref(audiopad);
}

gboolean bus_call_cb(GstBus *bus, GstMessage *msg, gpointer data)
{
    assert(bus);
    GMainLoop *loop = (GMainLoop*)data;
    gchar *debug = NULL;
    GError *error = NULL;
    switch (GST_MESSAGE_TYPE(msg))
    {
        case GST_MESSAGE_EOS:
            g_main_loop_quit(loop);
            break;
        case GST_MESSAGE_ERROR:
            gst_message_parse_error(msg, &error, &debug);
            g_free (debug);
            g_printerr("Error: %s\n", error->message);
            g_main_loop_quit(loop);
            g_error_free(error);
            break;
        default:
            break;
    }
    return TRUE;
}

int convert(pa_player *player, char *path)
{
    static uint8_t init = 0;
    if (!init)
        gst_init(NULL, NULL);
    init = 1;
    // inits a mainloop for events polling
    GMainLoop *loop = g_main_loop_new(NULL, FALSE);
    GstElement *pipe = gst_pipeline_new("mp3");
    // Creates a fake stream output
    GstElement *stream = (GstElement *) G_MEMORY_OUTPUT_STREAM(
        g_memory_output_stream_new(NULL, 0,
        (GReallocFunc)g_realloc, (GDestroyNotify)g_free));
    // fake sink connected to stream
    GstElement *sink = gst_element_factory_make("giostreamsink", "sink");
    g_object_set(G_OBJECT(sink), "stream", stream, NULL);
    // various plugins to load & convert audio
    GstElement *source = gst_element_factory_make("filesrc", "source");
    g_object_set(G_OBJECT(source), "location", path, NULL);
    GstElement *convert = gst_element_factory_make("audioconvert", "convert");
    GstElement *decode = gst_element_factory_make("decodebin", "decoder");
    GstElement *encoder = gst_element_factory_make("wavenc", "encoder");
    assert(convert);
    assert(stream);
    assert(decode);
    assert(source);
    assert(sink);
    // callback connection
    g_signal_connect(decode, "pad-added", G_CALLBACK(on_pad_added_cb), convert);

    // Bus stuff
    GstBus *bus = gst_pipeline_get_bus(GST_PIPELINE(pipe));
    guint id = gst_bus_add_watch(bus, bus_call_cb, loop);
    gst_object_unref(bus);

    gst_bin_add_many(GST_BIN(pipe), source, decode, convert, encoder, sink, NULL);
    gst_element_link(source, decode);
    // Options for converter
    GstCaps *caps = gst_caps_new_simple("audio/x-raw",
                               //"rate", G_TYPE_INT, 48000,
                               //"channels", G_TYPE_INT, 1,
                               //"width", G_TYPE_INT, 16,
                               //"depth", G_TYPE_INT, 16,
                               //"format",G_TYPE_STRING, "S32LE",
                               "signed", G_TYPE_BOOLEAN, TRUE,
                               NULL);
    gst_element_link_filtered(convert, encoder, caps);
    gst_element_link(encoder, sink);
    gst_caps_unref(caps);

    gst_element_set_state(GST_ELEMENT(pipe), GST_STATE_PLAYING);

    g_main_loop_run(loop);
    // freeing zone
    gst_element_set_state(pipe, GST_STATE_NULL);
    gst_object_unref(GST_OBJECT(pipe));
    g_source_remove (id);
    g_main_loop_unref(loop);
    // output
    gpointer *data =
                g_memory_output_stream_get_data(G_MEMORY_OUTPUT_STREAM(stream));
    // Gets the size of the currently allocated data area
    //unsigned long size =
    //           g_memory_output_stream_get_size(G_MEMORY_OUTPUT_STREAM(stream));
    // Returns the number of bytes from the start up to including
    // the last byte written in the stream that has not been truncated away.
    unsigned long sizeData =
            g_memory_output_stream_get_data_size(G_MEMORY_OUTPUT_STREAM(stream));
    if (sizeData == 0)
        return -1;
    char *newData = calloc(sizeData, sizeof(char));
    memcpy(newData, data, sizeData);
    #if DEBUG
    FILE *file_a = fopen("./a.wav", "w");
    fwrite(newData, sizeof(char), sizeData, file_a);
    fclose(file_a);
    #endif
    // creates and binds a file to a pa_player
    file *f = calloc(1, sizeof(file));
    player->player->track = f;
    f->fd = -1;
    f->map = (unsigned char *) newData;
    f->stats = calloc(1, sizeof(struct stat));
    f->stats->st_size = sizeData;
    wav *h = headerParser(f);
    if (!h)
        return -1;
    player->player->info = h;
    player->player->data = h->data->chunk;
    g_free(data);
    return 0;
}