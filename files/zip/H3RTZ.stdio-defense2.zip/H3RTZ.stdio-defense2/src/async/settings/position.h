#ifndef POSITION_H
#define POSITION_H

#include "../multiplayer.h"
void relative(pa_player *player, size_t offset, uint8_t manual);
void cb_seeking(pa_stream *s, int success, void *userdata);
#endif