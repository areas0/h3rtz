#ifndef TOOLS_H
#define TOOLS_H
#define _GNU_SOURCE
#include <pulse/pulseaudio.h>
#include "../../wav/wav.h"
#include <math.h>

typedef enum state
{
    BABY, // before mainloop init
    READY, // before stream init
    ACTIVE, // while playing/paused
    TERMINATED, // killed stream but track in memory <=> ready
    FINAL, // killed mainloop
} state;

typedef enum playerStatus
{
    NOT_READY, // if state is != ACTIVE
    PLAYING, // can be drained
    PAUSED, // corked stream
} playerStatus;

typedef enum DrainStatus
{
    DRAIN_INACTIVE, // no operation running
    DRAIN_ACTIVE, // operation running -> playing state
    DRAIN_FINISHED, // can interrupt stream
} DrainStatus;

typedef enum fileType
{
    WAV_ORIGINAL,
    OTHER,
} fileType;

// Object used to track draining process
typedef struct drain
{
    DrainStatus state;
    pa_operation *drain;
} drain;

// Contains offset information
// + GUI information
typedef struct pa_time
{
    size_t offset;
    double time;
    double current;
    pa_usec_t *latency;
} pa_time;

// Per track data, will change over the program's lifetime
typedef struct wav_player
{
    wav *info; // contain header and data pointers for the file played
    file *track; // I/O attributes
    unsigned char *data; // points to the beginning of the audio samples
    pa_stream *stream; // Opaque PulseAudio object to launch operations
    drain *drainer; // holds information about the draining status
    pa_time *timing; // position in the current file, latency
    playerStatus status; // see enum
} wav_player;

// Static PulseAudio objects during the program's lifetime
typedef struct pa_objects
{
    pa_context *context;
    pa_threaded_mainloop *loop;
    pa_mainloop_api *api;
    char *sink;
    pa_server_info *server;
} pa_objects;

typedef struct pa_info
{
    // modify that value to change the volume
    // must be a double between 0.0 and 1.0
    double volume;
    // sink input id
    uint32_t id;
} pa_info;

typedef struct pa_player
{
    wav_player *player; //variable objects
    pa_objects *pulseAudio; //static objects
    pa_info *info; // for volume
    state pa_state; // global PulseAudio State
    fileType type; // unused atm
} pa_player;

#include "../multiplayer.h"

void *display_time(void *userdata);
void updateInfo(pa_player *player);
char *timeToFormat(double time);
void *synchronize(void *userdata);
#endif