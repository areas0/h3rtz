#include "tools.h"

void updateInfo(pa_player *player)
{
    player->player->data = player->player->info->data->chunk;
    player->player->timing->offset = 0;
}


// will print current timestamp / completion bar on terminal
void *display_time(void *userdata)
{
    // variables to get data
    pa_player *pa_player = userdata;
    //pa_objects *pa = pa_player->pulseAudio;

    // need file info to display artist, album, etc...
    fileInfo *info = getFileInfo(pa_player->player->info->list);
    // Constant
    double power = pow(10, 6);
    // Total duration computation: nb bytes in file / bitrate
    double duration = (double) pa_player->player->info->data->data_bytes/
    (double) pa_player->player->info->fmt->bitrate;
    // total timestamp to string
    char *total = timeToFormat(duration);
    // sets the information: if it doesn't exist, gives unknown
    char *playing = info->name ? info->name : "Unknown";
    char *artist = info->artists ? info->artists : "Unknown";
    char *album = info->product ? info->product : "Unknown";
    // while the player is running, update the timestamp
    while(pa_player->pa_state == ACTIVE)
    {
        // gets the latency in pulseaudio -> lantency (pa_usec *)
        updateLatency(pa_player);
        getVolume(pa_player);
        // clears the screen
        printf("\e[1;1H\e[2J");
        printf("Currently playing: %s\n", playing);
        printf("Artist(s): %s\n", artist);
        printf("Album: %s\n", album);
        printf("[");
        // computations
        double timing = pa_player->player->timing->time;
        // converts to microseconds
        timing *= power;
        double wLatency = timing - (double) *(pa_player->player->timing->latency);
        //printf("%lf %lf\n", wLatency, wLatency/power);
        size_t ratio = ((wLatency/power) * 100)/ duration;
        for (size_t i = 0; i < ratio; i++)
        {
            printf("=");
        }
        for (size_t i = ratio; i < 100; i++)
        {
            printf(" ");
        }
        
        printf("] ");
        char *timestamp = timeToFormat(wLatency/power);
        printf("%s / %s", timestamp, total);
        free(timestamp);
        printf("\n\n");
        printf("DEBUG: PulseAudio\n");
        printf("Currently: %s\n", pa_player->player->status == PLAYING ? "Playing" : 
                                                                "Paused");
        printf("Latency: %ld usec\n", *pa_player->player->timing->latency);
        printf("Current device: %s\n", pa_player->pulseAudio->sink);
        printf("Current volume: %lf\n", pa_player->info->volume);
        printPulseState(pa_player);
        sleep(1);
    }
    free(info);
    free(total);
    return NULL;
}
// Simple timestamp formatting function
// @param time: double as number of seconds
char *timeToFormat(double time)
{
    char *format = (int) time % 60 < 10 ? "0" : "";
    char *result = NULL;
    int length = asprintf(&result, "%dm%s%ds", (int) time / 60, format,
    (int) time % 60);
    if (length <= 0)
        errx(EXIT_FAILURE, "Format error");
    return result;
}

#if DEPRECATED
void *synchronize(void *userdata)
{
    pa_player *player = userdata;
    while(player->pa_state < DRAINED)
    {
        if (player->pa_state == PLAYING || player->pa_state == FINISHED)
        {
            sem_post(&player->utility->wait);
        }
        sleep(1);
    }
    printf("Exiting synchro\n");
    return NULL;
}
#endif