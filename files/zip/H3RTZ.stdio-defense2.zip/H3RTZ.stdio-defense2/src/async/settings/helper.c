#include "helper.h"


char *paStateToString(state s)
{
    switch (s)
    {
    case BABY:
        return "BABY";
    case READY:
        return "READY";
    case ACTIVE:
        return "ACTIVE";
    case TERMINATED:
        return "TERMINATED";
    case FINAL:
        return "KILLED";
    default:
        return "Unknown";
    }
}

char *playerStatusToString(playerStatus s)
{
    switch (s)
    {
    case NOT_READY:
        return "NOT_READY";
    case PLAYING:
        return "PLAYING";
    case PAUSED:
        return "PAUSED";
    default:
        return "Unknown";
    }
}

char *drainStatusToString(DrainStatus d)
{
    switch (d)
    {
    case DRAIN_INACTIVE:
        return "INACTIVE";
    case DRAIN_ACTIVE:
        return "ACTIVE";
    case DRAIN_FINISHED:
        return "FINISHED";
    default:
        return "Unknown";
    }
}

void printPulseState(pa_player *player)
{
    printf("====== PLAYER STATUS ======\n");
    printf("PulseAudio: %s\n", paStateToString(player->pa_state));
    printf("Stream: %s\n", playerStatusToString(player->player->status));
    printf("Drain: %s\n", drainStatusToString(player->player->drainer->state));
    printf("======     END       ======\n");
}