#include "volume.h"

void getVolume(pa_player *player)
{
    pa_objects *pa = player->pulseAudio;
    if (!pa->sink)
        return;
    if (player->pa_state != ACTIVE)
        return;
    pa_threaded_mainloop_lock(pa->loop);
    pa_operation * op = pa_context_get_sink_input_info(pa->context, 
                                player->info->id, &getVolumeCb, player);
    while (pa_operation_get_state(op) != PA_OPERATION_DONE)
        pa_threaded_mainloop_wait(pa->loop);
    pa_threaded_mainloop_unlock(pa->loop);
    pa_operation_unref(op);
}

void setVolume(pa_player *player)
{
    pa_objects *pa = player->pulseAudio;
    if (!pa->sink)
        return;
    pa_threaded_mainloop_lock(pa->loop);
    pa_volume_t new = pa_sw_volume_from_linear(player->info->volume);
    pa_cvolume *vol = calloc(1, sizeof(pa_cvolume));
    pa_cvolume_set(vol, player->player->info->fmt->channel, new);
    pa_operation *op = pa_context_set_sink_input_volume(pa->context, 
                        player->info->id, vol, &callbackRaised, player);
    while (pa_operation_get_state(op) != PA_OPERATION_DONE)
        pa_threaded_mainloop_wait(pa->loop);
    free(vol);
    pa_threaded_mainloop_unlock(pa->loop);
    pa_operation_unref(op);
}

void getVolumeCb(pa_context *c, const pa_sink_input_info *i, int eol, void *userdata)
{
    if (!i)
        return;
    assert(c);
    assert(eol >= 0);
    pa_player *player = userdata;
    pa_objects *pa = player->pulseAudio;
    player->info->volume = pa_sw_volume_to_linear(pa_cvolume_avg(&i->volume));
    pa_threaded_mainloop_signal(pa->loop, 0);
}

void callbackRaised(pa_context *c, int success, void *userdata)
{

    pa_player *player = userdata;
    if (!success || !c)
        warnx("ContextCallback: missing context or operation unsuccessful");
    pa_threaded_mainloop_signal(player->pulseAudio->loop, 0);
}