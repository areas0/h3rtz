#ifndef VOLUME_H
#define VOLUME_H

#include "../multiplayer.h"

extern double volume;
void getVolume(pa_player *player);
void setVolume(pa_player *player);
void setVolumeCb(pa_context *c, const pa_sink_info *i, int eol, void *userdata);
void getVolumeCb(pa_context *c, const pa_sink_input_info *i, int eol, void *userdata);
#endif