#include "position.h"
pthread_mutex_t mutex_acc = PTHREAD_MUTEX_INITIALIZER;
/* Experimental: DO NOT USE IN GUI */
void relative(pa_player *player, size_t offset, uint8_t manual)
{
    pa_objects *pa = player->pulseAudio;
    if (manual)
        Pause(player);
    pa_threaded_mainloop_lock(pa->loop);
    if (player->pa_state != ACTIVE)
    {
        warnx("relative: Invalid player given...");
        pa_threaded_mainloop_unlock(pa->loop);
        return;
    }

    // If there is currently a drain, we stop it because it will fail
    // the draining operations times out after x seconds
    if (player->player->drainer->state == DRAIN_ACTIVE)
    {
        cancelDrain(player);
    }

    pa_operation *op = pa_stream_flush(player->player->stream, &cb_seeking, player);
    while (pa_operation_get_state(op) != PA_OPERATION_DONE)
        pa_threaded_mainloop_wait(pa->loop);
    pa_threaded_mainloop_unlock(pa->loop);
    
    // offset computation with block alignement
    player->player->timing->offset = 
                    offset - offset % player->player->info->fmt->samplerate;
    if (manual)
        play(player);
}

void cb_seeking(pa_stream *s, int success, void *userdata)
{
    assert(s);
    assert(success);
    assert(userdata);
    pa_player *player = userdata;
    pa_threaded_mainloop_signal(player->pulseAudio->loop, 0);
}