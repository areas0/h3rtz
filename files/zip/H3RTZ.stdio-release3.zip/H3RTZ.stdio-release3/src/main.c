#include <stdio.h>
#include "./GUI/init.h"
#include "./wav/wav.h"
#include "./async/multiplayer.h"
#include "./wav/encode/encode.h"
#include "./mp3/psychoacoustics/psychoacoustic.h"
#include "./mp3/psychoacoustics/tests/test.h"
#include "./huffman/compress.h"
#include "./tools/Bitstream/bistream.h"
#include "./huffman/decompress.h"
#include "./huffman/encoder/simple.h"
#include "./huffman/encoder/hzt.h"

const char *help = "Usage: exec mode [ARGS...]\n\
Modes:\n\
1: Launches the GUI (default mode)\n\
2: Launches the debugging PulseAudio player (deprecated):\n\
   [ARGS]: list of path of wav files to play\n\
   Example: ./main 2 ./examples/file1.wav ./examples/file2.wav\n\
3: Launches the wav encoding interface on shell\n\
   [ARGS]: path of wav file to encode\n\
4: Testes MP3 encoding procedures (deprecated)\n\
5: Encodes a file using the H3RTZ file format:\n\
   [ARGS]: 1. input file 2. output file\n\
   Example: ./main 5 ./examples/example.wav ./examples/output.wav\n\
6: Decodes a file using the H3RTZ file format decompression algorithm:\n\
   [ARGS]: 1. input file 2. output file\n\
   Example: ./main 5 ./examples/example.wav ./examples/output.wav\n";

int main(int argc, char **argv)
{
    if (argc == 1 || !argv)
    {
      init_interface();
      return 0;
    }
    long mode = atol(argv[1]);
    switch (mode)
    {
      case 1:
        init_interface();
        break;
      case 2:
        player(argc-1, &argv[1]);
        break;
      case 3:
        // TODO: UPDATE THAT CALL
        //wav_encode(argv[2]);
        break;
      case 4:
        testFFT();
        checkTonal();
        testNoise();
        testDecimation();
        testMaskingTonal();
        testMaskingNoise();
        testGlobalMasking();
        testMinMasking();
        break;
      case 5:
        if (argc < 4)
        {
          printf("%s", help);
          return 1;
        }
        convertFile(argv[2], argv[3]);
        break;
      case 6:
        if (argc < 4)
        {
          printf("%s", help);
          return 1;
        }
        decodeFile(argv[2], argv[3]);
        break;
      default:
        printf("%s", help);
        break;
    }
    return 0;
}
