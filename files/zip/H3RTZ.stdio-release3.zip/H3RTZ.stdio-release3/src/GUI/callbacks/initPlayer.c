#include "initPlayer.h"

void on_choose_wav(GtkWidget *widget, gpointer userdata)
{
    gtk_player *player = userdata;
    if (player->filename)
        free(player->filename);
    player->filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(widget));
    player->ui.name_chooser = player->filename;
    append(NULL, player);
    if (player->player->pa_state == TERMINATED)
        incrementPosition(player->playlist);
    if (player->player->pa_state != ACTIVE)
        playTrack(player);

}
