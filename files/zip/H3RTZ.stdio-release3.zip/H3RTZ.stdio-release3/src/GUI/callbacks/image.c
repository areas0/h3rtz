#include "image.h"

void image(gpointer userdata)
{
    gtk_player *player = userdata;
    fileType info;
    info = player->player->type;
    //For now, we'll see how to get mp3 pic song,
    //but lets just take care of WAv since there is no pic
    if(info == WAV_ORIGINAL)
    {
        gtk_image_set_from_file(GTK_IMAGE(player->ui.song_image), "./icons/newwav.png");
        //printf("Pas MP3");
    }
    else
    {
        gtk_image_set_from_file(GTK_IMAGE(player->ui.song_image), "./icons/newmp3.png");
        //printf("Pas Wav");
    }
}
