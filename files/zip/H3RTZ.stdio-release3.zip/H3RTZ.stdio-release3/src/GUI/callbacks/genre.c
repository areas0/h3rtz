#include "genre.h"

void genre(gpointer userdata)
{
    gtk_player *player = userdata;
    fileInfo *genre;
    genre = getFileInfo(player->player->player->info->list);
    gtk_label_set_text(player->ui.genre, genre->genre ? genre->genre : "Unknown");
    free(genre);
}
