#include "exit.h"

void on_quit(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    changeTrack(player->player);
    pa_context_unref(player->player->pulseAudio->context);
    pa_threaded_mainloop_stop(player->player->pulseAudio->loop);
    pa_threaded_mainloop_free(player->player->pulseAudio->loop);
    freePulsePlayer(player->player);
    freePlaylist(player->playlist);
    gtk_main_quit();
}
