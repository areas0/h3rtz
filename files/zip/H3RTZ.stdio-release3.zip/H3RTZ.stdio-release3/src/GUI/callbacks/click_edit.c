#include "click_edit.h"
#include "../../wav/encode/encode.h"

//done
void click_edit(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    if (player->filename == NULL)
    {
        gtk_widget_show(GTK_WIDGET(player->ui.warning_dialog));
        printf("Can't edit info if there's no files playing\n");
    }
    //get text function
    else
    {
        if (!player->playlist->nb_el)
        {
            gtk_widget_show(GTK_WIDGET(player->ui.warning_dialog));
            return;
        }
        gtk_widget_show(GTK_WIDGET(player->ui.dialog_edit));
        // Album
        fileInfo *info;
        info = getFileInfo(player->player->player->info->list);
        gtk_label_set_text(player->ui.dialog_album, info->product ? info->product : info->album ? info->album
                                                                                                : "Unknown");
        // Genre
        gtk_label_set_text(player->ui.dialog_genre, info->genre ? info->genre : "Unknown");

        // Artist
        gtk_label_set_text(player->ui.dialog_artist, info->artists ? info->artists : "Unknown");

        // Copyrights
        gtk_label_set_text(player->ui.dialog_copyrights, info->copyrights ? info->copyrights : "Unknown");

        // Name
        gtk_label_set_text(player->ui.dialog_name, info->name ? info->name : "Unknown");

        free(info);
    }
}

void updateFields(gtk_player *player)
{
    fileInfo *info;
    info = getFileInfo(player->player->player->info->list);
    gtk_label_set_text(player->ui.dialog_album, info->product ? info->product : info->album ? info->album
                                                                                            : "Unknown");
    // Genre
    gtk_label_set_text(player->ui.dialog_genre, info->genre ? info->genre : "Unknown");

    // Artist
    gtk_label_set_text(player->ui.dialog_artist, info->artists ? info->artists : "Unknown");

    // Copyrights
    gtk_label_set_text(player->ui.dialog_copyrights, info->copyrights ? info->copyrights : "Unknown");

    // Name
    gtk_label_set_text(player->ui.dialog_name, info->name ? info->name : "Unknown");

    free(info);
}

void clicked_save(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    char *no_changes = "No changes";
    gtk_player *player = userdata;

    //Parse the names
    //Put it in the lists we created
    gint16 length_artist = gtk_entry_get_text_length(player->ui.artist_text);
    gint16 length_copyright = gtk_entry_get_text_length(player->ui.copyright_text);
    gint16 length_genre = gtk_entry_get_text_length(player->ui.genre_text);
    gint16 length_name = gtk_entry_get_text_length(player->ui.name_text);
    gint16 length_album = gtk_entry_get_text_length(player->ui.album_text);

    player->args->artist = no_changes;
    player->args->copyright = no_changes;
    player->args->genre = no_changes;
    player->args->name = no_changes;
    player->args->album = no_changes;

    if (length_artist != 0)
    {
        player->args->artist = malloc((length_artist + 1) * sizeof(char));
        strcpy(player->args->artist, gtk_entry_get_text(player->ui.artist_text));
        gtk_label_set_text(GTK_LABEL(player->ui.dialog_artist), (const gchar *)player->args->artist);
    }
    else if (length_copyright != 0)
    {
        player->args->copyright = malloc((length_copyright + 1) * sizeof(char));
        strcpy(player->args->copyright, gtk_entry_get_text(player->ui.copyright_text));
        gtk_label_set_text(GTK_LABEL(player->ui.dialog_copyrights), (const gchar *)player->args->copyright);
    }
    if (length_genre != 0)
    {
        player->args->genre = malloc((length_genre + 1) * sizeof(char));
        strcpy(player->args->genre, gtk_entry_get_text(player->ui.genre_text));
        gtk_label_set_text(GTK_LABEL(player->ui.dialog_genre), (const gchar *)player->args->genre);
    }
    if (length_name != 0)
    {
        player->args->name = malloc((length_name + 1) * sizeof(char));
        strcpy(player->args->name, gtk_entry_get_text(player->ui.name_text));
        gtk_label_set_text(GTK_LABEL(player->ui.dialog_name), (const gchar *)player->args->name);
    }
    if (length_album != 0)
    {
        player->args->album = malloc((length_album + 1) * sizeof(char));
        strcpy(player->args->album, gtk_entry_get_text(player->ui.album_text));
        gtk_label_set_text(GTK_LABEL(player->ui.dialog_album), (const gchar *)player->args->album);
    }

    printf("test_artist = %s\n", player->args->artist);
    printf("test_copy = %s\n", player->args->copyright);
    printf("test_genre = %s\n", player->args->genre);
    printf("test_name = %s\n", player->args->name);
    printf("test_album = %s\n", player->args->album);

    //Calling the function to encode
    add_encode(player);

    player->args->artist != no_changes ? free(player->args->artist) : NULL;

    player->args->copyright != no_changes ? free(player->args->copyright) : NULL;

    player->args->genre != no_changes ? free(player->args->genre) : NULL;

    player->args->name != no_changes ? free(player->args->name) : NULL;

    player->args->album != no_changes ? free(player->args->album) : NULL;

}

gboolean dialog_hide(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    assert(player);
    gtk_widget_hide(widget);
    return TRUE;
}

void about_dialog_hide(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    gtk_widget_hide(GTK_WIDGET(player->ui.about_dialog));
}

void about_dialog_clicked(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    gtk_widget_show(GTK_WIDGET(player->ui.about_dialog));
}

void about_warning_hide(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    gtk_widget_hide(GTK_WIDGET(player->ui.warning_dialog));
}

//convert Dialog
void convert_dialog_clicked(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    gtk_widget_show(GTK_WIDGET(player->ui.convert_dialog));
}

void convert_hide(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    gtk_widget_hide(GTK_WIDGET(player->ui.convert_dialog));
}

//Process when we should change the format of a file
//Also where the warning shows up when there is no file chosen
void convert_button_clicked(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    gtk_widget_show(GTK_WIDGET(player->ui.convert_dialog));
}
//
void convert_warning_hide(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player *player = userdata;
    gtk_widget_hide(GTK_WIDGET(player->ui.warning_dialog));
}