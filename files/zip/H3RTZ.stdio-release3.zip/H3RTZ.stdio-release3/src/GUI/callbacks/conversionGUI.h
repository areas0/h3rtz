#ifndef CONVERSIONGUI_H
#define CONVERSIONGUI_H

#include "../init.h"
void compressFileGUI(GtkWidget *widget, gpointer userdata);
void widgetHideConvert(GtkWidget *widget, gpointer userdata);
#endif