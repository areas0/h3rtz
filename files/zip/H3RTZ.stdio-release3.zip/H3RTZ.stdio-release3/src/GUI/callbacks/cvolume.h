#ifndef CVOLUME_H
#define CVOLUME_H

#include "../init.h"
void cvolume(GtkWidget *widget, gpointer userdata);
void *setDefaultVolume(void *userdata);
#endif
