#include "conversionGUI.h"

void compressFileGUI(GtkWidget *widget, gpointer userdata)
{
    assert(widget);
    gtk_player *player = userdata;
    GtkWidget *dialog;
    GtkFileChooserAction action = GTK_FILE_CHOOSER_ACTION_OPEN;
    gint res;

    dialog = gtk_file_chooser_dialog_new("Choose a file to convert",
                                         player->ui.window,
                                         action,
                                         (gchar *)"_Cancel",
                                         GTK_RESPONSE_CANCEL,
                                         (gchar *)"_Open",
                                         GTK_RESPONSE_ACCEPT,
                                         NULL);

    res = gtk_dialog_run(GTK_DIALOG(dialog));
    if (res == GTK_RESPONSE_ACCEPT)
    {
        char *filename;
        GtkFileChooser *chooser = GTK_FILE_CHOOSER(dialog);
        filename = gtk_file_chooser_get_filename(chooser);
        gtk_widget_destroy(dialog);
        tuple t = ParseTrack(filename);
        wav *w = t.b;
        file *f = t.a;
        // file *f = getData(filename);
        // wav *w = headerParser(f);
        if (w)
        {
            gint res;
            action = GTK_FILE_CHOOSER_ACTION_SAVE;
            dialog = gtk_file_chooser_dialog_new("Choose the output file",
                                                 player->ui.window,
                                                 action,
                                                 "_Cancel",
                                                 GTK_RESPONSE_CANCEL,
                                                 "_Save",
                                                 GTK_RESPONSE_ACCEPT,
                                                 NULL);
            chooser = GTK_FILE_CHOOSER(dialog);

            gtk_file_chooser_set_do_overwrite_confirmation(chooser, TRUE);
            // gtk_file_chooser_set_filename(chooser,filename);
            gtk_file_chooser_set_current_name(chooser,
                                              "default.wav");

            res = gtk_dialog_run(GTK_DIALOG(dialog));
            if (res == GTK_RESPONSE_ACCEPT)
            {
                char *filename_out;

                filename_out = gtk_file_chooser_get_filename(chooser);
                gtk_widget_destroy(dialog);
                if (w->fmt->AudioFormat == PCM)
                {
                    convertFile(filename, filename_out);
                }
                else if (w->fmt->AudioFormat == h3rtz)
                {
                    decodeFile(filename, filename_out);
                }
                gtk_widget_show(player->ui.convert_done);
                g_free(filename_out);
            }
            else
            {
                gtk_widget_destroy(dialog);
            }
            freeWav(w);
        }
        freeFile(f);
        g_free(filename);
    }
    else
    {
        gtk_widget_destroy(dialog);
    }
}

void widgetHideConvert(GtkWidget *widget, gpointer userdata)
{
    gtk_player *player = userdata;
    assert(widget);
    gtk_widget_hide(GTK_WIDGET(player->ui.convert_done));
}