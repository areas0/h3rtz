#ifndef PROGRESS_H
#define PROGRESS_H

#include "../init.h"
#if DEPRECATED
gboolean fill(GtkProgressBar *progress_bar);
void *playerProgress(void *userdata);
int playerProgressV2(void *userdata);
#endif
#endif