#ifndef CLICK_EDIT_H
#define CLICK_EDIT_H

#include "../init.h"
void click_edit(GtkWidget *widget, gpointer userdata);
gboolean dialog_hide(GtkWidget *widget, gpointer userdata);
void about_dialog_hide(GtkWidget *widget, gpointer userdata);
void about_warning_hide(GtkWidget *widget, gpointer userdata);
void clicked_save(GtkWidget *widget, gpointer userdata);
void about_dialog_clicked(GtkWidget *widget, gpointer userdata);
//Convert
void convert_warning_hide(GtkWidget *widget, gpointer userdata);
void convert_hide(GtkWidget *widget, gpointer userdata);
void convert_dialog_clicked(GtkWidget *widget, gpointer userdata);
void convert_button_clicked(GtkWidget *widget, gpointer userdata);
void updateFields(gtk_player *player);
#endif
