#ifndef EXIT_H
#define EXIT_H

#include "../init.h"

// Quits the interface
// @param userdata: gtk_player currently used
void on_quit(GtkWidget *widget, gpointer userdata);

#endif