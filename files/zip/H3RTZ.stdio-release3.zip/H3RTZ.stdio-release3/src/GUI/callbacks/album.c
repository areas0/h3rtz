#include "album.h"

void album(gpointer userdata)
{
    gtk_player *player = userdata;
    fileInfo *info;
    info = getFileInfo(player->player->player->info->list);
    gtk_label_set_text(player->ui.album,  info->product ? info->product:
                       info->album ? info->album : "Unknown");
    free(info);
}
