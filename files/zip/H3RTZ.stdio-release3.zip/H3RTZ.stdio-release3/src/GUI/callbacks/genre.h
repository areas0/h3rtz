#ifndef GENRE_H
#define GENRE_H
#include "../init.h"

void genre(gpointer userdata);

#endif
