#ifndef PLAYERSTATE_H
#define PLAYERSTATE_H

#include "../init.h"
// Sub callback function to play a track
void on_play(gtk_player *g);
// sub callback function to pause a track
void on_pause(gtk_player *g);
// Entry callback to toggle UI elements & pause/play audio
// @param userdata: a gtk_player
void toggle(GtkWidget *widget, gpointer userdata);
#endif
