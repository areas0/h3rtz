#include "progress.h"
#if DEPRECATED
// Call this function with pthread_create and with final arg the gtk player
// this function will update every few seconds the progress bar

gboolean fill(GtkProgressBar *progress_bar)
{
  //Get the current progress
  gdouble fraction;
  fraction = gtk_progress_bar_get_fraction (GTK_PROGRESS_BAR (progress_bar));
  //Increase the bar by 10% each time this function is called
  fraction += 0.1;
  //Fill in the bar with the new fraction
  gtk_progress_bar_set_fraction (GTK_PROGRESS_BAR (progress_bar), fraction);
  //percentage display
  char c[3];
  gtk_progress_bar_set_text(progress_bar, c);
  //Ensures that the fraction stays below 1.0
  if (fraction < 1.0)
    return TRUE;
  return FALSE;
}

void *playerProgress(void *userdata)
{
    gtk_player *player = userdata;
    pa_player *pulseAudio = player->player;
    // Constant
    double power = pow(10, 6);
    // Total duration computation: nb bytes in file / bitrate
    double duration = (double) pulseAudio->player->info->data->data_bytes/
    (double) pulseAudio->player->info->fmt->bitrate;
    double ratio = 0;
    pthread_t t;
    pthread_create(&t, NULL, &synchronize, player->player);
    pthread_detach(t);
    while (pulseAudio->pa_state == PLAYING || pulseAudio->pa_state == PAUSED)
    {
      int w,p;
      sem_getvalue(&pulseAudio->utility->wait, &w);
      sem_getvalue(&pulseAudio->utility->play, &p);
      printf("Pre Semaphores: %d %d\n", w,p);
      // locks till one second has passed
      sem_wait(&pulseAudio->utility->wait);
      // locks till the player has resumed
      sem_wait(&pulseAudio->utility->play);
      // sets it back to one to restore
      sem_post(&pulseAudio->utility->play);
      sem_getvalue(&pulseAudio->utility->wait, &w);
      sem_getvalue(&pulseAudio->utility->play, &p);
      printf("Post Semaphores: %d %d\n", w,p);
      updateLatency(pulseAudio);
      // computations
      double timing = pulseAudio->player->time;
      // converts to microseconds
      timing *= power;
      double wLatency = timing - (double) *(pulseAudio->pulseAudio->latency);
      //printf("%lf %lf\n", wLatency, wLatency/power);
      ratio = ((wLatency/power))/ duration;
      printf("Ratio: %lf\n", ratio);
      // update the progress bar
      gtk_progress_bar_set_fraction (GTK_PROGRESS_BAR (player->ui.progress_bar), ratio);
      // sleeps for one second
      //sleep(1);
    }
    return NULL;
}

int playerProgressV2(void *userdata)
{
  gtk_player *player = userdata;
  pa_player *pulseAudio = player->player;
  if (player->player->pa_state >= DRAINED)
  {
    // 100% completion for interruption
    gtk_progress_bar_set_fraction(GTK_PROGRESS_BAR(player->ui.progress_bar), 1.0);
    // disables callback
    g_source_remove(player->ui.ID);
    return FALSE;
  }
  double power = pow(10, 6);
  // Constant
  // Total duration computation: nb bytes in file / bitrate
  double duration = (double)pulseAudio->player->info->data->data_bytes /
                    (double)pulseAudio->player->info->fmt->bitrate;
  double ratio = 0;
  updateLatency(pulseAudio);
  // computations
  double timing = pulseAudio->player->time;
  // converts to microseconds
  timing *= power;
  double wLatency = timing - (double)*(pulseAudio->pulseAudio->latency);
  ratio = ((wLatency / power)) / duration;
  printf("Ratio: %lf\n", ratio);
  // update the progress bar
  gtk_progress_bar_set_fraction(GTK_PROGRESS_BAR(player->ui.progress_bar), ratio);
  return TRUE;
}
#endif