#ifndef PLAYLIST_H
#define PLAYLIST_H

#include "../init.h"

enum {
  LIST_ITEM = 0,
  N_COLUMNS
};
extern pthread_mutex_t playlist_l;
void append(GtkWidget *widget, gpointer userdata);
void remove_item(GtkWidget *widget, gpointer userdata);
void remove_all(GtkWidget *widget, gpointer userdata);
void init_list(gpointer userdata);
ssize_t findIndex(gtk_player *player, gchar *key);
void itemSelection(GtkTreeView *tree_view,
                   GtkTreePath *path,
                   GtkTreeViewColumn *column,
                   gpointer userdata);
#endif