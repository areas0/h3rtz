#include "title.h"

void changeTitle(gpointer userdata)
{
    gtk_player *player = userdata;
    fileInfo *info;
    info = getFileInfo(player->player->player->info->list);
    gtk_label_set_text(player->ui.name, info->artists ? info->artists : "Unknown");
    free(info);
}

