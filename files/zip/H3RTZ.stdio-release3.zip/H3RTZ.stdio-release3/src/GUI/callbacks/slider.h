#ifndef SLIDER_H
#define SLIDER_H

#include "../init.h"

int slider(void *userdata);
void changePosition(GtkWidget *widget, gpointer userdata);
#endif