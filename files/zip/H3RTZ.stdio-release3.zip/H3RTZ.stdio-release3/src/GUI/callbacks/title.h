#ifndef TITLE_H
#define TITLE_H

#include "../init.h"
void changeTitle(gpointer userdata);
#endif
