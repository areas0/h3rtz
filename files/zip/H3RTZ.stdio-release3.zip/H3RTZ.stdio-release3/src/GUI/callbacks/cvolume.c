#include "cvolume.h"
#include <stdio.h>

void cvolume(GtkWidget *widget __attribute__((unused)), gpointer userdata)
{
    gtk_player* player = userdata;
    if (player->player->pa_state != ACTIVE)
        return;
    gdouble value = gtk_scale_button_get_value(GTK_SCALE_BUTTON(player->ui.volume));
    player->player->info->volume = value;
    setVolume(player->player);
    return;
}
// USED WITH PTHREAD
void *setDefaultVolume(void *userdata)
{
    gtk_player *player = userdata;
    // gets the default volume for our application
    getVolume(player->player);
    // sets it as a value for our slider
    gtk_scale_button_set_value(GTK_SCALE_BUTTON(player->ui.volume),
    player->player->info->volume);
    return NULL;
}
