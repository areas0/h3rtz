#include "chooser_dialog.h"

void chooser_dialog(GtkWidget *widget, gpointer userdata)
{
    gtk_player *player = userdata;
    player->ui.name_chooser = malloc(sizeof(char) * 200);
    player->ui.name_chooser = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(widget));
}
