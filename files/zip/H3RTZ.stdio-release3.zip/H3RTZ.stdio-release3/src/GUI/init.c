#include "init.h"

//Macro to check
#define CHECK(button)                                     \
    if (button == NULL)                                   \
    {                                                     \
        fprintf(stderr, "Error: can't get the button\n"); \
        exit(EXIT_FAILURE);                               \
    }

GtkWindow *window;
gchar *path; //the path to the audio file look at fct audio_chooser

void free_player(gtk_player player)
{
    //freeing elements that were malloc'd
    free(player.new_wav);
    free(player.playlist);
    free(player.args);
}

void init_interface(void)
{
    GtkBuilder *builder;

    //Initialize GTK
    gtk_init(NULL, NULL);

    // Establish contact with glade xml code used to adjust widget setting
    builder = gtk_builder_new();
    GError *error = NULL;
    if (gtk_builder_add_from_file(builder, "./stdio.glade", &error) == 0)
    {
        fprintf(stderr, "Error: can't open the XML file %s\n", error->message);
        exit(EXIT_FAILURE);
    }

    //create window using the builder
    window = GTK_WINDOW(gtk_builder_get_object(builder, "window"));

    GtkFileChooserButton *audio_chooser_button = GTK_FILE_CHOOSER_BUTTON(
        gtk_builder_get_object(builder, "audio_chooser"));
    CHECK(audio_chooser_button);

    GtkFileChooser *audio_chooser = GTK_FILE_CHOOSER(
        gtk_builder_get_object(builder, "audio_chooser"));
    CHECK(audio_chooser);

    GtkButton *play_pause = GTK_BUTTON(
        gtk_builder_get_object(builder, "play_pause"));
    CHECK(play_pause);

    GtkButton *forward = GTK_BUTTON(
        gtk_builder_get_object(builder, "next"));
    CHECK(forward);

    GtkButton *backward = GTK_BUTTON(
        gtk_builder_get_object(builder, "previous"));
    CHECK(backward);

    GtkVolumeButton *volume = GTK_VOLUME_BUTTON(
        gtk_builder_get_object(builder, "volume"));
    CHECK(volume);

    GtkScale *slider = GTK_SCALE(
        gtk_builder_get_object(builder, "slider"));
    CHECK(slider);

    GtkAdjustment *adjustment1 = GTK_ADJUSTMENT(
        gtk_builder_get_object(builder, "adjustment1"));
    CHECK(adjustment1);

    GtkLabel *name = GTK_LABEL(
        gtk_builder_get_object(builder, "name"));
    CHECK(name);

    GtkLabel *genre = GTK_LABEL(
        gtk_builder_get_object(builder, "genre"));
    CHECK(genre);

    GtkLabel *album = GTK_LABEL(
        gtk_builder_get_object(builder, "album"));
    CHECK(album);

    GtkListStore *dialog_list_store = GTK_LIST_STORE(
        gtk_builder_get_object(builder, "dialog_list_store"));
    CHECK(dialog_list_store);

    GtkTreeView *dialog_tree = GTK_TREE_VIEW(
        gtk_builder_get_object(builder, "dialog_tree"));
    CHECK(dialog_tree);

    GtkTreeSelection *select = GTK_TREE_SELECTION(
        gtk_builder_get_object(builder, "select"));
    CHECK(select);

    GtkButton *dialog_remove = GTK_BUTTON(
        gtk_builder_get_object(builder, "dialog_remove"));
    if (dialog_remove == NULL)
    {
        fprintf(stderr, "Error: can't get the button dialog_remove\n");
        exit(EXIT_FAILURE);
    }

    GtkButton *dialog_remove_all = GTK_BUTTON(
        gtk_builder_get_object(builder, "dialog_remove_all"));
    if (dialog_remove_all == NULL)
    {
        fprintf(stderr, "Error: can't get the button dialog_remove_all\n");
        exit(EXIT_FAILURE);
    }

    GtkButton *dialog_add = GTK_BUTTON(
        gtk_builder_get_object(builder, "dialog_add"));
    if (dialog_add == NULL)
    {
        fprintf(stderr, "Error: can't get the button dialog_add\n");
        exit(EXIT_FAILURE);
    }

    GtkWidget *window1 = GTK_WIDGET(
        gtk_builder_get_object(builder, "window1"));
    if (window1 == NULL)
    {
        fprintf(stderr, "Error: can't get the button window1\n");
        exit(EXIT_FAILURE);
    }

    GtkWidget *warning_dialog = GTK_WIDGET(
        gtk_builder_get_object(builder, "warning_dialog"));
    if (warning_dialog == NULL)
    {
        fprintf(stderr, "Error: can't get the button warning_dialog\n");
        exit(EXIT_FAILURE);
    }

    GtkWidget *dialog_edit = GTK_WIDGET(
        gtk_builder_get_object(builder, "dialog_edit"));
    if (dialog_edit == NULL)
    {
        fprintf(stderr, "Error: can't get the button dialog_edit\n");
        exit(EXIT_FAILURE);
    }

    GtkWidget *about_dialog = GTK_WIDGET(
        gtk_builder_get_object(builder, "about_dialog"));
    if (about_dialog == NULL)
    {
        fprintf(stderr, "Error: can't get the button about_dialog\n");
        exit(EXIT_FAILURE);
    }

    GtkButton *edit_info = GTK_BUTTON(
        gtk_builder_get_object(builder, "edit_info"));
    if (edit_info == NULL)
    {
        fprintf(stderr, "Error: can't get the button edit_info\n");
        exit(EXIT_FAILURE);
    }

    // GtkButton *about_close = GTK_BUTTON(
    // gtk_builder_get_object(builder, "about_close"));
    // if (about_close == NULL)
    // {
    //     fprintf(stderr, "Error: can't get the button about_close\n");
    //     exit(EXIT_FAILURE);
    // }

    // GtkButton *dialog_close = GTK_BUTTON(
    //     gtk_builder_get_object(builder, "dialog_close"));
    // if (dialog_close == NULL)
    // {
    //     fprintf(stderr, "Error: can't get the button dialog_close\n");
    //     exit(EXIT_FAILURE);
    // }
    GtkLabel *dialog_name = GTK_LABEL(
        gtk_builder_get_object(builder, "dialog_name"));
    if (dialog_name == NULL)
    {
        fprintf(stderr, "Error: can't get the button dialog_name\n");
        exit(EXIT_FAILURE);
    }

    GtkLabel *dialog_genre = GTK_LABEL(
        gtk_builder_get_object(builder, "dialog_genre"));
    if (dialog_genre == NULL)
    {
        fprintf(stderr, "Error: can't get the button dialog_genre\n");
        exit(EXIT_FAILURE);
    }

    GtkLabel *dialog_copyrights = GTK_LABEL(
        gtk_builder_get_object(builder, "dialog_copyrights"));
    if (dialog_copyrights == NULL)
    {
        fprintf(stderr, "Error: can't get the button dialog_copyrights\n");
        exit(EXIT_FAILURE);
    }

    GtkLabel *dialog_artist = GTK_LABEL(
        gtk_builder_get_object(builder, "dialog_artist"));
    if (dialog_artist == NULL)
    {
        fprintf(stderr, "error: can't get the button dialog_artist\n");
        exit(EXIT_FAILURE);
    }

    GtkLabel *dialog_album = GTK_LABEL(
        gtk_builder_get_object(builder, "dialog_album"));
    if (dialog_album == NULL)
    {
        fprintf(stderr, "error: can't get the button dialog_album\n");
        exit(EXIT_FAILURE);
    }

    GtkButton *dialog_save = GTK_BUTTON(
        gtk_builder_get_object(builder, "dialog_save"));
    if (dialog_save == NULL)
    {
        fprintf(stderr, "error: can't get the button dialog_save\n");
        exit(EXIT_FAILURE);
    }

    GtkButton *about = GTK_BUTTON(
        gtk_builder_get_object(builder, "about"));
    if (about == NULL)
    {
        fprintf(stderr, "error: can't get the button about\n");
        exit(EXIT_FAILURE);
    }

    GtkButton *ok_warning = GTK_BUTTON(
        gtk_builder_get_object(builder, "ok_warning"));
    if (ok_warning == NULL)
    {
        fprintf(stderr, "error: can't get the button ok_warning\n");
        exit(EXIT_FAILURE);
    }
    //GktEntry
    GtkEntry *artist_text = GTK_ENTRY(
        gtk_builder_get_object(builder, "artist_text"));
    if (artist_text == NULL)
    {
        fprintf(stderr, "Error: can't get the button artist_text\n");
        exit(EXIT_FAILURE);
    }

    GtkEntry *copyright_text = GTK_ENTRY(
        gtk_builder_get_object(builder, "copyright_text"));
    if (copyright_text == NULL)
    {
        fprintf(stderr, "Error: can't get the button copyright_text\n");
        exit(EXIT_FAILURE);
    }

    GtkEntry *genre_text = GTK_ENTRY(
        gtk_builder_get_object(builder, "genre_text"));
    if (genre_text == NULL)
    {
        fprintf(stderr, "Error: can't get the button genre_text\n");
        exit(EXIT_FAILURE);
    }

    GtkEntry *name_text = GTK_ENTRY(
        gtk_builder_get_object(builder, "name_text"));
    if (name_text == NULL)
    {
        fprintf(stderr, "error: can't get the button name_text\n");
        exit(EXIT_FAILURE);
    }

    GtkEntry *album_text = GTK_ENTRY(
        gtk_builder_get_object(builder, "album_text"));
    if (album_text == NULL)
    {
        fprintf(stderr, "error: can't get the button album_text\n");
        exit(EXIT_FAILURE);
    }

    //COnvert Dialog

    GtkButton *convert_button = GTK_BUTTON(
        gtk_builder_get_object(builder, "convert_button"));
    if (convert_button == NULL)
    {
        fprintf(stderr, "error: can't get the button convert_button\n");
        exit(EXIT_FAILURE);
    }

    GtkImage *song_image = GTK_IMAGE(
        gtk_builder_get_object(builder, "song_image"));
    if (song_image == NULL)
    {
        fprintf(stderr, "error: can't get the button song_image\n");
        exit(EXIT_FAILURE);
    }

    GtkWidget *convert_wait = GTK_WIDGET(
        gtk_builder_get_object(builder, "convert_wait"));
    if (convert_wait == NULL)
    {
        fprintf(stderr, "error: can't get the button convert_wait\n");
        exit(EXIT_FAILURE);
    }

    GtkWidget *convert_done = GTK_WIDGET(
        gtk_builder_get_object(builder, "convert_done"));
    if (convert_done == NULL)
    {
        fprintf(stderr, "error: can't get the button convert_done\n");
        exit(EXIT_FAILURE);
    }
    
    GtkButton *convert_warning_close2 = GTK_BUTTON(
    gtk_builder_get_object(builder, "convert_warning_close2"));
    if (ok_warning == NULL)
    {
        fprintf(stderr, "error: can't get the button convert_warning_close2\n");
        exit(EXIT_FAILURE);
    }

    //Start player
    gtk_player player = {
        .data = NULL,
        .filename = NULL,
        .player = NULL,
        .new_wav = malloc(BUFFER_SIZE),
        .ui =
            {
                .window = window,
                .dialog_edit = dialog_edit,
                .about_dialog = about_dialog,
                .play_pause = play_pause,
                .volume = volume,
                .ID = 0,
                .slider = slider,
                .adjustment = adjustment1,
                .name_chooser = NULL,
                .dialog_list_store = dialog_list_store,
                .dialog_tree = dialog_tree,
                .select = select,
                .name = name,
                .genre = genre,
                .album = album,
                .audio_chooser = audio_chooser,
                // .about_close = about_close,
                .dialog_name = dialog_name,
                .dialog_genre = dialog_genre,
                .dialog_copyrights = dialog_copyrights,
                .dialog_artist = dialog_artist,
                .dialog_album = dialog_album,
                .artist_text = artist_text,
                .copyright_text = copyright_text,
                .genre_text = genre_text,
                .name_text = name_text,
                .album_text = album_text,
                .warning_dialog = warning_dialog,
                .convert_wait = convert_wait,
                .convert_done = convert_done,
                .song_image = song_image,
            },
        .playlist = calloc(1, sizeof(playlist_t)),
        .args = malloc(sizeof(text_entry)),
    };

    if (initPulsePlayer(&(player.player)) == -1)
        errx(EXIT_FAILURE, "Failed to initialize the player, \
                check that PulseAudio is started and running...");
    if (init_player(player.player) == -1)
        errx(EXIT_FAILURE, "Failed to initialize the player, \
                check that PulseAudio is started and running...");
    // inits a playlist
    initStaticPlaylist(player.playlist);
    init_list(&player);

    //Connect event handlers
    gtk_builder_connect_signals(builder, NULL);
    g_signal_connect(audio_chooser_button, "file_set", G_CALLBACK(on_choose_wav), &player);
    g_signal_connect(play_pause, "clicked", G_CALLBACK(toggle), &player);
    g_signal_connect(window, "delete_event", G_CALLBACK(gtk_main_quit), &player);
    g_signal_connect(volume, "value-changed", G_CALLBACK(cvolume), &player);
    g_signal_connect(adjustment1, "value-changed", G_CALLBACK(changePosition), &player);
    g_signal_connect(dialog_add, "clicked", G_CALLBACK(append), &player);
    g_signal_connect(dialog_remove, "clicked", G_CALLBACK(remove_item), &player);
    g_signal_connect(dialog_remove_all, "clicked", G_CALLBACK(remove_all), &player);
    g_signal_connect(dialog_save, "clicked", G_CALLBACK(clicked_save), &player);
    g_signal_connect(forward, "clicked", G_CALLBACK(forward_cb), &player);
    g_signal_connect(backward, "clicked", G_CALLBACK(backward_cb), &player);
    //g_signal_connect(dialog_close, "clicked", G_CALLBACK(dialog_hide), &player);
    g_signal_connect(about, "clicked", G_CALLBACK(about_dialog_clicked), &player);
    //g_signal_connect(about_close, "clicked", G_CALLBACK(about_dialog_hide), &player);
    // g_signal_connect(about_close, "clicked", G_CALLBACK(about_dialog_hide), &player);
    g_signal_connect(ok_warning, "clicked", G_CALLBACK(about_warning_hide), &player);
    //signals for the convert
    g_signal_connect(convert_button, "clicked", G_CALLBACK(compressFileGUI), &player);
    // connects the signal for double click event
    g_signal_connect(player.ui.dialog_tree, "row-activated", G_CALLBACK(itemSelection), &player);
    g_signal_connect(edit_info, "clicked", G_CALLBACK(click_edit), &player);
    g_signal_connect(dialog_edit, "delete-event", G_CALLBACK(dialog_hide), &player);
    g_signal_connect(about_dialog, "delete-event", G_CALLBACK(dialog_hide), &player);
    g_signal_connect(convert_warning_close2, "clicked", G_CALLBACK(widgetHideConvert), &player);
    //Set
    gtk_widget_set_size_request(GTK_WIDGET(window), 820, 920);
    gtk_widget_set_size_request(GTK_WIDGET(window1), 100, 200);
    gtk_window_set_resizable(window, TRUE);
    GtkWidget *image = gtk_image_new_from_file("./icons/play.png");
    gtk_button_set_image(GTK_BUTTON(player.ui.play_pause), image);
    gtk_widget_show(GTK_WIDGET(window));
    //Execute loop GTK
    gtk_main();
    // cleans up PulseAudio stuff with playlist
    Pause(player.player);
    terminateStream(player.player);
    freePlaylist(player.playlist);
    player.player->player->info = 0;
    player.player->player->track = 0;
    pa_context_unref(player.player->pulseAudio->context);
    pa_threaded_mainloop_stop(player.player->pulseAudio->loop);
    pa_threaded_mainloop_free(player.player->pulseAudio->loop);
    freePulsePlayer(player.player);
    free(player.args);
    free(player.new_wav);

    g_object_unref(G_OBJECT(builder));
    gtk_window_close(window);
    gtk_widget_destroy(GTK_WIDGET(window));
    gtk_widget_destroy(GTK_WIDGET(audio_chooser_button));
}
