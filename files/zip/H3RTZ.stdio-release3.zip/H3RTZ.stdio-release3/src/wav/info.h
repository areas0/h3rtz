#ifndef INFO_H
#define INFO_H

#include "headerwav.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parser.h"

typedef enum infoIds
{
    IARL = 0x4941524C, // archival location
    IART = 0x49415254, // artist
    ICMS = 0x49434D53, //commisionned
    ICMT = 0x49434D54, // comments
    ICOP = 0x49434F50, // copyright
    ICRD = 0x49435244, // creation date
    // skipped some codes (image related)
    IGNR = 0x49474E52, // genre
    IKEY = 0x494B4559, // keywords
    INAM = 0x494E414D, // name
    ISBJ = 0x4953424A, // content of the file
    ISFT = 0x49534654, // software
    ISRC = 0x49535243, // source
    IPRD = 0x49505244, // Product
    IPRT = 0x49505254, // track id
} infoIds;

typedef struct fileInfo
{
    char *archival;
    char *artists;
    char *commissioned;
    char *comments;
    char *copyrights;
    char *creationDate;
    char *genre;
    char *keywords;
    char *name;
    char *album;
    char *software;
    char *source;
    char *product;
    int tracknb;
} fileInfo;

list *listParser(unsigned char *data, size_t *i);
info *infoParser(unsigned char *data, size_t *j);
fileInfo *getFileInfo(list *list);
void printFileInfo(fileInfo *f);
void freeList(list *l);
void freeInfo(info *i);
void printFileInfo(fileInfo *f);
#endif