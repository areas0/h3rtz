#ifndef HEADERWAV_H
#define HEADERWAV_H
// this file contains the standard header data for the project

// types of fmt chunks
typedef enum fmt_type
{
    CLASSIC_PCM,
    FLOAT_PCM,
    EXTENSIBLE,
    UNKNOWN,
} fmt_type;

typedef struct riff
{
    char riff[4];//contains 4 bytes
    int fileSize; //contains 4 bytes
    char fileFormatId[4]; // contains 4 bytes
} riff;

typedef struct fmt
{
    char fmt[4]; //format block id 4B
    int blocSize; // classic 16b

    unsigned short AudioFormat; //2B see enum compression_codes
    short channel; //2B

    int sampling_freq; // 4B
    int bitrate; //important 4B //number of bytes to read per sec
    short blocrate; //2B NbrChannels * BitsPerSample/8
    short samplerate; //2B //8-16-24 bits
} fmt;
// 18 bytes fmt block for IEE float PCM
typedef struct fmt_float
{
    char fmt[4]; //format block id 4B
    int blocSize; // will be 18

    unsigned short AudioFormat; //2B see enum compression_codes
    short channel; //2B

    int sampling_freq; // 4B
    int bitrate; //important 4B //number of bytes to read per sec
    short blocrate; //2B NbrChannels * BitsPerSample/8
    short samplerate; //2B //8-16-24 bits
    short wExtSize;
} fmt_float;
// 40 bytes bloc WAVE_EXTENSIBLE
typedef struct fmt_extensible
{
    char fmt[4]; //format block id 4B
    int blocSize; // will be 18

    unsigned short AudioFormat; //2B see enum compression_codes
    short channel; //2B

    int sampling_freq; // 4B
    int bitrate; //important 4B //number of bytes to read per sec
    short blocrate; //2B NbrChannels * BitsPerSample/8
    short samplerate; //2B //8-16-24 bits

    short extension_size;
    short valid_bytes_ps;
    int channel_mask;
    char sub_format[16]; //contains the new format
} fmt_extensible;

typedef struct data
{
    char data[4]; // entry point for real data boi
    int data_bytes; //number of bytes in the data chunk
    unsigned char *chunk;
} data;

typedef struct fact
{
    char fact[4];
    int chunk_size;
    int nb_samples;
} fact;
// Contains various info
// linked list with sentinel structure
typedef struct info
{
    char infoId[4];
    unsigned int size;
    char *data;
    struct info *next;
} info;

typedef struct list
{
    char list[4];
    int chunk_size;
    unsigned char *data;
    struct info *infos;
} list;

// this generic type contains all wav chunks
// Warning: some can be null
typedef struct wav
{
    riff *riff; // cannot be modified
    union // store both types at the same place: memory efficient
    {
        fmt *fmt;
        fmt_float *fmt_float;
        fmt_extensible *fmt_extensible;
    };
    fact *fact; // optional: often used for float
    struct data *data; // invariable
    fmt_type format; // casting helper
    list *list;
} wav;

#endif