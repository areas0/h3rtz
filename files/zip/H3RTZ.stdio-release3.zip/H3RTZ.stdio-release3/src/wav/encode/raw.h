#ifndef RAW_H
#define RAW_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <err.h>
#include <errno.h>
#include <sys/types.h>
#include <pulse/pulseaudio.h>
#include <pulse/simple.h>
#include "../wav.h"
#include "../info.h"
#include "../headerwav.h"
#define BUFFER_SIZE 128

// safe write
void rewrite(int fd, const void *buf, size_t count, char *err_msg);

// safe read
void reread(int fd, void *buf, size_t count, char *err_msg);

//writes a new wave file with given header and nnew wav file
void write_wav(char *raw_file, char **new_wav, struct wav *header);

//writes the raw PCM signal
void write_raw(char *path, char **raw_file, struct wav *header);

//writes a new header into fd
void write_header(int fd, struct wav *header);

//writes n null bytes for padding
void write_space(int fd, size_t n);

//adds the new list to current wav header
void add_wav(char *src, char *raw_file, char *argv[], char *new_wav);

#endif
