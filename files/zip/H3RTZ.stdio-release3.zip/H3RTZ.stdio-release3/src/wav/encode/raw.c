#include "raw.h"

// safe write
void rewrite(int fd, const void *buf, size_t count, char *err_msg)
{
    int r;
    size_t offset = 0;
    while (offset < count)
    {
        r = write(fd, buf + offset, count - offset);
        if (r == -1)
        {
            r = errno;
            errx(EXIT_FAILURE, "failed to write %s into fd: %s", err_msg, strerror(r));
        }
        if (r == 0)
        {
            break;
        }
        offset += r;
    }
}

// safe read
void reread(int fd, void *buf, size_t count, char *err_msg)
{
    int r;
    size_t offset = 0;
    while (offset < count)
    {
        r = read(fd, buf + offset, count - offset);
        if (r == -1)
        {
            r = errno;
            errx(EXIT_FAILURE, "failed to read %s from fd: %s", err_msg, strerror(r));
        }
        if (r == 0)
        {
            break;
        }
        offset += r;
    }
}

//write a new wave file with given header and file
void write_wav(char *raw_file, char **new_wav, struct wav *header)
{
    int ret = open(raw_file, O_RDONLY);

    if (ret < 0)
    {
        errx(EXIT_FAILURE, "open raw file failed\n");
    }

    //creating repetition file
    char *new_file = malloc(BUFFER_SIZE);

    strcpy(new_file, raw_file);
    new_file[strlen(new_file) - 4] = 0;
    strcat(new_file, "_2.wav");

    strcpy(*new_wav, new_file);
    free(new_file);

    int res = open(*new_wav, O_CREAT | O_WRONLY, 0666);

    if (res < 0)
    {
        errx(EXIT_FAILURE, "failed to create new file");
    }

    struct stat st;
    int stat = fstat(ret, &st);

    if (stat == -1)
    {
        errx(EXIT_FAILURE, "stat on raw file failed\n");
    }

    //write header
    write_header(res, header);

    int raw_size = st.st_size;
    char *buf = malloc(raw_size * sizeof(char));

    reread(ret, buf, raw_size, "raw data");

    //write .raw into .wav
    rewrite(res, buf, raw_size, "new wav");

    free(buf);
}

//writes the raw signal + data structure
void write_raw(char *path, char **raw_file, struct wav *header)
{
    char *buf = malloc(header->data->data_bytes);
    char *new_file = malloc(BUFFER_SIZE);

    strcpyn((unsigned char *)path, new_file, strlen(path) + 1);
    new_file[strlen(new_file) - 4] = 0;
    strcat(new_file, ".raw");
    strcpy(*raw_file, new_file);

    int fd_write = open(*raw_file, O_CREAT | O_WRONLY | O_TRUNC, 0666);

    rewrite(fd_write, header->data->chunk, header->data->data_bytes, "raw data");

    free(buf);
    free(new_file);
}

//writes a new header into fd
void write_header(int fd, struct wav *header)
{
    //Writing riff chunk header
    rewrite(fd, header->riff, sizeof(riff), "riff chunk");

    //write fmt chunk
    switch (header->format)
    {
    case CLASSIC_PCM:
        rewrite(fd, header->fmt, sizeof(fmt), "classic PCM");
        break;

    case FLOAT_PCM:
        rewrite(fd, header->fmt_float, sizeof(fmt_float), "float PCM");
        rewrite(fd, header->fact, sizeof(fact), "fact PCM");
        break;

    case EXTENSIBLE:
        rewrite(fd, header->fmt_extensible, sizeof(struct fmt_extensible), "extensible PCM");
        break;
    default:
        errx(EXIT_FAILURE, "unknown format\n");
        break;
    }

    //writing nested data chunk
    if (header->list != NULL)
    {
        rewrite(fd, header->list->list, 4, "LIST");
        char chunk_size[8];

        int size = sprintf(chunk_size, "%c", header->list->chunk_size);

        rewrite(fd, chunk_size, size, "list chunk size");

        //weird spacing found in file
        write_space(fd, 3);

        //infos struct writing
        for (info *i = header->list->infos; i != NULL; i = i->next)
        {
            rewrite(fd, i->infoId, 4, "infoID");

            //writing size
            if (i->size)
            {
                char size_buf[4];
                size = sprintf(size_buf, "%c", i->size);
                char *error_buf = malloc(BUFFER_SIZE);
                sprintf(error_buf, "info size on %s", i->infoId);

                rewrite(fd, size_buf, size, error_buf);
                free(error_buf);
            }

            if (i->data != NULL)
            {
                write_space(fd, 3);
                int chunk_size = i->size;

                char *error_buf = malloc(BUFFER_SIZE);
                sprintf(error_buf, "info data on %s", i->infoId);

                rewrite(fd, i->data, chunk_size, error_buf);
                free(error_buf);

                if (chunk_size % 2 != 0 || i->data[chunk_size - 1] != '\0')
                {
                    write_space(fd, 1);
                }
            }
        }
    }

    rewrite(fd, header->data->data, 4, "data string");
    unsigned char chunk_size[4]; // holding an int
    int data_bytes = header->data->data_bytes;

    chunk_size[0] = data_bytes & 0xFF;
    chunk_size[1] = (data_bytes >> 8) & 0xFF;
    chunk_size[2] = (data_bytes >> 16) & 0xFF;
    chunk_size[3] = (data_bytes >> 24) & 0xFF;

    for (size_t i = 0; i < 4; i++)
    {
        rewrite(fd, &chunk_size[i], 1, "data size");
    }
}

//writes n null bytes for spacing
void write_space(int fd, size_t n)
{
    for (size_t i = 0; i < n; i++)
    {
        unsigned char hex = 0x0;
        rewrite(fd, &hex, 1, "spacing");
    }
}

void add_wav(char *src, char *raw_file, char *argv[], char *new_wav)
{
    /* Convention for argv:
    0: Artist
    1: Copyrights
    2: Genre
    3: Name
    4: Album
    */

    file *first_file = getData(src);
    wav *header = headerParser(first_file);
    int freed[5] = {0};
    int check[5] = {0};
    info *current = header->list->infos;

    for (; current->next; current = current->next)
    {
        switch (uintConversionBE((unsigned char *)current->infoId))
        {
        case IART:
            if (strcmp(argv[0], "No changes") != 0)
            {
                check[0] = 1;
                int diff = (strlen(argv[0]) + 1) - current->size;
                current->size += diff;
                header->list->chunk_size += diff;
                header->riff->fileSize += diff;
                printf("diff on %s: %d\n", current->infoId, diff);
                current->data = argv[0];
            }
            break;
        case ICOP:
            if (strcmp(argv[1], "No changes") != 0)
            {
                check[1] = 1;
                int diff = (strlen(argv[1]) + 1) - current->size;
                current->size += diff;
                header->list->chunk_size += diff;
                header->riff->fileSize += diff;
                printf("diff on %s: %d\n", current->infoId, diff);
                current->data = argv[1];
            }
            break;
        case IGNR:
            if (strcmp(argv[2], "No changes") != 0)
            {
                check[2] = 1;
                int diff = (strlen(argv[2]) + 1) - current->size;
                current->size += diff;
                header->list->chunk_size += diff;
                header->riff->fileSize += diff;
                printf("diff on %s: %d\n", current->infoId, diff);
                current->data = argv[2];
            }
            break;
        case INAM:
            if (strcmp(argv[3], "No changes") != 0)
            {
                check[3] = 1;
                int diff = (strlen(argv[3]) + 1) - current->size;
                current->size += diff;
                header->list->chunk_size += diff;
                header->riff->fileSize += diff;
                printf("diff on %s: %d\n", current->infoId, diff);
                current->data = argv[3];
            }
            break;
        case ISBJ:
            if (strcmp(argv[4], "No changes") != 0)
            {
                check[4] = 1;
                int diff = strlen(argv[4] + 1) - current->size;
                current->size += diff;
                header->list->chunk_size += diff;
                header->riff->fileSize += diff;
                printf("diff on %s: %d\n", current->infoId, diff);
                current->data = argv[4];
            }
            break;
        default:
            break;
        }
    }

    switch (uintConversionBE((unsigned char *)current->infoId))
    {
    case IART:
        if (strcmp(argv[0], "No changes") != 0)
        {
            check[0] = 1;
            int diff = (strlen(argv[0]) + 1) - current->size;
            current->size += diff;
            header->list->chunk_size += diff;
            header->riff->fileSize += diff;
            printf("diff on %s: %d\n", current->infoId, diff);
            current->data = argv[0];
        }
        break;
    case ICOP:
        if (strcmp(argv[1], "No changes") != 0)
        {
            check[1] = 1;
            int diff = (strlen(argv[1]) + 1) - current->size;
            current->size += diff;
            header->list->chunk_size += diff;
            header->riff->fileSize += diff;
            printf("diff on %s: %d\n", current->infoId, diff);
            current->data = argv[1];
        }
        break;
    case IGNR:
        if (strcmp(argv[2], "No changes") != 0)
        {
            check[2] = 1;
            int diff = (strlen(argv[2]) + 1) - current->size;
            current->size += diff;
            header->list->chunk_size += diff;
            header->riff->fileSize += diff;
            printf("diff on %s: %d\n", current->infoId, diff);
            current->data = argv[2];
        }
        break;
    case INAM:
        if (strcmp(argv[3], "No changes") != 0)
        {
            check[3] = 1;
            int diff = (strlen(argv[3]) + 1) - current->size;
            current->size += diff;
            header->list->chunk_size += diff;
            header->riff->fileSize += diff;
            printf("diff on %s: %d\n", current->infoId, diff);
            current->data = argv[3];
        }
        break;
    case ISBJ:
        if (strcmp(argv[4], "No changes") != 0)
        {
            check[4] = 1;
            int diff = (strlen(argv[4]) + 1) - current->size;
            current->size += diff;
            header->list->chunk_size += diff;
            header->riff->fileSize += diff;
            printf("diff on %s: %d\n", current->infoId, diff);
            current->data = argv[4];
        }
        break;
    default:
        break;
    }

    info *artist = malloc(sizeof(info));
    info *copy = malloc(sizeof(info));
    info *genre = malloc(sizeof(info));
    info *name = malloc(sizeof(info));
    info *album = malloc(sizeof(info));

    /*
    These are allocated for adding new information
    To the linked list that didn't exist before.
    To avoid having clones, I use a check static list to see if it's there.
    Separating the check static list and the freed list helps handle edges cases
    If the user tries to change anything but enter no input for example.
    */

    for (size_t j = 0; j < 5; j++)
    {
        if (!check[j])
        {
            switch (j)
            {
            case 0:
                if (strcmp(argv[0], "No changes") != 0)
                {
                    freed[0] = 1;
                    strcpyn((unsigned char *)"IART", (char *)artist->infoId, 4);
                    artist->size = strlen(argv[0]) + 1;
                    artist->data = argv[0];
                    artist->next = NULL;
                    header->riff->fileSize += artist->size;
                    header->list->chunk_size += artist->size;
                    current->next = artist;
                    current = current->next;
                    printf("created new node %s: %s of size %d\n", current->infoId, current->data, current->size);
                }
                break;
            case 1:
                if (strcmp(argv[1], "No changes") != 0)
                {
                    freed[1] = 1;
                    strcpyn((unsigned char *)"ICOP", (char *)copy->infoId, 4);
                    copy->size = strlen(argv[1]) + 1;
                    copy->data = argv[1];
                    copy->next = NULL;
                    header->list->chunk_size += copy->size;
                    header->riff->fileSize += copy->size;
                    current->next = copy;
                    current = current->next;
                    printf("created new node %s: %s of size %d\n", current->infoId, current->data, current->size);
                }

                break;
            case 2:
                if (strcmp(argv[2], "No changes") != 0)
                {
                    freed[2] = 1;
                    strcpyn((unsigned char *)"IGNR", (char *)genre->infoId, 4);
                    genre->size = strlen(argv[2]) + 1;
                    genre->data = argv[2];
                    genre->next = NULL;
                    header->riff->fileSize += genre->size;
                    header->list->chunk_size += genre->size;
                    current->next = genre;
                    current = current->next;
                    printf("created new node %s: %s of size %d\n", current->infoId, current->data, current->size);
                }
                break;
            case 3:
                if (strcmp(argv[3], "No changes") != 0)
                {
                    freed[3] = 1;
                    strcpyn((unsigned char *)"INAM", (char *)name->infoId, 4);
                    name->size = strlen(argv[3]) + 1;
                    name->data = argv[3];
                    name->next = NULL;
                    header->riff->fileSize += name->size;
                    header->list->chunk_size += name->size;
                    current->next = name;
                    current = current->next;
                    printf("created new node %s: %s of size %d\n", current->infoId, current->data, current->size);
                }
                break;
            case 4:
                if (strcmp(argv[4], "No changes") != 0)
                {
                    freed[4] = 1;
                    strcpyn((unsigned char *)"ISBJ", (char *)album->infoId, 4);
                    album->size = strlen(argv[4]) + 1;
                    album->data = argv[4];
                    album->next = NULL;
                    header->riff->fileSize += album->size;
                    header->list->chunk_size += album->size;
                    current->next = album;
                    current = current->next;
                    printf("created new node %s: %s of size %d\n", current->infoId, current->data, current->size);
                }
                break;
            default:
                break;
            }
        }
    }

    write_wav(raw_file, &new_wav, header);

    freeWav(header);
    freeFile(first_file);

    /*
    Freeing the elements that weren't assigned to the linked list
    that I created.
    Depending on whether I change the info in the first list
    or create new nodes, the way of freeing changes.
    freeWav and the stack gets rid of the ones I use and
    The freed vector tells me if:
    1. I used it (freed[i] = 1) or 
    2. didn't (freed[i] = 0). 
    The second case is handled with freeWav as it IS part of the linked list
    (so freed with the wav object)
    The first case isn't because I malloc and never use the information.
    */
    for (size_t i = 0; i < 5; i++)
    {
        if (!freed[i])
        {
            switch (i)
            {
            case 0:
                free(artist);
                break;
            case 1:
                free(copy);
                break;
            case 2:
                free(genre);
                break;
            case 3:
                free(name);
                break;
            case 4:
                free(album);
            default:
                break;
            }
        }
    }
}