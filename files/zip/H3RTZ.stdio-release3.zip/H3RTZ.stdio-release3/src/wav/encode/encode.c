#include "raw.h"
#include "encode.h"


void encode(char *src)
{
    file *first_file = getData(src); //real file
    wav *header = headerParser(first_file);

    char *raw_file = malloc(BUFFER_SIZE);
    write_raw(src, &raw_file, header);

    char *new_wav = malloc(BUFFER_SIZE);
    write_wav(raw_file, &new_wav, header);

    /*
    Priting results
    file *wav_file = getData(new_wav);
    wav *res = headerParser(wav_file);
    
    freeWav(res);
    freeFile(wav_file);
    */

    free(new_wav);
    free(raw_file);
    freeWav(header);
    freeFile(first_file);
}

void add_list(char *raw_file, gtk_player *player)
{
    char *args[5];
    args[0] = player->args->artist;
    args[1] = player->args->copyright;
    args[2] = player->args->genre;
    args[3] = player->args->name;
    args[4] = player->args->album;

    add_wav(player->filename, raw_file, args, player->new_wav);

    /*
    //Final testing
    file *wav_file = getData(player->new_wav);
    wav *res = headerParser(wav_file);

    freeWav(res);
    freeFile(wav_file);
    */
}

void add_encode(gtk_player *player)
{
    file *first_file = getData(player->filename); //real file
    wav *header = headerParser(first_file);
    if (!header)
    {
        freeFile(first_file);
        return;
    }
    char *raw_file = malloc(BUFFER_SIZE);
    write_raw(player->filename, &raw_file, header);

    add_list(raw_file, player);

    free(raw_file);
    freeWav(header);
    freeFile(first_file);
}

/*
void wav_encode(char *src)
{
    //Main for wav_encoding
    //Encode for no changes
    //Add_encode for new infomation
    if (src == NULL)
    {
        errx(1, "Usage: [wav_file]");
    }

    printf("Want to write a new header ? (y / n) : ");

    char keep_header = 0;
    int scan = scanf("%c", &keep_header);

    if (scan == 0)
    {
        errx(1, "Failed to scan");
    }

    switch (keep_header)
    {
    case 'y':
        add_encode();
        break;
    case 'n':
        encode(src);
        break;
    default:
        warnx("Encode: error, misinput from user");
        break;
    }
}
*/