#ifndef ENCODE_H
#define ENCODE_H

#include "../../GUI/init.h"

// add elements to the linked list
void add_list(char *raw_file, gtk_player *player);

//takes a file and reencodes the file somewhere else into src_2.wav
void encode(char *src);

//add new info to header->list
// Disclaimer: I will only add new informations from the linked list
void add_encode(gtk_player *player);

#endif