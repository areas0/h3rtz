#include "legacy.h"


struct wav_header *read_header_wav(char *path)
{
    int fd_in = open(path, O_RDONLY);
    if (fd_in == -1)
        errx(4, "fd_in is incorrect");
    struct stat st;
    int error = stat(path, &st);
    if (error == -1)
        errx(4, "Failed");
    struct wav_header *h = mmap(NULL, st.st_size, PROT_READ, MAP_SHARED,
                                fd_in, 0);
    if (h == MAP_FAILED)
        err(errno, "Could not map the file");
    // integrity checker
    if (uintConversionBE((unsigned char*)h->riff) != RIFF ||
        uintConversionBE((unsigned char*)h->fmt) != FMT ||
        uintConversionBE((unsigned char*)h->fileFormatId) != WAV ||
        uintConversionBE((unsigned char*)h->data) != DATA)
        errx(errno, "Invalid header, returning...");
    print_header(h);
    //playfile(h);
    return h;
}
// playground
void playfile(struct wav_header *h)
{
    int error = 0;
    pa_sample_spec ss = headerToSpecsLegacy(h);
    // init audio server using synchronous api aka simple api
    pa_simple *s = pa_simple_new(NULL,"wav player",PA_STREAM_PLAYBACK,NULL,
                                        "music stream",&ss,NULL,NULL,&error);
    // error handling
    if (error < 0 || s == NULL)
        errx(4, "couldn't start server");
    
    int i = 0;
    // h+44 is the address where begins the data (size of header is 44)
    unsigned char *data = (unsigned char *) ((size_t) h+sizeof(struct wav_header));
    // offset is the number of bytes to be read by frame
    // it is the number of bits per bloc * the number of channels
    unsigned int offset = h->samplerate * h->channel;
    for (i = 0; i < h->data_bytes;)
    {
        error = pa_simple_write(s, &(data[i]), offset, &error);
        if (error < 0)
        {
            // don't forget to clean
            pa_simple_free(s);
            errx(4,"something bad happened %d", error);
        }
        i += offset; // adds an offset to the next sample
    }
    // makes sure that everything has been played
    pa_simple_drain(s, &error); // it will make the program stuck till finished
    pa_simple_free(s); // clean
}

void print_header(struct wav_header *h)
{
    if (h == NULL)
    {
        warnx("print_header : No header found");
        return;
    }
    printf("========File Info==========\n");
    //printf("FileSize: %d\n", h->fileSize);
    printf("Sampling frequency: %dHz\n", h->sampling_freq);
    printf("Sampling size: %d bits\n", h->samplerate);
    printf("Audio type: %s\n", audio_format(
                                    (enum compression_codes) h->AudioFormat));
    printf("Channels: %s\n", channel_type((enum channels) h->channel));
    printf("Average bitrate: %d bits per sec\n", h->bitrate);
    printf("Estimated duration: %ds\n", h->data_bytes/h->bitrate);
    printf("=====Bloc info=====\n");
    printf("Bloc size: %d bits\n", h->blocSize);
    printf("Bloc rate: %dB\n", h->blocrate);
    printf("=======Various data=======\n");
    printf("FileSize: %d B (data: %d B)\n", h->fileSize, h->data_bytes);
    printf("File format id: %s\n", uintConversionBE(
                (unsigned char*)   h->fileFormatId) == WAV ? "WAV" : "Unknown");
    printf("=======End========\n");
}

char *audio_format(enum compression_codes code)
{
    switch (code)
    {
    case PCM:
        return "PCM";
    case MPEG:
        return "MPEG";
    case PCM_float:
        return "PCM float (32-64 bits)";
    case WaveFormatExtensible:
        return "Wave Extensible | Format in subchunk:";
    case h3rtz:
        return "H3RTZ proprietary format";
    default:
        return "Unsupported";
    }
}

char *channel_type(enum channels c)
{
    switch (c)
    {
    case mono:
        return "mono";
    case stereo:
        return "stereo";
    default:
        return "unsupported";
    }
}
// Provides a header for pulseaudio according to the header's data
pa_sample_spec headerToSpecsLegacy(struct wav_header *h)
{
    pa_sample_spec s;
    switch ((enum data_type) h->samplerate)
    {
        case unsigned_data8:
            s.format = PA_SAMPLE_U8;
            break;
        case signed_data12: //handle 12 bit as 16 bit
            if (h->blocSize != 16)
                warnx("headerToSpecs: BlocSize on 12 bit audio is invalid");
            s.format = PA_SAMPLE_S16LE;
            break;
        case signed_data16:
            s.format = PA_SAMPLE_S16LE;
            break;
        case signed_data24:
            s.format = PA_SAMPLE_S24LE;
            break;
        case signed_data32:
            s.format = PA_SAMPLE_S32LE;
            break;
        case signed_data64:
            s.format = PA_SAMPLE_MAX;
            warnx("headerToSpecs: pulseaudio formats specs reached: %d", 64);
            break;
        default:
            s.format = PA_SAMPLE_INVALID;
            warnx("headerToSpecs: couldn't assign a valid format, \
                                                    program will likely fail");
            break;
    }
    s.rate = h->sampling_freq;
    s.channels = h->channel;
    return s;
}