#ifndef PARSER_H
#define PARSER_H

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <err.h>
#include <sys/types.h>
#include <pulse/pulseaudio.h>
#include <pulse/simple.h>
#include <string.h>
#include "../tools/conversion.h"
#include "legacy.h"
#include "wav.h"
#include "headerwav.h"
#include "info.h"

extern const uint32_t RIFF;
extern const uint32_t WAV;
extern const uint32_t FMT;
extern const uint32_t DATA;
extern const uint32_t FACT;
extern const uint32_t LIST;
extern const uint32_t INFO;
extern const __uint128_t PCM_CODE;
extern const __uint128_t PCM_FLOAT_CODE;

typedef struct file
{
    int fd;
    unsigned char *map;
    struct stat *stats;
} file;

file *getData(char *path);
void freeFile(file *file);
wav *headerParser(file *file);
riff *riffParser(unsigned char *data, size_t *i);
data *dataParser(unsigned char *d, size_t *i);
fact *factParser(unsigned char *data, size_t *i);
void fmtParser(unsigned char *data, size_t *i, wav *header);
void strcpyn(unsigned char *src, char *dest, size_t n);
void freeWav(wav *wav);
#endif