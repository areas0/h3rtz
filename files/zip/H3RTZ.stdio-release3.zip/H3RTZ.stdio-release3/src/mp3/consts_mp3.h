#ifndef CONSTS_MP3_H
#define CONSTS_MP3_H


#define NB_SAMPLES 1024
#define HALF NB_SAMPLES/2

// number of critical bands according to sampling frequency
#define CRIT_BAND_44100 27
#define CRIT_BAND_48000 27
#define CRIT_BAND_32000 24

#define NB_SUBBANDS 32
#define SUB_SIZE HALF/NB_SUBBANDS
// Math zone with constants not defined without GNU_SOURCE
# define M_PI		3.14159265358979323846	/* pi */

#endif