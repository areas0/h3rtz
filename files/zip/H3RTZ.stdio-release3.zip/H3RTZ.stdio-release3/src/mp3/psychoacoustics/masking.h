#ifndef MASKING_H
#define MASKING_H

#include "psychoacoustic.h"
static_list_f **getMaskTonal(tonalComponents *t, long double *SPL, band_table table);
static_list_f **getMaskNoise(tonalComponents *t, long double *SPL, band_table table);
static_list_f *getGlobalMasks(static_list_f **tonal, static_list_f **noises,
                              crit_table *table, size_t size);
long double *getMinimumMaskThr(static_list_f *global, size_t *map);
#endif