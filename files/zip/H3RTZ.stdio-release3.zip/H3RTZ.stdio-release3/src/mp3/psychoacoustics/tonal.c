#include "tonal.h"

static_list *findPeaks(long double *SPL)
{
    static_list *l = initStaticList();
    for (size_t i = 3; i < HALF-12; i++)
    {
        if (SPL[i] > SPL[i-1] && SPL[i] > SPL[i+1])
        {
            appendStaticList(l, i);
        }
    }
    return l;
}

tonalComponents *findTonalComponents(long double *SPL)
{
    tonalComponents *t = calloc(1, sizeof(tonalComponents));
    t->SPL = malloc(sizeof(long double)*HALF);
    memcpy(t->SPL, SPL, HALF*sizeof(long double));

    static_list *peaks = findPeaks(SPL);
    static_list *tonals = initStaticList();
    t->tonals = tonals;

    tonal_t *isTonal = calloc(HALF, sizeof(tonal_t));
    t->flags = isTonal;

    isTonal[0] = isTonal[1] = isTonal[2] = IGNORE;
    for (size_t i = 0; i < peaks->nb_el; i++)
    {
        size_t k = peaks->data[i];
        // critical band ranges, see table 3.10
        size_t j = 0;
        if (k > 2 && k < 63)
            j = 2;
        else if (k >= 63 && k < 127)
            j = 3;
        else if (k >= 127 && k < 255)
            j = 6;
        else
            j = 12;
        // tonal component detection according to spec in page 29
        u_int8_t tonal = 1;
        for (size_t l = 2; l <= j; l++)
        {
            if (t->SPL[k] - t->SPL[k-l] < 7 || t->SPL[k] - t->SPL[k+l] < 7)
            {
                tonal = 0;
            }
        }
        if (tonal)
        {
            // add SPL db from k-1,k,k+1
            t->SPL[k] = add_db(t->SPL+k-1, 3);
            // mark k as a tonal component for complexity
            isTonal[k] = TONAL;
            // add k to the list of tonal components for later
            appendStaticList(tonals, k);
            // ignore neighbors
            // symetrical loop in range [k-j;k+j]
            for (size_t l = 1; l < j; l++)
            {
                t->flags[k-l] = t->flags[k+l] = IGNORE;
            }
        }
    }
    freeStaticList(peaks);
    return t;
}

void findNonTonalComponents(tonalComponents *t, crit_table *table, crit_table *bands,
                            size_t *associated)
{
    t->noises = initStaticList();
    for (size_t i = 0; i < table->size-1; i++)
    {
        long double weight = 0;
        long double power = -8.0;
        for (size_t j = table->indices[i]; j < table->indices[i+1]; j++)
        {
            // maybe should be j instead i
            if (t->flags[i] == UNSET)
            {
                long double values[2] = {t->SPL[j], power};
                power = add_db((long double *)values, 2);
                weight += powl(10, t->SPL[j]/10.0) *
                (bands->barks[associated[j]] - (long double) i);
            }
        }

        if (power > -8.0)
        {
            // compute center
            long double index = weight/powl(10, power / 10.0);
            long double offset = index * (table->indices[i+1] - table->indices[i]);
            size_t center = (size_t) (table->indices[i] + (size_t) roundl(offset));

            // if the center is a tonal, place it at center+1
            if (t->flags[center] == TONAL)
                center++;
            // set it as a noise
            t->flags[center] = NOISE;
            t->SPL[center] = power;
            // append to noises
            appendStaticList(t->noises, center);
        }
    }
    
}

void freeTonalComponents(tonalComponents *t)
{
    if (!t)
        return;
    free(t->flags);
    free(t->SPL);
    freeStaticList(t->noises);
    freeStaticList(t->tonals);
    free(t);
}