#include "transform.h"

long double *getSPL(long double *samples)
{
    long double *vector = calloc(HALF, sizeof(long double));
    long double *window = getHannWindow(NB_SAMPLES);
    long double max = -INFINITY;
    for (size_t i = 0; i < HALF; i++)
    {
        // FFT transform on NB_SAMPLES points => 1024 for MP3
        // sum allows to retrieve total value faster
        long double complex sum = 0;
        for (size_t j = 0; j < NB_SAMPLES; j++)
        {
            long double complex val = cexpl(-I* ((2*M_PI*i*j)/NB_SAMPLES));
            long double complex q = window[j]*samples[j]*val;
            sum += q;
        }
        // conversion to real norm
        long double norm = cabsl(sum);
        long double sq = powl(norm, 2);
        long double res;
        // null logarithm is undefined!
        if (sq != 0)
            res = 10*log10l(sq);
        else
            res = sq;
        vector[i] = res;
        if (res > max)
            max = res;
    }
    // normalization to 96DB max
    long double adjust = 96.0-max;
    addToArrayl(vector, HALF, adjust);
    free(window);
    return vector;
}
