#ifndef SPL_BAND_H
#define SPL_BAND_H

#include "psychoacoustic.h"
#define _GNU_SOURCE
#include <stdio.h>
long double *getSPLBand(long double *SPL, long double *scale_factors);
long double *loadScaleFactors(char *path);
#endif