#ifndef TRANSFORM_H
#define TRANSFORM_H

#include "../consts_mp3.h"
#include "psychoacoustic.h"
#include "../../tools/array.h"
#include "../math/window.h"
long double *getSPL(long double *samples);

#endif