#include "masking.h"
// refer to part 3.2.6 in pdf
static_list_f **getMaskTonal(tonalComponents *t, long double *SPL, band_table table)
{
    size_t *map = table.associated;
    crit_table *crit = table.t;
    static_list_f **masks = calloc(crit->size, sizeof(static_list_f));
    // there is a mask per critical band
    // each of them is a list of values in dB
    for (size_t i = 0; i < crit->size; i++)
    {
        masks[i] = initStaticListF();
        long double zi = crit->barks[i];
        for (size_t j = 0; j < t->tonals->nb_el; j++)
        {
            size_t k = t->tonals->data[j];
            long double zj = crit->barks[map[k]];
            long double dz = zi-zj;
            if (dz >= -3 && dz <= 8)
            {
                long double avtm = -1.525 - 0.275 * zj - 4.5;
                long double vf = 0;
                if (dz >= -3 && dz < -1)
                    vf = 17 * (dz+1) - (0.4 * SPL[k] + 6);
                else if (dz >= -1 && dz < 0)
                    vf = dz * (0.4 * SPL[k] + 6);
                else if (dz >= 0 && dz < 1)
                    vf = -17*dz;
                else if (dz >= 1 && dz <= 8)
                    vf = -(dz - 1) * (17 - 0.15 * SPL[k]) - 17;
                else
                    t->flags[k] = IGNORE;
                
                appendStaticListF(masks[i], SPL[k]+vf+avtm);
            }
        }
    }
    return masks;
}

// getMaskTonal && getMaskNoise work in very similar ways, only one formula
// changes
static_list_f **getMaskNoise(tonalComponents *t, long double *SPL, band_table table)
{
    size_t *map = table.associated;
    crit_table *crit = table.t;
    static_list_f **masks = calloc(crit->size, sizeof(static_list_f));
    for (size_t i = 0; i < crit->size; i++)
    {
        masks[i] = initStaticListF();
        long double zi = crit->barks[i];
        for (size_t j = 0; j < t->noises->nb_el; j++)
        {
            size_t k = t->noises->data[j];
            long double zj = crit->barks[map[k]];
            long double dz = zi-zj;
            if (dz >= -3 && dz <= 8)
            {
                long double avnm = -1.525 - 0.175 * zj - 0.5;
                long double vf = 0;
                if (dz >= -3 && dz < -1)
                    vf = 17 * (dz+1) - (0.4 * SPL[k] + 6);
                else if (dz >= -1 && dz < 0)
                    vf = dz * (0.4 * SPL[k] + 6);
                else if (dz >= 0 && dz < 1)
                    vf = -17*dz;
                else
                    vf = -(dz - 1) * (17 - 0.15 * SPL[k]) - 17;
                
                appendStaticListF(masks[i], SPL[k]+vf+avnm);
            }
        }
    }
    return masks;
}

// Computes global mask for all 130 critical bands
// The mask is the sum of SPL in tonal,noise masks + the threshold of hearing
static_list_f *getGlobalMasks(static_list_f **tonal, static_list_f **noises,
crit_table *table, size_t size)
{
    static_list_f *g_masks = initStaticListF();
    for (size_t i = 0; i < size; i++)
    {
        // merge all values into one array
        // its size is 1 (thr) + nb el in noise and tonal
        long double *values = calloc(1+tonal[i]->nb_el+noises[i]->nb_el,
                                sizeof(long double));
        values[0] = table->thresholds[i];
        // copy at offset 1
        memcpy(values+1, tonal[i]->data, tonal[i]->nb_el*sizeof(long double));
        // copy at offset 1+nb values in tonal
        memcpy(values+1+tonal[i]->nb_el, noises[i]->data, noises[i]->nb_el*
                sizeof(long double));

        // computes the dB sum
        long double final = add_db(values, 1+tonal[i]->nb_el+noises[i]->nb_el);
        // appends it to the list of global masks
        appendStaticListF(g_masks, final);
        free(values);
    }
    return g_masks;
}

long double *getMinimumMaskThr(static_list_f *global, size_t *map)
{
    long double *mask = calloc(NB_SUBBANDS, sizeof(long double));
    for (size_t i = 0; i < NB_SUBBANDS; i++)
    {
        // gets the minimum between index first and last of global masks thr
        size_t first = map[i*SUB_SIZE];
        size_t last = map[(i+1)*SUB_SIZE -1];
        long double min = INFINITY;
        for (size_t i = first; i <= last && i < global->nb_el; i++)
        {
            if (global->data[i] < min)
                min = global->data[i];
        }
        // default value is 0
        mask[i] = min == INFINITY ? 0 : min;
    }
    return mask;
}