#ifndef TEST_H
#define TEST_H

#include "../psychoacoustic.h"
#define  _GNU_SOURCE
#include <stdio.h>
/*
** small test suite to test the psychoacoustic model
** It will compare data to the equivalent result from python code
** Each test can be considered as standalones
** The needed data will be loaded from expected results in folder
*/
void testFFT(void);
long double *loadFFT(void);
void checkTonal(void);
void testNoise(void);
void testDecimation(void);
tonalComponents *loadTonalComponents(char *path);
void testMaskingTonal(void);
static_list_f **loadDoubleList(char *path);
void testMaskingNoise(void);
void testGlobalMasking(void);
static_list_f *loadListFloat(char *path);
void testMinMasking(void);
#endif