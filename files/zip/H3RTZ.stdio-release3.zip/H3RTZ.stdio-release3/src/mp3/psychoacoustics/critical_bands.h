#ifndef CRITICAL_BANDS_H
#define CRITICAL_BANDS_H

#define  _GNU_SOURCE
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <err.h>
#include <string.h>
#include "../math/decibel.h"
#include "../consts_mp3.h"

typedef struct crit_table
{
    size_t *indices;
    long double *frequencies;
    long double *barks;
    long double *thresholds;
    size_t size;
    size_t sampling_rate;
} crit_table;

typedef struct band_table
{
    crit_table *t;
    size_t *associated;
} band_table;

long double z(long double f);
long double *generateTableZ(long double *f, size_t len);
crit_table *generateTable(size_t sampling_rate);
void freeTable(crit_table *t);
band_table associateBandToTable(crit_table *t);
#endif