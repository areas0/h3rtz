#ifndef PSYCHOACOUSTIC_H
#define PSYCHOACOUSTIC_H

#include <math.h>
#include <complex.h>
#define  _GNU_SOURCE
#include <stdio.h>
#include "../../wav/parser.h"
#include "../consts_mp3.h"
#include "transform.h"
#include "../math/weights.h"
#include "critical_bands.h"
#include "tonal.h"
#include "decimation.h"
#include "masking.h"
#include "spl_band.h"
void psychoAcoustic1(int *samples, short bits);

#endif