#ifndef WEIGHTS_H
#define WEIGHTS_H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

long double *normalizeInput(int *samples, size_t len, size_t factor);

#endif