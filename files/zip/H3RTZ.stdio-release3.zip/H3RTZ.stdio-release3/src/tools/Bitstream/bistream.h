#ifndef BITSTREAM_H
#define BITSTREAM_H
#include <stdio.h>
#include <stdlib.h>
#include <err.h>
#include <assert.h>
#include <sys/types.h>
#include <glib.h>
#define DEFAULT_ALLOC_SIZE 500
typedef struct bitStream
{
    char *data; // stream of data
    size_t offset_w; // offset for writing purposes per bit
    size_t cell_w; // offset in the cell % 8
    size_t len_r; // maximum reading index
    size_t offset_r; // maximum offset in cell % 8 for len_r
    size_t allocated_len;
} bitStream;

bitStream *initializeBitStream(void);
void appendBitStream(bitStream *s, char el);
bitStream *encodeData(char *s);
char fromBinToByte(char *s);
void freeBitStream(bitStream *b);
char *decodeBitStream(bitStream *stream);
char *toBitRepresentation(unsigned char c);
char decodeIndex(bitStream *stream, size_t *read_byte, size_t *read_bit);
#endif