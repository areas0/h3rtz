#include "./bistream.h"

bitStream *initializeBitStream(void)
{
    bitStream *s = calloc(1, sizeof(bitStream));
    s->data = calloc(DEFAULT_ALLOC_SIZE, sizeof(char));
    s->allocated_len = DEFAULT_ALLOC_SIZE;
    return s;
}
// appends a bit to a bitstream with realloc if needed
void appendBitStream(bitStream *s, char el)
{
    // reallocation if needed
    if (s->allocated_len == s->offset_w)
    {
        s->data = realloc(s->data, sizeof(char)*s->allocated_len*2);
        s->allocated_len *= 2;
    }
    // if it is 0 we shift one time to the left (LMSB)
    if (el == '0')
    {
        s->data[s->offset_w] = s->data[s->offset_w] << 1;
        // cell offset update modulo 8 bits
        s->cell_w = (s->cell_w+1) % 8;
        if (!s->cell_w)
            s->offset_w++;
    }
    // if it is 1 we shift one time to the left (LMSB) & add one
    else if (el == '1')
    {
        s->data[s->offset_w] = s->data[s->offset_w] << 1;
        s->data[s->offset_w] |= 1;
        s->cell_w = (s->cell_w+1) % 8;
        if (!s->cell_w)
            s->offset_w++;
    }
    else
    {
        errx(EXIT_FAILURE, "unknown char");
    }
}

bitStream *encodeData(char *s)
{
    bitStream *b = initializeBitStream();
    for (size_t i = 0; s[i]; i++)
    {
        appendBitStream(b, s[i]);
    }
    // updates padding according to the result
    b->offset_r = !b->cell_w ? 0 : 8 - b->cell_w;
    //warnx("BitStream size: %zu", b->offset_w+1);
    return b;
}


// @return 8-bits value of the binary representation string
char fromBinToByte(char *s)
{
    char val = 0;
    char power = 1;
    for (size_t i = 0; i < 8 && s[i]; i++)
    {
        val += s[7-i] == '0' ? 0 : power;
        power *= 2;
    }
    return val;
}

void freeBitStream(bitStream *b)
{
    if (!b)
        return;
    free(b->data);
    free(b);
}

char *decodeBitStream(bitStream *stream)
{
    GString *s = g_string_new("");
    for (size_t i = 0; i < stream->offset_w; i++)
    {
        // convert char to bit representation
        // can reduce allocation by using an unique buffer
        char *base2 = toBitRepresentation(stream->data[i]);
        g_string_append(s, base2);
        free(base2);
    }
    char *last = toBitRepresentation(stream->data[stream->offset_w]);
    g_string_append(s, last+stream->offset_r);
    free(last);
    char *result = s->str;
    g_string_free(s, FALSE);
    return result;
}

char *toBitRepresentation(unsigned char c)
{
    char *value = calloc(9, sizeof(char));
    for (size_t i = 0; i < 8; i++)
    {
        value[7-i] = c % 2 ? '1' : '0';
        c /= 2;
    }
    return value;
}

char decodeIndex(bitStream *stream, size_t *read_byte, size_t *read_bit)
{
    if (*read_byte > stream->offset_w)
        return 0;
    if (stream->offset_w == *read_byte && *read_bit <= 8-stream->offset_r)
    {
        return ((stream->data[*read_byte] >>
                 (7 - stream->offset_r - *read_bit)) &
                0x01) ? '1' : '0';
    }
    return ((stream->data[*read_byte] >> (7 - *read_bit) ) & 0x01 ) ? '1' : '0';
}