#include "./bintree.h"

// Creates a simple binTree with a key using a generic type.
// @param left&right are binTrees, it can be NULL
binTree *createTree(freq_info key, binTree *left, binTree *right)
{
    binTree *tree = calloc(1, sizeof(binTree));
    tree->key = key;
    tree->left = left;
    tree->right = right;
    return tree;
}

void freeBinTree(binTree *tree)
{
    if (!tree)
        return;
    if (tree->left)
        freeBinTree(tree->left);
    if (tree->right)
        freeBinTree(tree->right);
    free(tree);
}