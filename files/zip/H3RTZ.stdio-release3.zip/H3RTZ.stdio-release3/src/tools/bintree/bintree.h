#ifndef BINTREE_H
#define BINTREE_H
#include <stdlib.h>
#include "../../huffman/compress.h"
#include "../../huffman/generic_list.h"

binTree *createTree(freq_info key, binTree *left, binTree *right);
void freeBinTree(binTree *tree);
#endif