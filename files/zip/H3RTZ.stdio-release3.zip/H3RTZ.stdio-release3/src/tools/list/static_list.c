#include "static_list.h"

static_list *initStaticList(void)
{
    static_list *l = calloc(1,sizeof(static_list));
    l->data = calloc(DEFAULT_SIZE, sizeof(size_t));
    l->size = DEFAULT_SIZE;
    return l;
}

void doubleCapacity(static_list *l)
{
    l->data = realloc(l->data, l->size*2*sizeof(size_t));
    l->size *= 2;
}

void appendStaticList(static_list *l, size_t elm)
{
    //if (ListContains(l, elm))
    //    return;
    if (l->size == l->nb_el)
    {
        doubleCapacity(l);
    }
    l->data[l->nb_el] = elm;
    l->nb_el++;
}

void removeLast(static_list *l)
{
    l->data[l->nb_el] = 0;
    l->nb_el--;
}

void popStaticList(static_list *l, size_t i)
{
    if (i >= l->nb_el)
        return;
    if (i == l->nb_el -1)
    {
        removeLast(l);
        return;
    }
    // moves all elements by one index
    for (size_t j = i; j < l->nb_el-1; j++)
    {
        l->data[j] = l->data[j+1];
    }
    l->nb_el--;
}

void freeStaticList(static_list *l)
{
    if (!l)
        return;
    if (l->data)
        free(l->data);
    free(l);
}

void printStaticList(static_list *l)
{
    for (size_t i = 0; i < l->nb_el; i++)
    {
        printf("%zu: %zu\n", i, l->data[i]);
    }
}

static_list_f *initStaticListF(void)
{
    static_list_f *l = calloc(1,sizeof(static_list));
    l->data = calloc(DEFAULT_SIZE, sizeof(long double));
    l->size = DEFAULT_SIZE;
    return l;
}

void doubleCapacityF(static_list_f *l)
{
    l->data = realloc(l->data, l->size*2*sizeof(long double));
    l->size *= 2;
}

void appendStaticListF(static_list_f *l, long double elm)
{
    //if (ListContainsF(l, elm))
    //    return;
    if (l->size == l->nb_el)
    {
        doubleCapacityF(l);
    }
    l->data[l->nb_el] = elm;
    l->nb_el++;
}

void removeLastF(static_list_f *l)
{
    l->data[l->nb_el] = 0;
    l->nb_el--;
}

void popStaticListF(static_list_f *l, size_t i)
{
    if (i >= l->nb_el)
        return;
    if (i == l->nb_el -1)
    {
        removeLastF(l);
        return;
    }
    // moves all elements by one index
    for (size_t j = i; j < l->nb_el-1; j++)
    {
        l->data[j] = l->data[j+1];
    }
    l->nb_el--;
}

void freeStaticListF(static_list_f *l)
{
    if (!l)
        return;
    if (l->data)
        free(l->data);
    free(l);
}

void printStaticListF(static_list_f *l)
{
    for (size_t i = 0; i < l->nb_el; i++)
    {
        printf("%zu: %Lf\n", i, l->data[i]);
    }
}

int ListContains(static_list *l, size_t elm)
{
    for (size_t i = 0; i < l->nb_el; i++)
    {
        if (l->data[i] - elm < 1e-1)
            return 1;
    }
    return 0;
}

int ListContainsF(static_list_f *l, long double elm)
{
    for (size_t i = 0; i < l->nb_el; i++)
    {
        if (l->data[i] == elm)
            return 1;
    }
    return 0;
}