#include "array.h"

void addToArrayl(long double *array, size_t size, long double term)
{
    for (size_t i = 0; i < size; i++)
    {
        array[i] += term;
    }
}