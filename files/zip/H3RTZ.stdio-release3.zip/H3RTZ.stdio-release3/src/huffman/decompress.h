#ifndef DECOMPRESS_H
#define DECOMPRESS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <glib.h>
#include "../tools/bintree/bintree.h"
#include "../tools/Bitstream/bistream.h"
#include "./output/structure.h"
#include <err.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include "../wav/encode/raw.h"
#include "../tools/bintree/bintree.h"
#include "../tools/Bitstream/bistream.h"
#define HUFF_MAX 256

#include "./generic_list.h"
#include "./compress.h"

char *decodeDataHuff(binTree *tree, char *str, size_t len, size_t *total);
binTree *decodeTree(char *data);
struct tuple_bi __decodeTree(char *data, size_t i);
char equalTree(binTree *a, binTree *b);
void test_decodedata(void);
char *decodeDataHuffSlice(binTree *tree, bitStream *b,
                          size_t *total, size_t *r, size_t *o);
char decodeDataHuffSingle(binTree *tree, bitStream *b,
                          size_t *r, size_t *o, uint8_t *possible);

struct tuple_bi
{
    binTree *t;
    size_t i;
};

#define LEGACY_DECOMPRESSION 0 // disables old code

#endif