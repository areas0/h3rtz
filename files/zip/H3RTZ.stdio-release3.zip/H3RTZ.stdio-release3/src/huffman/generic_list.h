#ifndef GENERIC_LIST_H
#define GENERIC_LIST_H

#include <stdlib.h>
#include <sys/types.h>
typedef struct freq_info{
  char item;
  size_t frequency;
} freq_info;

// Rudimentary binTree type definition
typedef struct binTree
{
    struct binTree *left; // 0
    struct binTree *right; // 1
    freq_info key;
    u_int8_t flag;
} binTree;

typedef struct freq_info gtype;

typedef struct glist{
    gtype *data;
    size_t nb_el;
    size_t len;
} glist;

typedef struct tlist{
    binTree **data;
    size_t nb_el;
    size_t len;
}tlist;

// List structure
glist *init_glist(void);
void free_glist(struct glist *list);
void append_glist(struct glist *list, gtype data);

// Tree structure
tlist *init_tlist(void);
void free_tlist(tlist *list);
void append_tlist(tlist *list, binTree *data);
binTree *tree_pop(tlist *list);

#endif