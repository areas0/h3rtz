#include "compress.h"

void swap(binTree *a, binTree *b)
{
    binTree tmp = *a;
    *a = *b;
    *b = tmp;
}

struct glist *build_frequency_list(char *str, size_t len)
{
    glist *result = init_glist();
    // Initialize a list of zeros
    size_t dataList[HUFF_MAX] = {0};
    for (size_t i = 0; i < len; i++)
    {
        // Increment the frequencies of each chars
        dataList[(unsigned char)str[i]] += 1;
    }
    for (size_t j = 0; j < HUFF_MAX; j++)
    {
        if (dataList[j] != 0)
        {
            // Tuple structure
            freq_info f = {
                .item = j,
                .frequency = dataList[j],
            };
            //append all the tuples of values and frequencies of each character
            append_glist(result, f);
        }
    }
    return result;
}
// helper function
gchar *getFile(gchar *path, gsize *len)
{
    gchar *content = NULL;
    GError *error = NULL;
    if (g_file_get_contents(path, &content, len, &error) == FALSE)
    {
        if (error)
            g_error_free(error);
        return NULL;
    }
    //g_free();
    return content;
}
// prints a list
void print(glist *list)
{
    for (size_t i = 0; i < list->nb_el; i++)
    {
        printf("%c,%zu\n",list->data[i].item, list->data[i].frequency);
    }
}

binTree *rec(binTree *tree)
{
    binTree *result = NULL;
    if (tree != NULL)
    {
        result->key.item = tree->key.item;
        rec(result->left);
        rec(result->right);
    }
    return result;
}
// This functions builds an Huffman compression tree using a frequency list
// @param freq_list: the frequency list of type g_list
binTree *buildHuffmanTree(glist *freq_list)
{
    tlist *t = init_tlist();
    for (size_t i = 0; i < freq_list->nb_el; i++)
    {
        binTree *tree = createTree(freq_list->data[i], NULL, NULL);
        append_tlist(t, tree);
    }
    decreasing_sort(t);
    
    while (t->nb_el > 1)
    {
        binTree *freq1 = tree_pop(t);
        binTree *freq2 = tree_pop(t);
        freq_info f = {
                .item = 0,
                .frequency = freq1->key.frequency + freq2->key.frequency,
        };
        binTree *new = createTree(f, freq2, freq1);
        // just in case to check for real root cause we have null character issue
        new->flag = 1; // 1 indicates a non terminal node
        append_tlist(t, new);
        decreasing_sort(t);
    }
    binTree *result = t->data[0];
    if (!result->left && !result->right)
        result->flag = 0;
    free(t->data);
    free(t);
    return result;
}

void decreasing_sort(tlist *list)
{
    for (size_t i = list->nb_el-1; i > 0; i--)
    {
        for (size_t j = 0; j < i; j++)
        {
            if (list->data[j]->key.frequency < list->data[j+1]->key.frequency)
                swap(list->data[j], list->data[j+1]);
        }
    }
}
// compresses the data into a string of 0 and 1 using an Huffman Tree
// @param len: length of the string or slice for partial compression
char *encodeDataHuff(binTree *tree, char *str, size_t len)
{
    // array of strings, one cell per ascii code
    char *charcode[HUFF_MAX] = {0};
    GString *result = g_string_new("");
    char *res;
    for (size_t i = 0; i < len; i++)
    {
        // if we haven't found yet the associated code
        if (!charcode[(unsigned char )str[i]])
        {
            //size_t len = 0;
            string *s = malloc(sizeof(string));
            s->data = malloc(129*sizeof(char));
            s->allocated = 129;
            s->len = 0;
            __occurence(tree, str[i], s, 0);
            // keeps it in the array now
            charcode[(unsigned char )str[i]] = s->data;
            //free(s->data);
            // we free the string structure but not the data because we need it
            free(s);
        }
        g_string_append(result, charcode[(unsigned char) str[i]]);
    }
    for (size_t i = 0; i < HUFF_MAX; i++)
    {
        if (charcode[i])
        {
            free(charcode[i]);
        }
    }
    res = result->str;
    g_string_free(result, FALSE);
    return res;
}
// recurssion function to find the Huffman code for a specific character
string *__occurence(binTree *tree, char elt, string *s, size_t pos)
{
    if (!tree)
        errx(EXIT_FAILURE, "Wut no tree");
    else
    {
        if (!tree->left)
        {
            if (tree->key.item == elt && !tree->flag)
            {
                // reallocation if the string is full
                if (pos == s->allocated)
                {
                    s->data = realloc(s->data, sizeof(char) * s->allocated * 2);
                    memset(s->data + s->allocated, 0, s->allocated);
                    s->allocated *= 2;
                }
                // adds the null terminating byte to avoid going over useless data
                s->data[pos] = 0;
                return s;
            }
            else
                return NULL;
        }
        else
        {
            // reallocation if the string is full
            if (pos == s->allocated)
            {
                s->data = realloc(s->data, sizeof(char)*s->allocated*2);
                memset(s->data+s->allocated, 0, s->allocated);
                s->allocated *= 2;
            }
            s->data[pos] = '0';
            string *result = __occurence(tree->left, elt, s, pos+1);
            if (result)
                return result;
            else
            {
                s->data[pos] = '1';
                return __occurence(tree->right, elt, s, pos+1);
            }
        }
        errx(EXIT_FAILURE, "unknown technically");
        return NULL;
    }
    errx(EXIT_FAILURE, "unknown technically");
    return NULL;
}

char *ascii_to_binary(unsigned char c)
{
    char* s = calloc(sizeof(char), 9);
	for (int i = 7; i >= 0; i--)
	{
		if (c % 2 == 0)
			s[i] = '0';
		else
			s[i] = '1';
		c/=2;
	}
    return s;
}

void __rec(binTree *tree, GString *result)
{
    if (!tree)
        return;
    if (!tree->flag)
    {
        g_string_append(result, "1");
        char *s = ascii_to_binary(tree->key.item);
        g_string_append(result, s);
        free(s);
    }
    else
    {
        g_string_append(result, "0");
        __rec(tree->left,result);
        __rec(tree->right,result);
    }
}

char *encodeTree(binTree *tree)
{
    GString *result = g_string_new("");
    __rec(tree, result);
    char *res = result->str;
    g_string_free(result, FALSE);
    return res;
}

output_h *createOutput(bitStream *b, char  *id)
{
    output_h *tree = malloc(sizeof(output_h));
    strcpyn((unsigned char *)id, tree->id, 4);
    // total stream length
    tree->len = !b->offset_r ? b->offset_w : b->offset_w+1;
    // padding byte if string is not % 8
    tree->padding = b->offset_r;
    tree->data = b->data;
    return tree;
}
// Faster compression of data via almost direct bitStream
bitStream *encodeDataHuffFast(binTree *tree, char *str, size_t len)
{
    // array of strings, one cell per ascii code
    char *charcode[HUFF_MAX] = {0};
    bitStream *result = initializeBitStream();
    for (size_t i = 0; i < len; i++)
    {
        // if we haven't found yet the associated code
        if (!charcode[(unsigned char )str[i]])
        {
            //size_t len = 0;
            string *s = malloc(sizeof(string));
            s->data = malloc(129*sizeof(char));
            s->allocated = 129;
            s->len = 0;
            __occurence(tree, str[i], s, 0);
            // keeps it in the array now
            charcode[(unsigned char )str[i]] = s->data;
            //free(s->data);
            // we free the string structure but not the data because we need it
            free(s);
        }
        for (size_t j = 0; charcode[(unsigned char) str[i]][j]; j++)
        {
            appendBitStream(result, charcode[(unsigned char) str[i]][j]);
        }
    }
    result->offset_r = !result->cell_w ? 0 : 8 - result->cell_w;
    for (size_t i = 0; i < HUFF_MAX; i++)
    {
        if (charcode[i])
        {
            free(charcode[i]);
        }
    }
    return result;
}

void print_tlist(tlist *t)
{
    for (size_t i = 0; i < t->nb_el; i++)
    {
        printf("%u %zu\n", t->data[i]->key.item, t->data[i]->key.frequency);
    }
}

void traversal(binTree *tree)
{
    if (!tree)
        return;
    if (!tree->flag)
        printf("%u %zu\n", tree->key.item, tree->key.frequency);
    if (tree->left)
        traversal(tree->left);
    if (tree->right)
        traversal(tree->right);
}