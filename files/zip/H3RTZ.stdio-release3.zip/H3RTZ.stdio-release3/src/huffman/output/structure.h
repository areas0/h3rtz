#ifndef STRUCTURE_H
#define STRUCTURE_H

#include <stdio.h>
#include "../../wav/encode/raw.h"
#include "../../tools/conversion.h"

typedef struct output_h
{
    char id[4];
    size_t len;
    char padding;
    char *data;
} output_h;

void writeStructure(int fd, output_h *o);
output_h *loadStructure(char *input, size_t *i);
#endif