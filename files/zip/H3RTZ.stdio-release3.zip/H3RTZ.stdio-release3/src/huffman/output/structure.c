#include "structure.h"


void writeStructure(int fd, output_h *o)
{
    rewrite(fd, o->id, sizeof(char)*4, "id write");
    rewrite(fd, &o->len, sizeof(size_t), "size");
    rewrite(fd, &o->padding, sizeof(char), "padding");
    if (o->len)
        rewrite(fd, o->data, o->len, "Huffman: data");
}

// loads from a string the output_h structure
// @param i: pointer to the current index
output_h *loadStructure(char *input, size_t *i)
{
    output_h *output = malloc(sizeof(output_h));
    // copies the identifier to the structure
    strcpyn((unsigned char *) input+*i, output->id, 4);
    // converts 8 bytes into an unsigned long
    output->len = uint64ConversionLE((unsigned char *) input+*i+4);
    // padding on a single byte
    output->padding = *(input+*i+12);
    // data pointer
    output->data = input+*i+13;
    // update the index
    *i = *i + 13 + output->len;
    return output;
}