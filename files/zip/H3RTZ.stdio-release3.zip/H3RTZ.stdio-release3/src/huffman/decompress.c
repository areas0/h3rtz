#include "decompress.h"

// @param len: length of the encoded data
// @param total: size_t pointer to the total size of the data
char *decodeDataHuff(binTree *tree, char *str, size_t len, size_t *total)
{
    string s =
    {
        .allocated = 512,
        .data = calloc(512, sizeof(char)),
        .len = 0,
    };
    binTree *t = tree;
    for (size_t i = 0; i < len; i++)
    {
        // if it is a leaf...
        if (!t->flag)
        {
            //  check if the string is full
            if (s.len == s.allocated)
            {
                // realloc if needed
                s.data = realloc(s.data, s.len * 2 * sizeof(char));
                s.allocated *= 2;
            }
            // append the leaf's item
            s.data[s.len] = t->key.item;
            s.len++;
            // reset the traversal
            t = tree;
        }
        if (str[i] == '0')
            t = t->left;
        if (str[i] == '1')
            t = t->right;
    }
    // last element
    s.data[s.len] = t->key.item;
    s.len++;
    *total = s.len;
    return s.data;
}

binTree *decodeTree(char *data)
{
    return __decodeTree(data, 0).t;
}

struct tuple_bi __decodeTree(char *data, size_t i)
{
    // maybe not safe, check for strlen as param mb if errors
    if (!data[i])
    {
        struct tuple_bi res =
        {
            .t = NULL,
            .i = i,
        };
        return res;
    }
    if (data[i] == '1')
    {
        char key = fromBinToByte(data+i+1);
        freq_info f =
        {
            .frequency = 0,
            .item = key,
        };
        binTree *t = createTree(f, NULL, NULL);
        struct tuple_bi res = {
            .t = t,
            .i = i+8,
        };
        return res;
    }
    freq_info f = {
        .frequency = 0,
        .item = 0,
    };
    binTree *t = createTree(f, NULL, NULL);
    // check that it is correct
    t->flag = 1;
    struct tuple_bi res_l = __decodeTree(data, i+1);
    struct tuple_bi res_r = __decodeTree(data, res_l.i+1);
    i = res_r.i;
    t->left = res_l.t;
    t->right = res_r.t;
    struct tuple_bi final =
    {
        .t = t,
        .i = i,
    };
    return final;
}

char equalTree(binTree *a, binTree *b)
{
    if (!a && !b)
        return 1;
    if ((!a && b) || (a &&!b))
    {
        return 0;
    }
    if (a->key.item != b->key.item)
    {
        return 0;
    }
    char res = equalTree(a->left, b->left);
    if (!res)
        return 0;
    res = equalTree(a->right, b->right);
    return res;
}

#define TEST_SIZE 512
#define TEST
void test_decodedata(void)
{
    // char *s = "Hello Jean, I like the 123 song!\0\1\2\24\48";
    // size_t len = 32;
    // gsize len;
    // gchar *s = getFile("./examples/10_123.wav", &len);
    char s[512] = {1};
    glist *freq = build_frequency_list(s, TEST_SIZE);
    binTree *t = buildHuffmanTree(freq);
    char *result = encodeDataHuff(t, s, TEST_SIZE);
    char *encoded_tree = encodeTree(t);
    bitStream *stream = encodeData(result);
    bitStream *stream_t = encodeData(encoded_tree);
    // stream->offset_r = !stream->cell_w ? 0 : 8 - stream->cell_w;
    char *decoded = decodeBitStream(stream);
    char *decoded_tree = decodeBitStream(stream_t);
    // printf("len, %zu\n", strlen(decoded));
    // printf("%s\n",decoded);
    freeBinTree(t);
    t = decodeTree(decoded_tree);
    size_t m;
    char *res = decodeDataHuff(t, decoded, strlen(decoded), &m);
    //printf("%s\n", result);
    #ifdef TEST
    for (size_t i = 0; i < TEST_SIZE; i++)
    {
        if (res[i] != s[i])
        {
            printf("error: %zu %u %u\n",i, (char) res[i], (char) s[i]);
        }
        assert(res[i] == s[i]);
    }
    #endif
    free(res);
    free(result);
    free(decoded);
    freeBitStream(stream);
    freeBinTree(t);
    free_glist(freq);
    // free(s);
}
// LEGACY code is available if LEGACY_DECOMPRESSION is enabled
// @param len: length of the encoded data
// @param total: size_t pointer to the total size of the data
char *decodeDataHuffSlice(binTree *tree, bitStream *b, size_t *total,
                          size_t *r, size_t *o)
{
    string s =
    {
        .allocated = *total,
        .data = calloc(*total, sizeof(char)),
        .len = 0,
    };
    #if LEGACY_DECOMPRESSION
    binTree *t = tree;
    #endif
    for (size_t i = 0; *r < b->offset_w && s.len < *total; i++)
    {
        #if LEGACY_DECOMPRESSION // old decompression done in the function's body
        // if it is a leaf...
        if (!t->flag)
        {
            //  check if the string is full
            if (s.len == s.allocated)
            {
                // realloc if needed
                s.data = realloc(s.data, s.len * 2 * sizeof(char));
                s.allocated *= 2;
            }
            // append the leaf's item
            s.data[s.len] = t->key.item;
            s.len++;
            // reset the traversal
            t = tree;
        }
        if (decodeIndex(b, r, o) == '0')
            t = t->left;
        if (decodeIndex(b, r, o) == '1')
            t = t->right;
        *o = (*o + 1) % 8;
        !*o ? (*r)++ : *r;
        #else
        //  check if the string is full
        if (s.len == s.allocated)
        {
            // realloc if needed
            s.data = realloc(s.data, s.len * 2 * sizeof(char));
            s.allocated *= 2;
        }
        // append the leaf's item
        uint8_t possible = 0;
        s.data[s.len] = decodeDataHuffSingle(tree, b, r, o, &possible);
        s.len++;
        #endif
    }
    return s.data;
}

// @param len: length of the encoded data
// @param total: size_t pointer to the total size of the data
char decodeDataHuffSingle(binTree *tree, bitStream *b, size_t *r,
                          size_t *o, uint8_t *possible)
{
    binTree *t = tree;
    for (size_t i = 0; *r < b->offset_w; i++)
    {
        // if it is a leaf...
        if (!t->flag)
        {
            *possible = 1;
            break;
        }
        if (decodeIndex(b, r, o) == '0')
            t = t->left;
        if (decodeIndex(b, r, o) == '1')
            t = t->right;
        *o = (*o + 1) % 8;
        !*o ? (*r)++ : *r;
    }
    if (*r == b->offset_w && t->flag)
        *possible = 0;
    return t->key.item;
}