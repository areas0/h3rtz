#include "./generic_list.h"

// List structure
glist *init_glist(void)
{
    // Memory allocation
    glist *list = malloc(sizeof(glist));
    // Defining the fields
    list->data = calloc(sizeof(gtype), 256);
    list->len = 256;
    list->nb_el = 0;
    return list;
}

void free_glist(glist *list)
{
    free(list->data);
    free(list);
}

void append_glist(glist *list, gtype data)
{
    // List is empty
    if (list == NULL)
        return;
    // List is full
    if (list->nb_el == list->len)
    {
        list->data = realloc(list->data, sizeof(gtype)*(list->len * 2));
        list->len *= 2;
    }

    // Update fields
    list->data[list->nb_el].item = data.item;
    list->data[list->nb_el].frequency = data.frequency;
    list->nb_el++;
}

// Tree structure
tlist *init_tlist(void)
{
    // Memory allocation
    tlist *list = malloc(sizeof(tlist));
    // Defining the fields
    list->data = calloc(sizeof(binTree*), 256);
    list->len = 256;
    list->nb_el = 0;
    return list;
}

void free_tlist(tlist *list)
{
    free(list->data);
    free(list);
}

void append_tlist(tlist *list, binTree *data)
{
    // List is empty
    if (list == NULL)
        return;
    // List is full
    if (list->nb_el == list->len)
    {
        list->data = realloc(list->data, sizeof(binTree*)*(list->len * 2));
        list->len *= 2;
    }

    // Update fields
    list->data[list->nb_el] = data;
    list->nb_el++;
}

binTree *tree_pop(tlist *list)
{
    // Finding the index of the last element
    list->nb_el--;
    return list->data[list->nb_el];
}