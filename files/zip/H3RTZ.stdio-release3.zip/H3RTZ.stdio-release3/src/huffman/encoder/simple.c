#include "./simple.h"

void compressFileHuffman(char *data, size_t len, char *path, size_t slice,
                         uint8_t flag)
{
    int fd = open(path, O_CREAT | O_WRONLY | O_TRUNC, 0666);
    if (fd == -1)
        errx(EXIT_FAILURE, "Failed to open output file via CFH");
    if (flag)
    {
        // writes a duplicate struct to know the original length
        writeDuplicate(fd, 0, len);
    }
    for (size_t i = 0; i < len; i += slice)
    {
        // final padding
        if (i + slice >= len)
            slice = len - i;
        // builds the frequency list
        glist *freq = build_frequency_list(data + i, slice);
        // special case if there's only one kind of char
        if (freq->nb_el == 1)
        {
            // buffer for the total occurrence
            char number[256] = {0};
            size_t temp = i + slice;
            while (temp < len && data[temp - 1] == data[temp])
                temp++;
            sprintf(number, "%zu", temp - i);
            output_h o = {
                .data = number,
                .id = {'D', 'U', 'P', 'L'}, // special id
                .padding = data[i], // padding used to indicate duplicated char
                .len = strlen(number),
            };
            i = temp - slice;
            writeStructure(fd, &o);
            free_glist(freq);
            continue;
        }
        // builds the associated Huffman tree
        binTree *t = buildHuffmanTree(freq);
        free_glist(freq);
        char *encoded_tree = encodeTree(t);
        bitStream *b = encodeData(encoded_tree);

        output_h *tree = createOutput(b, "TREE");
        writeStructure(fd, tree);
        // initial frees
        freeBitStream(b);
        free(tree);
        free(encoded_tree);

        bitStream *d = encodeDataHuffFast(t, data + i, slice);
        tree = createOutput(d, "HDAT");

        writeStructure(fd, tree);
        // Freeing zone
        freeBitStream(d);
        free(tree);
        freeBinTree(t);
    }
    // we finished compression
    close(fd);
}

void writeDuplicate(int fd, char dup, size_t nb)
{
    // buffer for the total occurrence
    char number[256] = {0};
    sprintf(number, "%zu", nb);
    output_h o = {
        .data = number,
        .id = {'D', 'U', 'P', 'L'}, // special id
        .padding = dup,             // padding used to indicate duplicated char
        .len = strlen(number),
    };
    writeStructure(fd, &o);
}
/**
 * @brief Decodes a stream of data and returns its original form
 * 
 * @param data the stream of data
 * @param i pointer to the index
 * @param decoded number of chars decoded during decompression
 * @return char* the decompressed data
 */
char *decodeStream(char *data, size_t *i, size_t *decoded)
{
    // parse the output
    output_h *old = loadStructure(data, i);
    // if it is a DUPL struct
    if (!strncmp(old->id, "DUPL", 4))
    {
        // scan for the number of times the duplicated is repeated
        size_t length = 0;
        sscanf(old->data, "%zu", &length);
        // do a malloc and set the memory space to that value
        char *res = malloc(sizeof(char) * length);
        memset(res, old->padding, sizeof(char) * length);
        free(old);
        *decoded = length;
        return res;
    }
    // create fake bitStream used for decoding
    bitStream stream = {
        .allocated_len = old->len - 1,
        .data = old->data,
        .offset_w = old->len - 1,
        .offset_r = old->padding,
    };
    // decode the bitStream to string of 0 and 1
    char *encodedTree = decodeBitStream(&stream);
    binTree *tree = decodeTree(encodedTree);
    free(old);

    // compressed data zone, similar to before
    old = loadStructure(data, i);
    bitStream stream_data = {
        .allocated_len = old->len,
        .data = old->data,
        .offset_w = old->len - 1,
        .offset_r = old->padding,
    };

    char *encodedData = decodeBitStream(&stream_data);
    char *decompressedData = decodeDataHuff(tree, encodedData,
                                            strlen(encodedData), decoded);

    freeBinTree(tree);
    free(encodedTree);
    free(old);
    free(encodedData);
    return decompressedData;
}

char *decodeTotalFile(char *data, size_t len, size_t *decodedT, uint8_t flag)
{
    string result = {
        .allocated = 9096,
        .data = calloc(9096, sizeof(char)),
        .len = 0,
    };
    for (size_t i = 0; i < len;)
    {
        // checks for errors in the parsing
        if (strncmp(data + i, "HDAT", 4) && strncmp(data + i, "TREE", 4) &&
            strncmp(data + i, "DUPL", 4))
        {
            printf("%zu %lx\n", i, i);
            errx(EXIT_FAILURE, "Error in padding");
        }
        // total size decoded
        size_t decoded = 0;
        if (!i && flag)
            free(decodeStream(data, &i, &decoded));
        char *d = decodeStream(data, &i, &decoded);
        if (result.allocated + decoded >= result.len)
        {
            // bad complexity, to be improved
            result.data = realloc(result.data, result.allocated + decoded);
            result.allocated += decoded;
        }
        memcpy(result.data + result.len, d, decoded);
        result.len += decoded;
        free(d);
    }
    *decodedT = result.len;
    return result.data;
}

void testEncoder(void)
{
    gsize len;
    gchar *s = getFile("./examples/10_123.wav", &len);
    // compressFileHuffman(s, len, "./output.ht", len);
    gsize len2;
    gchar *s2 = getFile("./output.ht", &len2);
// size_t len3;
// char *first = decodeTotalFile(s2, len2, &len3);
#ifndef LEGACY
    size_t i = 0;
    output_h *old = loadStructure(s2, &i);
    if (!strncmp(old->id, "DUPL", 4))
    {
        size_t length = 0;
        sscanf(old->data, "%zu", &length);
        char *res = malloc(sizeof(char) * length);
        memset(res, old->padding, sizeof(char) * length);
        free(old);
        // *decoded = length;
        return;
    }
    bitStream stream = {
        .allocated_len = old->len - 1,
        .data = old->data,
        .offset_w = old->len - 1,
        .offset_r = old->padding,
    };
    char *encodedTree = decodeBitStream(&stream); // "00011100111"
    binTree *tree = decodeTree(encodedTree);
    free(old);
    // compressed data zone
    old = loadStructure(s2, &i);
    bitStream stream_data = {
        .allocated_len = old->len,
        .data = old->data,
        .offset_w = old->len - 1,
        .offset_r = old->padding,
    };
    size_t r = 0, o = 0, total = 10000;
    char *first = decodeDataHuffSlice(tree, &stream_data, &total, &r, &o);
#endif
    for (size_t i = 0; i < total; i++)
    {
        if (s[i] != first[i])
        {
            printf("error: %zu %u %u\n", i, s[i], first[i]);
        }
        assert(s[i] == first[i]);
    }

    FILE *f = fopen("./new.wav", "w+");
    fwrite(first, len, sizeof(char), f);
    fclose(f);
    free(first);
    // free(s);
    free(s2);
    freeBinTree(tree);
    return;
}
// This function only decompresses the tree structure
binTree *decompressTree(char *data, size_t *i)
{
    output_h *old = loadStructure(data, i);
    if (strncmp(old->id, "TREE", 4))
    {
        free(old);
        return NULL;
    }
    bitStream stream = {
        .allocated_len = old->len - 1,
        .data = old->data,
        .offset_w = old->len - 1,
        .offset_r = old->padding,
    };
    char *encodedTree = decodeBitStream(&stream);
    binTree *tree = decodeTree(encodedTree);
    free(encodedTree);
    free(old);
    return tree;
}
// This function loads quickly data into memory under the form of a bistream
bitStream *loadOnlyData(char *data, size_t *i)
{
    output_h *old = loadStructure(data, i);
    if (strncmp(old->id, "HDAT", 4))
    {
        free(old);
        return NULL;
    }
    bitStream *stream = calloc(1, sizeof(bitStream));
    stream->allocated_len = old->len - 1;
    stream->data = old->data;
    stream->offset_w = old->len - 1;
    stream->offset_r = old->padding;
    free(old);
    return stream;
}
// loads the total length via hack of DUPL chunk
size_t loadOnlyDUPL(char *data, size_t *i)
{
    output_h *old = loadStructure(data, i);
    if (strncmp(old->id, "DUPL", 4))
    {
        free(old);
        return 0;
    }
    size_t length;
    sscanf(old->data, "%zu", &length);
    free(old);
    return length;
}