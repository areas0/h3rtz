#ifndef HZT_H
#define HZT_H


#include "simple.h"
typedef struct huff_decode
{
    binTree *tree;
    bitStream *b;
    size_t r;
    size_t o;
} huff_decode;
#include "../../async/multiplayer.h"



void convertFile(char *path, char *output);
void decodeFile(char *path, char *output);
void decodeHuffmanToPA(wav *w);
tuple decodeHuffmanPart(wav *w);

#endif