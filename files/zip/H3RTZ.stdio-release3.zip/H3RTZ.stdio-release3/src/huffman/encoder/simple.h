#ifndef SIMPLE_H
#define SIMPLE_H

#include "../output/structure.h"
#include "../compress.h"
#include "../decompress.h"
void compressFileHuffman(char *data, size_t len, char *path, size_t slice,
                         uint8_t flag);
void testEncoder(void);

struct tuple_huffman
{
    binTree *tree;
    char *data;
    size_t len;
};
char *decodeTotalFile(char *data, size_t len, size_t *decodedT, uint8_t flag);

binTree *decompressTree(char *data, size_t *i);
bitStream *loadOnlyData(char *data, size_t *i);
void writeDuplicate(int fd, char dup, size_t nb);
size_t loadOnlyDUPL(char *data, size_t *i);
#endif