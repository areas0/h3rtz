#include "hzt.h"
/**
 * @brief Compresses a file using the Huffman algorithm from wav file format
 * 
 * @param path input file path
 * @param output output file path
 */
void convertFile(char *path, char *output)
{
    // file *f = getData(path);
    // if (!f)
    //     return;
    // wav *w = headerParser(f);
    tuple t = ParseTrack(path);
    wav *w = t.b;
    file *f = t.a;
    if (!f || !w)
        return;
    if (w->fmt->AudioFormat == h3rtz)
        errx(42, "Cannot convert an already compressed file, aborting...");
    // open a file descriptor to the output file
    int fd = open(output, O_CREAT | O_WRONLY | O_TRUNC, 0666);
    if (fd == -1)
    {
        freeWav(w);
        freeFile(f);
        errx(EXIT_FAILURE, "Failed to create output file");
    }
    // change the wav format flag to unknown
    w->fmt->AudioFormat = h3rtz;
    // compress the file to another using the compressFileHuffman function
    compressFileHuffman((char *)w->data->chunk, w->data->data_bytes,
                        "output.temp", w->data->data_bytes, 1);
    // load the compressed file in memory using the getFile function
    size_t compressed;
    char *contents = getFile("output.temp", &compressed);
    // update the size: data->data_bytes to be updated
    size_t diff = w->riff->fileSize - w->data->data_bytes;
    w->riff->fileSize = diff + compressed;
    w->data->data_bytes = compressed;
    // write the header
    write_header(fd, w);
    // write the compressed data using rewrite
    rewrite(fd, contents, compressed,
            "ERROR: Error while writing the compresssed file!");
    free(contents);
    w->fmt->AudioFormat = PCM;
    freeWav(w);
    freeFile(f);
    close(fd);
    if (remove("./output.temp") == -1)
        err(errno, "Failed to remove temporary file");
}

void decodeFile(char *path, char *output)
{
    file *f = getData(path);
    if (!f)
        return;
    wav *w = headerParser(f);
    if (!w)
        return;
    // open a file descriptor to the output file
    int fd = open(output, O_CREAT | O_WRONLY | O_TRUNC, 0666);
    if (fd == -1)
    {
        freeWav(w);
        freeFile(f);
        errx(EXIT_FAILURE, "Failed to open output file");
    }
    // change the wav format flag to experimental
    w->fmt->AudioFormat = PCM;
    // decompress the file using the decodeTotalFile function
    size_t d;
    char *decoded = decodeTotalFile((char *)w->data->chunk, w->data->data_bytes,
                                    &d, 1);
    // update the size: data->data_bytes to be updated
    size_t diff = w->riff->fileSize - w->data->data_bytes;
    w->riff->fileSize = diff + d;
    w->data->data_bytes = d;
    // write the header
    write_header(fd, w);
    // write the compressed data using rewrite
    rewrite(fd, decoded, d, "ERROR: Error while writing the decompresssed file!");
    free(decoded);
    freeWav(w);
    freeFile(f);
    close(fd);
}

// Decompresses the data chunk using huffman decompression
// replaces old data->chunk by decompressed data
// LEGACY
// @param w: wav header of the compressed file
void decodeHuffmanToPA(wav *w)
{
    if (!w)
        return;
    // decompress the file using the decodeTotalFile function
    size_t d;
    char *decoded = decodeTotalFile((char *)w->data->chunk, w->data->data_bytes,
                                    &d, 1);
    // update the size: data->data_bytes to be updated
    size_t diff = w->riff->fileSize - w->data->data_bytes;
    w->riff->fileSize = diff + d;
    w->data->data_bytes = d;
    w->data->chunk = (unsigned char *)decoded;
}

// loads a tuple with the Huffman tree + the data under the structure BitStream
tuple decodeHuffmanPart(wav *w)
{
    tuple t = {0};
    if (!w || w->fmt->AudioFormat != h3rtz)
        return t;
    size_t i = 0;
    size_t original_length = loadOnlyDUPL((char *)w->data->chunk, &i);
    binTree *tree = decompressTree((char *)w->data->chunk, &i);
    bitStream *b = loadOnlyData((char *)w->data->chunk, &i);
    w->data->data_bytes = original_length;
    t.a = tree;
    t.b = b;
    return t;
}