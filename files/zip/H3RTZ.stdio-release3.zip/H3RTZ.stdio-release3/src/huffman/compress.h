#ifndef COMPRESS_H
#define COMPRESS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <glib.h>
#include "../tools/bintree/bintree.h"
#include "../tools/Bitstream/bistream.h"
#include "./output/structure.h"
#include <err.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include "../wav/encode/raw.h"
#define HUFF_MAX 256

#include "./generic_list.h"
typedef struct string
{
  char *data;
  size_t len;
  size_t allocated;
} string;

void swap(binTree *a, binTree *b);
struct glist *build_frequency_list(char *str, size_t len);
gchar *getFile(gchar *path, gsize *len);
void print(struct glist *list);
binTree *buildHuffmanTree(glist *freq_list);
void decreasing_sort(tlist *list);
void print_tlist(tlist *t);
binTree *rec(binTree *tree);
void traversal(binTree *tree);
void testBuildHuffman(void);
char *encodeDataHuff(binTree *tree, char *str, size_t len);
string *__occurence(binTree *tree, char elt, string *s, size_t pos);
char *ascii_to_binary(unsigned char c);
void __rec(binTree *tree, GString *result);
char *encodeTree(binTree *tree);
void compressToFile(char *data, size_t len, char *output);
output_h *createOutput(bitStream *b, char  *id);
void encodeFile(char *path);
void encodeFileMulti(void);
void encodeFile(char *path);
void *workerHuffman(void *userdata);
bitStream *encodeDataHuffFast(binTree *tree, char *str, size_t len);
#endif