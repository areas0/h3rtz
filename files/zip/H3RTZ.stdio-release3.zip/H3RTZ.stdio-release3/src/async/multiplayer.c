#include "multiplayer.h"
double volume = 1.0f;
// Inits a new mainloop, prepares a context and connects the context to a server
// @returns -1 on error 0 on success
int init_player(pa_player *player)
{
    pa_objects *pa = player->pulseAudio;
    if (player->pa_state != BABY)
        return -1;
    pa->loop = pa_threaded_mainloop_new();
    if (!pa->loop)
        return -1;
    pa->api = pa_threaded_mainloop_get_api(pa->loop);
    if (!pa->api)
        return -1;
    pa->context = pa_context_new(pa->api, "h3rtz");
    if (!pa->context)
        return -1;
    pa_context_set_state_callback(pa->context, &callback_init_wait, player);

    pa_threaded_mainloop_lock(pa->loop);
    if (pa_threaded_mainloop_start(pa->loop) != 0)
        return -1;
    if (pa_context_connect(pa->context, NULL, PA_CONTEXT_NOAUTOSPAWN, NULL) != 0)
        return -1;

    while(1)
    {
        pa_context_state_t state = pa_context_get_state(pa->context);
        if (!PA_CONTEXT_IS_GOOD(state))
            return -1;
        if (state == PA_CONTEXT_READY)
            break;
        pa_threaded_mainloop_wait(pa->loop);
    }
    if (!player->player->timing->latency)
        player->player->timing->latency = malloc(sizeof(pa_usec_t));
    player->pa_state = READY;
    pa_threaded_mainloop_unlock(pa->loop);
    return 0;
}

// Prepares to stream a file
// @returns -1 on error 0 on success
int prepareStream(pa_player *player)
{
    pa_threaded_mainloop_lock(player->pulseAudio->loop);
    if (player->pa_state != READY && player->pa_state != TERMINATED)
    {
        warnx("prepareStream: failed because of invalid state");
        return -1;
    }
    if (player->pa_state == TERMINATED && player->player->timing)
    {
        //player->player->timing->current = 0;
        //player->player->timing->offset = 0;
        //player->player->timing->time = 0;
    }
    pa_objects *pa = player->pulseAudio;
    wav_player *wav = player->player;
    // transforms the current header into specs for pulseaudio
    pa_sample_spec spec = headerToSpecs(player->player->info);
    // mapping = nb channels
    pa_channel_map map;
    pa_channel_map_init_auto(&map, player->player->info->fmt->channel,
                                PA_CHANNEL_MAP_DEFAULT);
    pa_format_info *info = pa_format_info_from_sample_spec(&spec, &map);
    //updatePropInfo(info, player->player->info);
    wav->stream = pa_stream_new_extended(pa->context, "h3rtz", &info, 1, NULL);
    pa_format_info_free(info);
    if (!wav->stream)
        return -1;
    pa_stream_set_state_callback(wav->stream, &callback_stream, player);
    pa_stream_set_overflow_callback(wav->stream, &callback_stream, player);
    pa_stream_set_underflow_callback(wav->stream, &callback_stream, player);
    // make sure that the player points to the data correctly
    updateInfo(player);
    // prepares the callback to write data to the buffer
    pa_stream_set_write_callback(wav->stream, &callback_write, player);
    
    pa_buffer_attr attributes =
    {
        .maxlength = -1,
        .minreq = -1,
        .tlength = -1,
        .prebuf = -1,
    };
    // by default, do not modify that
    pa_stream_flags_t flags = PA_STREAM_START_CORKED |
        PA_STREAM_INTERPOLATE_TIMING |
        PA_STREAM_NOT_MONOTONIC | PA_STREAM_AUTO_TIMING_UPDATE |
        PA_STREAM_ADJUST_LATENCY;
    // connects the stream to the playback handler (outside of program)
    // synchronous operation
    int error = pa_stream_connect_playback(wav->stream, NULL,
                                                &attributes, flags, NULL, NULL);
    if (error != 0)
        return -1;
    // wait for stream to be ready
    while(1)
    {
        pa_stream_state_t stream_state = pa_stream_get_state(wav->stream);
        if (!PA_STREAM_IS_GOOD(stream_state))
            return -1;
        if (stream_state == PA_STREAM_READY)
            break;
        pa_threaded_mainloop_wait(pa->loop);
    }
    // our program is ready we can start seeking events
    pa_threaded_mainloop_unlock(pa->loop);
    // gets the name of our default sink
    if (!player->pulseAudio->sink)
        getDefaultSink(player);
    player->info->id = pa_stream_get_index(wav->stream);
    if (player->info->id == PA_INVALID_INDEX)
        return -1;
    if (!wav->timing)
        initPulseTimeInfo(&(wav->timing));
    player->pa_state = ACTIVE;
    wav->status = PAUSED;
    wav->drainer->state = DRAIN_INACTIVE;
    return 0;
}

// test player, playground for Jean
#if !TEST
void player(int argc, char **argv)
{
    pa_player *player = NULL;
    int e = initPulsePlayer(&player);
    if (e == -1)
        errx(EXIT_FAILURE, "Failed init");
    init_player(player);
    pthread_t t;
    wav **players = calloc(argc-1, sizeof(wav));
    file **files = calloc(argc-1, sizeof(file));
    for (int i = 1; i < argc; i++)
    {
        tuple t = ParseTrack(argv[i]);
        players[i-1] = t.b;
        files[i-1] = t.a;
    }

    for (int i = 1; i < argc; i++)
    {
        changeTrackNoFree(player, players[i-1], files[i-1]);
        //player->player->track = files[i-1];
        //player->player->info = players[i-1];
        //parseFile(player, argv[i]);
        prepareStream(player);
        play(player);
        pthread_create(&t, NULL, &display_time, player);
        pthread_detach(t);
        while (player->pa_state == ACTIVE)
        {
            
            char c = getc(stdin);
            if (c == 'p')
                Pause(player);
            else if (c == 'n')
                play(player);
            else if (c == 'f')
            {
                //Pause(player);
                relative(player, player->player->timing->offset+4200, 1);
                //play(player);
            }
            else if (c == 'q')
            {
                Pause(player);
                terminateStream(player);
                break;
            }
            
           /*
            pthread_t t2;
            pthread_create(&t2, NULL, &drainStreamT, player);
            pthread_detach(t2);
            sleep(1);
            pthread_create(&t2, NULL, &drainStreamT, player);
            pthread_detach(t2);
            sleep(5);
            cancelDrain(player);
            sleep(45);
            */
            /*
            play(player);
            Pause(player);
            Pause(player);
            sleep(5);
            play(player);
            sleep(5);
            interrupt(player);
            */
            /*
            sleep(5);
            Pause(player);
            terminateStream(player);
            */
           /*
            sleep(5);
            pthread_t t;
            pthread_create(&t, NULL, &drainStreamT, player);
            pthread_detach(t);
            sleep(1);
            relative(player, player->player->timing->offset+4500, 1);
            */
        }
        //changeTrack(player);
    }
    // freeing zone
    pa_context_unref(player->pulseAudio->context);
    pa_threaded_mainloop_stop(player->pulseAudio->loop);
    pa_threaded_mainloop_free(player->pulseAudio->loop);
    freePulsePlayer(player);
    
}
#endif

/* Standard termination procedure for stream
* @return positive int if it terminated a stream otherwise negative
*/
int terminateStream(pa_player *player)
{
    //pa_objects *pa = player->pulseAudio;
    //pa_stream *stream = player->player->stream;
    if (player->pa_state == ACTIVE && player->player->status == PAUSED)
    {
        warnx("terminateStream: launched interrupt procedure");
        interrupt(player);
        //player->player->stream = 0;
        return 0;
    }
    if (player->pa_state == ACTIVE && player->player->status == PLAYING)
    {
        warnx("terminateStream: launched draining procedure");
        drainStream(player);
        player->pa_state = TERMINATED;
        player->player->status = NOT_READY;
        //player->player->stream = 0;
        return 1;
    }
    return -1;
}

void *terminateStreamT(void *userdata)
{
    terminateStream((pa_player *) userdata);
    return NULL;
}
// quick file parser: tries to parse the file as a wav file
// if it fails, tries to do it with gstreamer
int parseFile(pa_player *player, char *path)
{
    file *f = getData(path);
    wav *h = headerParser(f);
    if (h)
    {
        player->player->track = f;
        player->player->info = h;
        player->type = WAV_ORIGINAL;
        return 0;
    }
    freeFile(f);
    if (convert(player, path) == -1)
    {
        warnx("Failed to convert the file, returning error...");
        return -1;
    }
    player->type = OTHER;
    return 0;
}
/**
 * @brief Frees the previous track and sets the field for the next one
 * 
 * @param player the PulseAudio object
 */
void changeTrack(pa_player *player)
{
    freeWav(player->player->info);
    freeFile(player->player->track);
    player->player->info = 0;
    player->player->track = 0;
}
// The caller is responsible of memory handling for field info and track
void changeTrackNoFree(pa_player *player, wav *w, file *f)
{
    if (dec)
    {
        freeBinTree(dec->tree);
        free(dec->b);
        free(dec);
        dec = 0;
    }
    if (w->fmt->AudioFormat == h3rtz)
    {
        tuple data = decodeHuffmanPart(w);
        dec = calloc(1, sizeof(huff_decode));
        dec->b = data.b;
        dec->tree = data.a;
    }
    player->player->info = w;
    player->player->track = f;
    player->type = f->fd == -1 ? OTHER : WAV_ORIGINAL;
}

// returns a tuple to the file parsed
// a contains the file (see typdef in tools.h)
// b contains the wav_header (see typedef in headerwav.h)
tuple ParseTrack(char *path)
{
    file *f = getData(path);
    wav *h = headerParser(f);
    tuple t =
    {
        .a = f,
        .b = h,
    };
    if (h)
    {
        // if (h->fmt->AudioFormat == h3rtz)
        // {
        //     // decodeHuffmanToPA(h);
        // }
        return t;
    }
    freeFile(f);
    pa_player player =
    {
        .player = calloc(1, sizeof(wav_player)),
    };
    if (convert(&player, path) == -1)
    {
        free(player.player);
        warnx("Failed to convert the file, returning error...");
        t.a = NULL;
        t.b = NULL;
        return t;
    }
    t.a = player.player->track;
    t.b = player.player->info;
    free(player.player);
    return t;
}