#include "object_free.h"

int freePulseObjects(pa_objects *obj)
{
    if (!obj)
        return -1;
    if (obj->sink)
        free(obj->sink);
    free(obj);
    return 0;
}

int freePulseDrain(drain *d)
{
    if (!d)
        return -1;
    free(d);
    return 0;
}

int freeWavPlayer(wav_player *p)
{
    if (!p)
        return -1;
    if (p->info)
        freeWav(p->info);
    if (p->track)
        freeFile(p->track);
    if (p->timing)
        freePulseTimeInfo(p->timing);
    if (p->drainer)
        freePulseDrain(p->drainer);
    free(p);
    return 0;
}

int freePulseTimeInfo(pa_time *p)
{
    if (!p)
        return -1;
    if (p->latency)
        free(p->latency);
    free(p);
    return 0;
}

int freePulseInfo(pa_info *i)
{
    if (!i)
        return -1;
    free(i);
    return 0;
}

int freePulsePlayer(pa_player *p)
{
    if (!p)
        return -1;
    if (p->player)
        freeWavPlayer(p->player);
    if (p->pulseAudio)
        freePulseObjects(p->pulseAudio);
    if (p->info)
        freePulseInfo(p->info);
    free(p);
    return 0;
}