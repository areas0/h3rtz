#include "write.h"

huff_decode *dec = NULL;

void callback_write(pa_stream *stream, size_t requested_bytes, void *userdata)
{
    size_t total = 0;
    pa_player *player = userdata;
    wav_player *wav = player->player;
    uint8_t *data = wav->data;
    size_t filelength = wav->info->data->data_bytes;
    uint8_t flag = wav->info->fmt->AudioFormat == h3rtz;
    // printf("%d\n", requested_bytes);
    while (total < requested_bytes && wav->timing->offset < filelength)
    {
        uint8_t *buffer = NULL;
        size_t bytes_to_fill = wav->info->fmt->bitrate;
        size_t i;
        if (total + bytes_to_fill > requested_bytes)
            bytes_to_fill = requested_bytes - total;
        // prepares the write operation (optimization)
        pa_stream_begin_write(stream, (void**) &buffer, &bytes_to_fill);
        // fills the buffer with the data from the file
        pthread_mutex_lock(&mutex_acc);
        if (flag)
        {
            uint8_t possible = 0;
            for (i = 0; i < bytes_to_fill && i + wav->timing->offset < filelength; i += 1)
            {
                possible = 0;
                buffer[i] = (uint8_t)decodeDataHuffSingle(dec->tree, dec->b,
                                                          &(dec->r), &(dec->o),
                                                          &possible);
                if (!possible)
                    break;
            }
        }
        else
        {
            for (i = 0; i < bytes_to_fill && i + wav->timing->offset < filelength; i += 1)
            {
                buffer[i] = (uint8_t)data[i + wav->timing->offset];
            }
        }
        pthread_mutex_unlock(&mutex_acc);
        for (; i < bytes_to_fill; i++)
        {
            buffer[i] = 0;
        }
        pa_stream_write(stream, buffer, bytes_to_fill, NULL, 0LL, PA_SEEK_RELATIVE);
        total += bytes_to_fill;
        wav->timing->offset += bytes_to_fill;
        //pa_playerInfo(player);
    }
    wav->timing->time = (double) wav->timing->offset/wav->info->fmt->bitrate;
    // if we finished buffering the file, we set the state as finished
    if (wav->timing->offset > filelength && player->pa_state == ACTIVE)
    {
        // disconnects the write callback
        pa_stream_set_write_callback(player->player->stream, NULL, NULL);
        // detached draining process: cannot drain in callback directly
        //player->pa_state = FINISHED;
        pthread_t t;
        pthread_create(&t, NULL, terminateStreamT, player);
        pthread_detach(t);
        //pthread_join(t, NULL);
        return;
    }
}