#ifndef DRAIN_H
#define DRAIN_H

#include "../multiplayer.h"

void callbackDrain(pa_stream *stream, int success, void *userdata);
void drainStream(pa_player *player);
void *drainStreamT(void *userdata);
void cancelDrain(pa_player *player);
#endif