#include "state.h"
// uncorks a stream
void play(pa_player *player)
{
    pa_objects *pa = player->pulseAudio;
    pa_threaded_mainloop_lock(pa->loop);
    if (player->pa_state != ACTIVE)
    {
        warnx("play: no stream playing, can't resume playback...");
        pa_threaded_mainloop_unlock(pa->loop);
        return;
    }
    if (player->player->status == PLAYING)
    {
        warnx("play: already playing");
        pa_threaded_mainloop_unlock(pa->loop);
        return;
    }
    if (!player->player->stream)
    {
        warnx("play: no stream to play, skipping...");
        pa_threaded_mainloop_unlock(pa->loop);
        return;
    }
    pa_operation *op = pa_stream_cork(player->player->stream, 0,
                                        &stateChange, player);
    while (pa_operation_get_state(op) != PA_OPERATION_DONE)
        pa_threaded_mainloop_wait(pa->loop);
    pa_threaded_mainloop_unlock(pa->loop);
    pa_operation_unref(op);
    player->player->status = PLAYING;
}
// corks a stream
void Pause(pa_player *player)
{
    pa_objects *pa = player->pulseAudio;
    pa_threaded_mainloop_lock(pa->loop);
    if (player->pa_state != ACTIVE)
    {
        warnx("Pause: no stream playing, can't stop playback...");
        pa_threaded_mainloop_unlock(pa->loop);
        return;
    }
    if (player->player->status != PLAYING)
    {
        warnx("Pause: already paused...");
        pa_threaded_mainloop_unlock(pa->loop);
        return;
    }
    if (!player->player->stream)
    {
        warnx("Pause: no stream to pause, skipping...");
        pa_threaded_mainloop_unlock(pa->loop);
        return;
    }
    pa_operation *op = pa_stream_cork(player->player->stream, 1,
                                        &stateChange, player);
    while (pa_operation_get_state(op) != PA_OPERATION_DONE)
        pa_threaded_mainloop_wait(pa->loop);
    pa_threaded_mainloop_unlock(pa->loop);
    pa_operation_unref(op);
    player->player->status = PAUSED;
}

// wrapper that launches an interruption operation
void interrupt(pa_player *player)
{
    pa_objects *pa = player->pulseAudio;
    pa_threaded_mainloop_lock(pa->loop);
    if (!pa->context)
    {
        pa_threaded_mainloop_unlock(pa->loop);
        warnx("Interrupt: no context, returning...");
        return;
    }
    if (player->pa_state != ACTIVE)
    {
        pa_threaded_mainloop_unlock(pa->loop);
        warnx("Interrupt: no stream to interrupt...");
        return;
    }
    if (player->player->drainer->state == DRAIN_ACTIVE)
    {
        cancelDrain(player);
    }
    pa_operation *op = pa_context_suspend_sink_by_name(pa->context, "h3rtz",
                                                    1, &interruptCb, player);
    while (pa_operation_get_state(op) != PA_OPERATION_DONE)
    {
        pa_threaded_mainloop_wait(pa->loop);
    }
    player->player->status = NOT_READY;
    player->pa_state = TERMINATED;
    pa_operation_unref(op);
    if (player->player->stream)
        pa_stream_disconnect(player->player->stream);
    //pa_stream_unref(player->player->stream);
    //player->player->stream = 0;
    pa_threaded_mainloop_unlock(pa->loop);
    warnx("interrupt: killed stream successfully...");
}

void stateChange(pa_stream *stream, int success, void *userdata)
{
    assert(stream);
    if (!success)
        warnx("Play/Pause: operation failed...");
    pa_player *player = userdata;
    pa_objects *pa = player->pulseAudio;
    pa_threaded_mainloop_signal(pa->loop, 0);
    return;
}
// Default callback for stream operations
void callback_stream(pa_stream *s, void *userdata)
{
    pa_player *player = userdata;
    pa_objects *pa = player->pulseAudio;
    pa_stream_state_t state = pa_stream_get_state(s);
    switch (state)
    {
    case PA_STREAM_UNCONNECTED:
        warnx("CbStream: Stream is unconnected...");
        break;
    case PA_STREAM_CREATING:
        warnx("CbStream: Stream is being prepared...");
        break;
    case PA_STREAM_READY:
        warnx("CbStream: Stream is ready...");
        break;
    case PA_STREAM_FAILED:
        terminateStream(player);
        warnx("CbStream: Stream failed, program will likely fail...");
        break;
    case PA_STREAM_TERMINATED:
        if (player->pa_state == ACTIVE)
        {
            warnx("CbStream: Redudancy for states, stream terminated");
            player->pa_state = TERMINATED;
            player->player->status = NOT_READY;
        }
        break;
    default:
        warnx("Unknown state...");
        break;
    }
    pa_threaded_mainloop_signal(pa->loop, 0);
}

void interruptCb(pa_context *c, int success, void *userdata)
{
    assert(c);
    assert(success >= 0);
    pa_player *player = userdata;
    pa_objects *pa = player->pulseAudio;
    pa_threaded_mainloop_signal(pa->loop, 0);
}