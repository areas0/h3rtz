#ifndef STATE_H
#define STATE_H

#include "../multiplayer.h"

void stateChange(pa_stream *stream, int success, void *userdata);
void interruptCb(pa_context *c, int success, void *userdata);
void callback_stream(pa_stream *s, void *userdata);
void play(pa_player *player);
void Pause(pa_player *player);
void interrupt(pa_player *player);
#endif