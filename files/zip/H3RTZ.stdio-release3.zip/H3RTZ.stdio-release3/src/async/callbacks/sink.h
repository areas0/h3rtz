#ifndef SINK_H
#define SINK_H

#include "../multiplayer.h"
void callbackSink(pa_context *c, const pa_server_info *i, void *userdata);
void getDefaultSink(pa_player *player);
void resume(pa_player *player);
#endif