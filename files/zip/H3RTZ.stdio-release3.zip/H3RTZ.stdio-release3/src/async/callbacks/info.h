#ifndef INFO_H
#define INFO_H

#include "../multiplayer.h"

void callback_info_source(pa_context *c, const pa_source_info *i,
                          int eol, void *userdata);

#endif