#ifndef PLACEHOLDERS_H
#define PLACEHOLDERS_H

#include "../multiplayer.h"
void callback_success_stream(pa_stream *stream, int success, void *userdata);
void callback_init_wait(pa_context *context, void *userdata);
#endif