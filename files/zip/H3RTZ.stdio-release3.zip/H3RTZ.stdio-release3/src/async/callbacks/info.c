#include "info.h"

void callback_info_source(pa_context *c, const pa_source_info *i,
                          int eol, void *userdata)
{
    assert(c);
    assert(eol >= 0);
    pa_player *player = userdata;
    pa_objects *pa = player->pulseAudio;
    if (i)
    {
        printf("Got info\n");
        printf("%ld %s\n", i->latency, i->name);
    }
    pa_threaded_mainloop_signal(pa->loop, 0);
}