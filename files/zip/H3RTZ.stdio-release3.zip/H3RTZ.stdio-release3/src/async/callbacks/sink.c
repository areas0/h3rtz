#include "sink.h"

// resumes a sink
void resume(pa_player *player)
{
    pa_objects *pa = player->pulseAudio;
    pa_threaded_mainloop_lock(pa->loop);
    pa_operation *op = pa_context_suspend_sink_by_name(pa->context, "h3rtz",
                                                    0, &interruptCb, player);
    while (pa_operation_get_state(op) != PA_OPERATION_DONE)
    {
        pa_threaded_mainloop_wait(pa->loop);
    }
    player->player->status = PLAYING;
    pa_threaded_mainloop_unlock(pa->loop);
    //printf("Finished resuming\n");
}

void getDefaultSink(pa_player *player)
{
    pa_objects *pa = player->pulseAudio;
    pa_threaded_mainloop_lock(pa->loop);
    pa_operation *op = pa_context_get_server_info(pa->context, &callbackSink,
                                                    player);
    while (pa->sink == NULL)
    {
        pa_threaded_mainloop_wait(pa->loop);
    }
    pa_operation_unref(op);
    pa_threaded_mainloop_unlock(pa->loop);
    //assert(infos);
    //printf("%p", infos);
}

void callbackSink(pa_context *c, const pa_server_info *i, void *userdata)
{
    assert(c);
    pa_player *player = userdata;
    pa_objects *pa = player->pulseAudio;
    int error = asprintf(&(pa->sink), "%s", i->default_sink_name);
    if (error <= 0)
        err(errno, "Couldn't copy sink name");
    //printf("Sink: %s\n", pa->sink);
    pa_threaded_mainloop_signal(pa->loop, 0);
}