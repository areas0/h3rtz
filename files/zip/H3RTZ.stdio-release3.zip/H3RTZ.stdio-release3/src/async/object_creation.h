#ifndef OBJECT_CREATION_H
#define OBJECT_CREATION_H
/* This file contains init functions for multiple
** objects related to the pulseAudio player
*/

#include "multiplayer.h"

int initPulseObjects(pa_objects **obj);
int initPulseDrain(drain **d);
int initWavPlayer(wav_player **w);
int initPulseTimeInfo(pa_time **i);
int initPulseInfo(pa_info **i);
int initPulsePlayer(pa_player **p);
#endif