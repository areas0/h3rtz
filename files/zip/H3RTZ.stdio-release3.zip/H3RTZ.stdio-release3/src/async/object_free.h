#ifndef OBJECT_FREE_H
#define OBJECT_FREE_H
/* This file contains freeing methods wrappers
** for pulseAudio and other objects
*/

#include "multiplayer.h"

int freePulseObjects(pa_objects *obj);
int freePulseDrain(drain *d);
int freeWavPlayer(wav_player *p);
int freePulseTimeInfo(pa_time *p);
int freePulsePlayer(pa_player *p);
#endif