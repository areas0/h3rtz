#ifndef MULTIPLAYER_H
#define MULTIPLAYER_H
#define _GNU_SOURCE

typedef struct tuple
{
    void *a;
    void *b;
} tuple;
#include <assert.h>
#include <string.h>
#include <wait.h>
#include "../wav/wav.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <pulse/pulseaudio.h>
#include "./settings/tools.h"
#include "./settings/latency.h"
#include "./settings/position.h"
#include "./settings/volume.h"
#include "./callbacks/drain.h"
#include "./callbacks/info.h"
#include "./callbacks/placeholders.h"
#include "./callbacks/sink.h"
#include "./callbacks/state.h"
#include "./callbacks/write.h"
#include "./properties/prop_info.h"
#include "./mp3/stream.h"
#include "object_creation.h"
#include "object_free.h"
#include "./settings/helper.h"
#include "../huffman/encoder/hzt.h"


extern huff_decode *dec;
int init_player(pa_player *player);
int prepareStream(pa_player *player);
void player(int argc, char **argv);
//void pa_playerInfo(pa_player *player);
int terminateStream(pa_player *player);
void callbackRaised(pa_context *c, int success, void *userdata);
void *terminateStreamT(void *userdata);
int parseFile(pa_player *player, char *path);
void changeTrack(pa_player *player);
tuple ParseTrack(char *path);
void changeTrackNoFree(pa_player *player, wav *w, file *f);
#endif