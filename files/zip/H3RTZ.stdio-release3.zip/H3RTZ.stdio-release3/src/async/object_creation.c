#include "object_creation.h"


int initPulseObjects(pa_objects **obj)
{
    if (*obj)
        return -1;
    obj[0] = calloc(1, sizeof(pa_objects));
    if (!obj[0])
        return -1;
    return 0;
}

int initPulseDrain(drain **d)
{
    if (d[0])
        return -1;
    d[0] = calloc(1, sizeof(drain));
    if (!*d)
        return -1;
    return 0;
}

int initWavPlayer(wav_player **w)
{
    if (w[0])
        return -1;
    w[0] = calloc(1, sizeof(wav_player));
    if (!w[0])
        return -1;
    if (initPulseTimeInfo(&(w[0]->timing)) == -1)
        return -1;
    if (initPulseDrain(&(w[0]->drainer)) == -1)
        return -1;
    return 0;
}

int initPulseTimeInfo(pa_time **i)
{
    if (*i)
        return -1;
    *i = calloc(1, sizeof(pa_time));
    if (!*i)
        return -1;
    return 0;
}

int initPulseInfo(pa_info **i)
{
    if (*i)
        return -1;
    *i = calloc(1, sizeof(pa_info));
    if (!*i)
        return -1;
    return 0;
}

int initPulsePlayer(pa_player **p)
{
    if (*p)
        return -1;
    *p = calloc(1, sizeof(pa_player));
    if (initPulseObjects(&(p[0]->pulseAudio)) == -1)
        return -1;
    if (initWavPlayer(&(p[0]->player)) == -1)
        return -1;
    if (initPulseInfo(&(p[0]->info)) == -1)
        return -1;
    return 0;
}