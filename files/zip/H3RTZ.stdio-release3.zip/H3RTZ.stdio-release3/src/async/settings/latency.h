#ifndef LATENCY_H
#define LATENCY_H

#include "../multiplayer.h"
void *updateLatency(void *userdata);

#endif