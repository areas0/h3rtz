#include "latency.h"

/* Retrives latency from a player. Made to be used with pthread
 * @param userdata: pa_player data
 */
void *updateLatency(void *userdata)
{
    pa_player *player = userdata;
    int neg;
    int err = pa_stream_get_latency(player->player->stream,
    player->player->timing->latency, &neg);
    if (err != 0)
    {
        //warnx("Couldn't retrieve latency\n");
        *player->player->timing->latency = 0;
    }
    return NULL;
}