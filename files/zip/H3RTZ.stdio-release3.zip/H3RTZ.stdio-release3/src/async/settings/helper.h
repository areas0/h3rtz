#ifndef HELPER_H
#define HELPER_H

#include "../multiplayer.h"
/* This file contains functions to help debug the PulseAudio player
** Some function will convert the enumeration into strings
** Some will print on the stdout the current status
*/
char *paStateToString(state s);
char *playerStatusToString(playerStatus s);
char *drainStatusToString(DrainStatus d);
void printPulseState(pa_player *player);
#endif